<?php
require_once 'db.php';
require_once 'pascco_shell.php';

$error = '';
$success = '';

$first_name = trim($_POST['first_name'] ?? '');
$last_name = trim($_POST['last_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$address = trim($_POST['address'] ?? '');
$preferred_mode = trim($_POST['preferred_mode'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $allowed_modes = [
        'face_to_face',
        'online',
        'either',
    ];

    if (
        $first_name === '' ||
        $last_name === '' ||
        $email === '' ||
        $phone === '' ||
        $address === ''
    ) {
        $error = 'Please complete all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (!in_array($preferred_mode, $allowed_modes, true)) {
        $error = 'Please select your preferred PMES mode.';
    } else {
        try {
            $check = $pdo->prepare(
                "SELECT id
                 FROM membership_applications
                 WHERE email = ?
                   AND status NOT IN ('approved', 'rejected')
                 LIMIT 1"
            );
            $check->execute([$email]);

            if ($check->fetch()) {
                $error = 'There is already an active membership application using this email address.';
            } else {
                $application_reference = 'APP-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(3)));
                $member_name = $first_name . ' ' . $last_name;

                $insert = $pdo->prepare(
                    "INSERT INTO membership_applications
                    (
                        user_id,
                        first_name,
                        last_name,
                        member_name,
                        email,
                        phone,
                        address,
                        preferred_mode,
                        application_reference,
                        status
                    )
                    VALUES (
                        NULL,
                        ?, ?, ?, ?, ?, ?, ?, ?,
                        'pending_schedule'
                    )"
                );

                $insert->execute([
                    $first_name,
                    $last_name,
                    $member_name,
                    $email,
                    $phone,
                    $address,
                    $preferred_mode,
                    $application_reference,
                ]);

                $success =
                    'Application submitted successfully. ' .
                    'Your reference number is ' . $application_reference .
                    '. PASCCO will contact you by email regarding available PMES schedules.';

                $first_name = '';
                $last_name = '';
                $email = '';
                $phone = '';
                $address = '';
                $preferred_mode = '';
            }
        } catch (Throwable $exception) {
            $error = 'Unable to submit your application. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <title>Register | PASCCO</title>
    <style>
        :root {
            --register-navy: #071d49;
            --register-blue: #1456a0;
            --register-blue-light: #2b74c8;
            --register-gold: #e7b84b;
            --register-ink: #182a45;
            --register-muted: #687a91;
            --register-line: #dbe5f0;
            --register-bg: #f4f7fb;
            --register-soft: #eef4fb;
            --register-success-bg: #eaf8f0;
            --register-success: #176b3a;
            --register-danger-bg: #fff0f0;
            --register-danger: #a73535;
            --register-shadow: 0 16px 38px rgba(7, 29, 73, .08);
        }

        html,
        body {
            margin: 0 !important;
            padding: 0 !important;
            overflow-x: hidden;
        }

        body {
            background: linear-gradient(180deg, #edf4fb 0, #f7f9fc 360px, var(--register-bg) 100%);
            color: var(--register-ink);
            font-family: 'Poppins', Arial, Helvetica, sans-serif;
        }

        button,
        input,
        select,
        textarea,
        label,
        a {
            font-family: 'Poppins', Arial, Helvetica, sans-serif;
        }

        .register-page {
            max-width: 1180px;
            margin: 0 auto;
            padding: 36px 22px 68px;
        }

        .register-hero {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 24px;
            margin-bottom: 24px;
        }

        .register-hero-content {
            max-width: 760px;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 10px;
            color: var(--register-blue);
            font-size: .76rem;
            font-weight: 800;
            letter-spacing: .16em;
            text-transform: uppercase;
        }

        .eyebrow::before {
            content: '';
            width: 28px;
            height: 3px;
            border-radius: 999px;
            background: var(--register-gold);
        }

        .register-hero h1 {
            margin: 0;
            color: var(--register-navy);
            font-size: clamp(2rem, 4vw, 3rem);
            line-height: 1.05;
        }

        .register-hero p {
            margin: 12px 0 0;
            color: #5e7088;
            font-size: 1rem;
            line-height: 1.65;
        }

        .hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            flex: 0 0 auto;
            padding: 11px 14px;
            border: 1px solid rgba(20, 86, 160, .13);
            border-radius: 999px;
            background: rgba(255, 255, 255, .82);
            box-shadow: 0 8px 20px rgba(7, 29, 73, .05);
            color: var(--register-navy);
            font-size: .84rem;
            font-weight: 800;
        }

        .hero-badge i {
            color: var(--register-blue);
            font-size: 1rem;
        }

        .register-layout {
            display: grid;
            grid-template-columns: minmax(0, 1.4fr) minmax(300px, .8fr);
            gap: 22px;
            align-items: start;
        }

        .register-card,
        .register-side-card {
            border: 1px solid rgba(7, 29, 73, .07);
            border-radius: 22px;
            background: #fff;
            box-shadow: var(--register-shadow);
        }

        .register-card {
            overflow: hidden;
        }

        .register-card-header {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 24px 26px 18px;
            border-bottom: 1px solid var(--register-line);
        }

        .register-card-icon {
            display: grid;
            place-items: center;
            width: 46px;
            height: 46px;
            border-radius: 14px;
            background: #edf4fd;
            color: var(--register-blue);
            font-size: 1.35rem;
            flex: 0 0 auto;
        }

        .register-card-header h2 {
            margin: 0;
            color: var(--register-navy);
            font-size: 1.28rem;
        }

        .register-card-header p {
            margin: 5px 0 0;
            color: var(--register-muted);
            font-size: .9rem;
            line-height: 1.5;
        }

        .register-card-body {
            padding: 24px 26px 28px;
        }

        .intro-box {
            margin-bottom: 20px;
            padding: 16px 17px;
            border-left: 4px solid var(--register-gold);
            border-radius: 12px;
            background: #fff8e4;
            color: #5f6f84;
            font-size: .9rem;
            line-height: 1.65;
        }

        .intro-box strong {
            display: block;
            margin-bottom: 4px;
            color: var(--register-navy);
            font-size: .94rem;
        }

        .alert {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 18px;
            padding: 13px 15px;
            border-radius: 12px;
            font-size: .89rem;
            line-height: 1.5;
            font-weight: 700;
        }

        .alert i {
            margin-top: 1px;
            font-size: 1.05rem;
            flex: 0 0 auto;
        }

        .alert.error {
            border: 1px solid #f3d1d1;
            background: var(--register-danger-bg);
            color: var(--register-danger);
        }

        .alert.success {
            border: 1px solid #ccebd9;
            background: var(--register-success-bg);
            color: var(--register-success);
        }

        .reference-box {
            margin-top: 8px;
            padding: 12px 13px;
            border: 1px solid #d7e4f2;
            border-radius: 11px;
            background: var(--register-soft);
            color: #51667f;
            font-size: .8rem;
            line-height: 1.5;
            font-weight: 600;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .field {
            margin-bottom: 2px;
        }

        .field.full {
            grid-column: 1 / -1;
        }

        .field label {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            margin-bottom: 8px;
            color: var(--register-navy);
            font-size: .88rem;
            font-weight: 800;
        }

        .required {
            color: #8290a2;
            font-size: .74rem;
            font-weight: 600;
        }

        .field input,
        .field select {
            width: 100%;
            box-sizing: border-box;
            min-height: 48px;
            padding: 12px 14px;
            border: 1px solid #cdd9e7;
            border-radius: 12px;
            background: #fff;
            color: var(--register-ink);
            font: inherit;
            font-size: 16px;
            outline: none;
            transition: border-color .18s ease, box-shadow .18s ease;
        }

        .field input::placeholder {
            color: #9aa9ba;
        }

        .field select {
            cursor: pointer;
        }

        .field input:focus,
        .field select:focus {
            border-color: var(--register-blue-light);
            box-shadow: 0 0 0 4px rgba(20, 86, 160, .10);
        }

        .field-help {
            margin-top: 7px;
            color: #8090a4;
            font-size: .76rem;
            line-height: 1.45;
        }

        .submit-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            min-height: 52px;
            margin-top: 20px;
            padding: 14px 18px;
            border: 0;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--register-blue), var(--register-blue-light));
            box-shadow: 0 10px 22px rgba(20, 86, 160, .18);
            color: #fff;
            cursor: pointer;
            font: inherit;
            font-weight: 800;
            transition: transform .18s ease, box-shadow .18s ease;
        }

        .submit-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 14px 25px rgba(20, 86, 160, .22);
        }

        .signin-note {
            margin: 14px 0 0;
            text-align: center;
            color: #75869b;
            font-size: .82rem;
        }

        .signin-note a {
            color: var(--register-blue);
            font-weight: 800;
            text-decoration: none;
        }

        .signin-note a:hover {
            text-decoration: underline;
        }

        .side-stack {
            display: grid;
            gap: 18px;
        }

        .register-side-card {
            padding: 22px;
        }

        .register-side-card.dark {
            border-color: transparent;
            background: linear-gradient(135deg, var(--register-navy), var(--register-blue));
            color: #fff;
        }

        .side-label {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: var(--register-blue);
            font-size: .72rem;
            font-weight: 800;
            letter-spacing: .12em;
            text-transform: uppercase;
        }

        .dark .side-label {
            color: #ffe7a1;
        }

        .register-side-card h3 {
            margin: 8px 0 0;
            color: var(--register-navy);
            font-size: 1.12rem;
        }

        .dark h3 {
            color: #fff;
        }

        .register-side-card > p {
            margin: 8px 0 0;
            color: var(--register-muted);
            font-size: .82rem;
            line-height: 1.55;
        }

        .dark > p {
            color: rgba(255, 255, 255, .82);
        }

        .steps {
            display: grid;
            gap: 13px;
            margin-top: 16px;
        }

        .step {
            display: grid;
            grid-template-columns: 30px 1fr;
            gap: 10px;
            align-items: start;
        }

        .step-no {
            display: grid;
            place-items: center;
            width: 30px;
            height: 30px;
            border-radius: 10px;
            background: #edf4fd;
            color: var(--register-blue);
            font-size: .78rem;
            font-weight: 800;
        }

        .dark .step-no {
            background: rgba(255, 255, 255, .12);
            color: #ffe7a1;
        }

        .step strong {
            display: block;
            color: var(--register-navy);
            font-size: .85rem;
        }

        .dark .step strong {
            color: #fff;
        }

        .step span {
            display: block;
            margin-top: 3px;
            color: var(--register-muted);
            font-size: .78rem;
            line-height: 1.45;
        }

        .dark .step span {
            color: rgba(255, 255, 255, .72);
        }

        .side-note {
            display: flex;
            gap: 10px;
            margin-top: 16px;
            padding-top: 15px;
            border-top: 1px solid var(--register-line);
        }

        .side-note i {
            color: var(--register-blue);
            font-size: 1.15rem;
            flex: 0 0 auto;
        }

        .side-note p {
            margin: 0;
            color: #6e7e92;
            font-size: .77rem;
            line-height: 1.5;
        }

        .dark .side-note {
            border-top-color: rgba(255, 255, 255, .14);
        }

        .dark .side-note i {
            color: #ffe7a1;
        }

        .dark .side-note p {
            color: rgba(255, 255, 255, .72);
        }

        @media (max-width: 900px) {
            .register-hero {
                align-items: flex-start;
                flex-direction: column;
            }

            .register-layout {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 640px) {
            .register-page {
                padding: 24px 14px 52px;
            }

            .form-grid {
                grid-template-columns: 1fr;
                gap: 14px;
            }

            .field.full {
                grid-column: auto;
            }

            .register-card-header,
            .register-card-body,
            .register-side-card {
                padding-left: 18px;
                padding-right: 18px;
            }

            .register-hero h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <?php pascco_public_header('Sign In', 'login.php'); ?>

    <main class="register-page">
        <section class="register-hero">
            <div class="register-hero-content">
                <div class="eyebrow">Membership application</div>
                <h1>Join PASCCO</h1>
                <p>
                    Start your membership journey by submitting your basic information. PASCCO will contact you with available Pre-Membership Education Seminar (PMES) schedules before the next application stage.
                </p>
            </div>
        </section>

        <div class="register-layout">
            <section class="register-card" aria-labelledby="register-title">
                <div class="register-card-header">
                    <div class="register-card-icon">
                        <i class="bx bx-user-plus" aria-hidden="true"></i>
                    </div>
                    <div>
                        <h2 id="register-title">Apply for Membership</h2>
                        <p>Complete the form below to begin your PASCCO membership application.</p>
                    </div>
                </div>

                <div class="register-card-body">
                    <div class="intro-box">
                        <strong>Before you continue</strong>
                        PMES is the first step in the PASCCO membership process. It introduces applicants to the cooperative, its services, member responsibilities, and basic membership requirements.
                    </div>

                    <?php if ($error): ?>
                        <div class="alert error" role="alert">
                            <i class="bx bx-error-circle" aria-hidden="true"></i>
                            <div><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert success" role="status">
                            <i class="bx bx-check-circle" aria-hidden="true"></i>
                            <div>
                                <div><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></div>
                                <div class="reference-box">
                                    Save your application reference number. You will need it later when submitting your PMES certificate and membership documents.
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="register.php">
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"
                        >

                        <div class="form-grid">
                            <div class="field">
                                <label for="first-name">
                                    <span>First Name</span>
                                    <span class="required">Required</span>
                                </label>
                                <input
                                    id="first-name"
                                    type="text"
                                    name="first_name"
                                    value="<?php echo htmlspecialchars($first_name, ENT_QUOTES, 'UTF-8'); ?>"
                                    autocomplete="given-name"
                                    required
                                >
                            </div>

                            <div class="field">
                                <label for="last-name">
                                    <span>Last Name</span>
                                    <span class="required">Required</span>
                                </label>
                                <input
                                    id="last-name"
                                    type="text"
                                    name="last_name"
                                    value="<?php echo htmlspecialchars($last_name, ENT_QUOTES, 'UTF-8'); ?>"
                                    autocomplete="family-name"
                                    required
                                >
                            </div>

                            <div class="field">
                                <label for="email">
                                    <span>Email Address</span>
                                    <span class="required">Required</span>
                                </label>
                                <input
                                    id="email"
                                    type="email"
                                    name="email"
                                    value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
                                    autocomplete="email"
                                    placeholder="you@example.com"
                                    required
                                >
                            </div>

                            <div class="field">
                                <label for="phone">
                                    <span>Contact Number</span>
                                    <span class="required">Required</span>
                                </label>
                                <input
                                    id="phone"
                                    type="tel"
                                    name="phone"
                                    value="<?php echo htmlspecialchars($phone, ENT_QUOTES, 'UTF-8'); ?>"
                                    autocomplete="tel"
                                    placeholder="09XX XXX XXXX"
                                    required
                                >
                            </div>

                            <div class="field full">
                                <label for="address">
                                    <span>Complete Address</span>
                                    <span class="required">Required</span>
                                </label>
                                <input
                                    id="address"
                                    type="text"
                                    name="address"
                                    value="<?php echo htmlspecialchars($address, ENT_QUOTES, 'UTF-8'); ?>"
                                    autocomplete="street-address"
                                    required
                                >
                            </div>

                            <div class="field full">
                                <label for="preferred-mode">
                                    <span>Preferred PMES Mode</span>
                                    <span class="required">Required</span>
                                </label>
                                <select id="preferred-mode" name="preferred_mode" required>
                                    <option value="" disabled <?php echo $preferred_mode === '' ? 'selected' : ''; ?> hidden>
                                        Select preferred mode
                                    </option>
                                    <option
                                        value="face_to_face"
                                        <?php echo $preferred_mode === 'face_to_face' ? 'selected' : ''; ?>
                                    >
                                        Face-to-Face
                                    </option>
                                    <option
                                        value="online"
                                        <?php echo $preferred_mode === 'online' ? 'selected' : ''; ?>
                                    >
                                        Online
                                    </option>
                                    <option
                                        value="either"
                                        <?php echo $preferred_mode === 'either' ? 'selected' : ''; ?>
                                    >
                                        Either
                                    </option>
                                </select>
                                <div class="field-help">
                                    Choose the PMES format you prefer. PASCCO will coordinate available schedules with you.
                                </div>
                            </div>
                        <button type="submit" class="submit-btn">
                            <i class="bx bx-send" aria-hidden="true"></i>
                            Submit Membership Application
                        </button>
                    </form>

                    <p class="signin-note">
                        Already registered? <a href="login.php">Sign in to your account</a>
                    </p>
                </div>
            </section>

            <aside class="side-stack">
                <section class="register-side-card dark">
                    <div class="side-label"><i class="bx bx-list-check" aria-hidden="true"></i> Application steps</div>
                    <h3>From registration to membership</h3>
                    <p>Your application starts with a simple request and continues through PMES and the membership document stage.</p>

                    <div class="steps">
                        <div class="step">
                            <div class="step-no">01</div>
                            <div>
                                <strong>Submit your information</strong>
                                <span>Provide your contact details and preferred PMES mode.</span>
                            </div>
                        </div>
                        <div class="step">
                            <div class="step-no">02</div>
                            <div>
                                <strong>Attend PMES</strong>
                                <span>PASCCO contacts you with an available seminar schedule.</span>
                            </div>
                        </div>
                        <div class="step">
                            <div class="step-no">03</div>
                            <div>
                                <strong>Complete your requirements</strong>
                                <span>Proceed to the required membership documents and supporting information.</span>
                            </div>
                        </div>
                        <div class="step">
                            <div class="step-no">04</div>
                            <div>
                                <strong>Finish your membership application</strong>
                                <span>Continue through PASCCO's review and onboarding process.</span>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="register-side-card">
                    <div class="side-label"><i class="bx bx-info-circle" aria-hidden="true"></i> Helpful reminder</div>
                    <h3>Keep your reference number</h3>
                    <p>After submission, save your application reference number. It will help identify your membership application during the next steps.</p>

                    <div class="side-note">
                        <i class="bx bx-shield-quarter" aria-hidden="true"></i>
                        <p>Your application is submitted through the PASCCO member system and protected by the site's session and CSRF safeguards.</p>
                    </div>
                </section>
            </aside>
        </div>
    </main>

    <?php pascco_global_footer(); ?>
</body>
</html>
