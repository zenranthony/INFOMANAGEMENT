<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/vendor/autoload.php';

function sendPmesScheduleEmail(
    string $recipientEmail,
    string $applicantName,
    string $scheduleDate,
    string $scheduleTime,
    string $mode,
    string $location = '',
    string $meetingLink = ''
): bool {

    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();

        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        
        $mail->Username = 'renzpizza172@gmail.com';
        $mail->Password = 'mbotvfwxtvzfidxo';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom(
            'renzpizza172@gmail.com',
            'Paco Savings and Credit Cooperative'
        );

        $mail->addAddress(
            $recipientEmail,
            $applicantName
        );

        $mail->isHTML(true);

        $mail->Subject = 'PASCCO PMES Schedule';

        $safeName = htmlspecialchars($applicantName, ENT_QUOTES, 'UTF-8');
        $safeDate = htmlspecialchars($scheduleDate, ENT_QUOTES, 'UTF-8');
        $safeTime = htmlspecialchars($scheduleTime, ENT_QUOTES, 'UTF-8');
        $safeMode = htmlspecialchars($mode, ENT_QUOTES, 'UTF-8');

        $extra = '';

        $extra = '';

if ($mode === 'Online') {

    $safeLink = htmlspecialchars(
        $meetingLink,
        ENT_QUOTES,
        'UTF-8'
    );

    $extra = "
        <p>
            <strong>PMES Mode:</strong> Online
        </p>

        <p>
            <strong>Meeting Link:</strong><br>
            {$safeLink}
        </p>

        <p>
            Please join the online session a few minutes before
            the scheduled time and make sure you have a stable
            internet connection.
        </p>
    ";

} elseif (
    $mode === 'Onsite' ||
    $mode === 'Face-to-Face'
) {

    $safeLocation = htmlspecialchars(
        $location,
        ENT_QUOTES,
        'UTF-8'
    );

    $extra = "
        <p>
            <strong>PMES Mode:</strong> Onsite / Face-to-Face
        </p>

        <p>
            <strong>Venue:</strong><br>
            {$safeLocation}
        </p>

        <p>
            Please arrive at least 15 minutes before the scheduled
            seminar and bring a valid ID for verification.
        </p>
    ";
}

        $mail->Body = "
            <div style='font-family:Arial,sans-serif;max-width:600px;margin:auto;'>

                <h2 style='color:#071d49;'>
                    PASCCO PMES Schedule
                </h2>

                <p>Dear {$safeName},</p>

                <p>
                    Your PASCCO membership application has been received.
                    You are invited to attend the
                    <strong>Pre-Membership Education Seminar (PMES)</strong>.   <strong>ANG GWAPO NI RENZ LUMABI</strong>
                </p>

                <p>
                    <strong>Date:</strong> {$safeDate}<br>
                    <strong>Time:</strong> {$safeTime}<br>
                    <strong>Mode:</strong> {$safeMode}
                </p>

                {$extra}

                <p>
                    After completing the PMES, please keep your PMES certificate.
                    You will need to upload it together with the required
                    membership documents to continue your application.
                </p>

                <p>
                    Thank you,<br>
                    <strong>Paco Savings and Credit Cooperative</strong>
                </p>

            </div>
        ";

        $mail->AltBody =
            "PASCCO PMES Schedule\n\n" .
            "Dear {$applicantName},\n\n" .
            "Date: {$scheduleDate}\n" .
            "Time: {$scheduleTime}\n" .
            "Mode: {$mode}\n\n" .
            "Please keep your PMES certificate after the seminar.";

        $mail->send();

        return true;

    } catch (Exception $e) {

    echo '<pre>';
    echo 'Mailer Error: ' . htmlspecialchars($mail->ErrorInfo);
    echo '</pre>';

    return false;
    }
}
function sendMembershipApprovedEmail(
    string $recipientEmail,
    string $applicantName,
    string $username,
    string $temporaryPassword,
    string $memberNumber,
    string $accountNumber
): bool {

    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;

        $mail->Username = 'renzpizza172@gmail.com';
        $mail->Password = 'mbotvfwxtvzfidxo';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom(
            'renzpizza172@gmail.com',
            'Paco Savings and Credit Cooperative'
        );

        $mail->addAddress(
            $recipientEmail,
            $applicantName
        );

        $mail->isHTML(true);

        $mail->Subject = 'PASCCO Membership Approved';

        $safeName = htmlspecialchars($applicantName, ENT_QUOTES, 'UTF-8');
        $safeUsername = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
        $safePassword = htmlspecialchars($temporaryPassword, ENT_QUOTES, 'UTF-8');
        $safeMemberNumber = htmlspecialchars($memberNumber, ENT_QUOTES, 'UTF-8');
        $safeAccountNumber = htmlspecialchars($accountNumber, ENT_QUOTES, 'UTF-8');

        $mail->Body = "
            <div style='font-family:Arial,sans-serif;max-width:600px;margin:auto;'>

                <h2 style='color:#071d49;'>
                    PASCCO Membership Approved
                </h2>

                <p>Dear {$safeName},</p>

                <p>
                    Congratulations! Your PASCCO membership application
                    has been approved.
                </p>

                <p>
                    Your member portal account has been created.
                    Please use the credentials below to sign in.
                </p>

                <div style='
                    background:#f4f7fb;
                    border-left:4px solid #e7b84b;
                    padding:16px;
                    margin:20px 0;
                '>

                    <p>
                        <strong>Username:</strong>
                        {$safeUsername}
                    </p>

                    <p>
                        <strong>Temporary Password:</strong>
                        {$safePassword}
                    </p>

                    <p>
                        <strong>Member Number:</strong>
                        {$safeMemberNumber}
                    </p>

                    <p>
                        <strong>Savings Account Number:</strong>
                        {$safeAccountNumber}
                    </p>

                </div>

                <p>
                    Please change your temporary password after signing in.
                </p>

                <p>
                    Thank you,<br>
                    <strong>Paco Savings and Credit Cooperative</strong>
                </p>

            </div>
        ";

        $mail->AltBody =
            "PASCCO Membership Approved\n\n" .
            "Dear {$applicantName},\n\n" .
            "Username: {$username}\n" .
            "Temporary Password: {$temporaryPassword}\n" .
            "Member Number: {$memberNumber}\n" .
            "Savings Account Number: {$accountNumber}\n";

        $mail->send();

        return true;

    } catch (Exception $e) {

        error_log(
            'Membership approval email error: ' .
            $mail->ErrorInfo
        );

        return false;
    }
}

function sendMemberLoginOtpEmail(
    string $recipientEmail,
    string $username,
    string $otp
): bool {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;

        // Reuse the same working PASCCO Gmail SMTP account used by the other emails.
        $mail->Username = 'renzpizza172@gmail.com';
        $mail->Password = 'mbotvfwxtvzfidxo';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom(
            'renzpizza172@gmail.com',
            'Paco Savings and Credit Cooperative'
        );
        $mail->addAddress($recipientEmail, $username);
        $mail->isHTML(true);
        $mail->Subject = 'PASCCO Member Login Verification Code';

        $safeUsername = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
        $safeOtp = htmlspecialchars($otp, ENT_QUOTES, 'UTF-8');

        $mail->Body = "
            <div style='margin:0;padding:0;background:#f4f7fb;font-family:Arial,sans-serif;color:#1f2a44;'>
                <div style='max-width:620px;margin:0 auto;padding:30px 18px;'>
                    <div style='background:#0b2c6a;color:#ffffff;padding:22px 26px;border-radius:12px 12px 0 0;'>
                        <h2 style='margin:0;font-size:27px;font-weight:700;'>PASCCO Login Verification</h2>
                        <p style='margin:7px 0 0;font-size:14px;color:#dbe8fb;'>Member Portal Security Check</p>
                    </div>
                    <div style='background:#ffffff;border:1px solid #d7e0ec;border-top:none;border-radius:0 0 12px 12px;padding:30px 28px;'>
                        <p style='margin:0 0 18px;font-size:16px;line-height:1.65;'>Dear {$safeUsername},</p>
                        <p style='margin:0 0 22px;font-size:16px;line-height:1.65;'>Use the verification code below to continue signing in to your PASCCO Member Portal account.</p>
                        <div style='background:#f5f8fc;border:1px solid #d7e0ec;border-radius:10px;padding:22px 16px;text-align:center;margin:22px 0 24px;'>
                            <div style='font-size:13px;color:#64748b;margin-bottom:10px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;'>Verification Code</div>
                            <div style='font-size:34px;font-weight:700;color:#0b2c6a;letter-spacing:9px;'>{$safeOtp}</div>
                        </div>
                        <p style='margin:0 0 10px;font-size:15px;line-height:1.6;color:#4b5b72;'>This code expires in <strong>5 minutes</strong>.</p>
                        <p style='margin:0 0 22px;font-size:15px;line-height:1.6;color:#4b5b72;'>If you did not try to sign in, you may ignore this message.</p>
                        <hr style='border:none;border-top:1px solid #e2e8f0;margin:22px 0;'>
                        <p style='margin:0;font-size:14px;line-height:1.6;color:#6b778c;'>Thank you,<br><strong style='color:#0b2c6a;'>Paco Savings and Credit Cooperative</strong></p>
                    </div>
                </div>
            </div>
        ";

        $mail->AltBody =
            "PASCCO Login Verification\n\n" .
            "Dear {$username},\n\n" .
            "Verification Code: {$otp}\n\n" .
            "This code expires in 5 minutes.\n" .
            "If you did not try to sign in, you may ignore this message.";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Member OTP email error: ' . $mail->ErrorInfo);
        return false;
    }
}
