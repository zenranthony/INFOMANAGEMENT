<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/vendor/autoload.php';

function sendPmesScheduleEmail(
    string $recipientEmail,
    string $applicantName,
    string $scheduleDate,
    string $scheduleTime,
    string $mode,
    string $location = '',
    string $meetingLink = ''
): bool {

    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();

        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        
        $mail->Username = 'renzpizza172@gmail.com';
        $mail->Password = 'mbotvfwxtvzfidxo';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom(
            'renzpizza172@gmail.com',
            'Paco Savings and Credit Cooperative'
        );

        $mail->addAddress(
            $recipientEmail,
            $applicantName
        );

        $mail->isHTML(true);

        $mail->Subject = 'PASCCO PMES Schedule';

        $safeName = htmlspecialchars($applicantName, ENT_QUOTES, 'UTF-8');
        $safeDate = htmlspecialchars($scheduleDate, ENT_QUOTES, 'UTF-8');
        $safeTime = htmlspecialchars($scheduleTime, ENT_QUOTES, 'UTF-8');
        $safeMode = htmlspecialchars($mode, ENT_QUOTES, 'UTF-8');

        $extra = '';

        $extra = '';

if ($mode === 'Online') {

    $safeLink = htmlspecialchars(
        $meetingLink,
        ENT_QUOTES,
        'UTF-8'
    );

    $extra = "
        <p>
            <strong>PMES Mode:</strong> Online
        </p>

        <p>
            <strong>Meeting Link:</strong><br>
            {$safeLink}
        </p>

        <p>
            Please join the online session a few minutes before
            the scheduled time and make sure you have a stable
            internet connection.
        </p>
    ";

} elseif (
    $mode === 'Onsite' ||
    $mode === 'Face-to-Face'
) {

    $safeLocation = htmlspecialchars(
        $location,
        ENT_QUOTES,
        'UTF-8'
    );

    $extra = "
        <p>
            <strong>PMES Mode:</strong> Onsite / Face-to-Face
        </p>

        <p>
            <strong>Venue:</strong><br>
            {$safeLocation}
        </p>

        <p>
            Please arrive at least 15 minutes before the scheduled
            seminar and bring a valid ID for verification.
        </p>
    ";
}

        $mail->Body = "
            <div style='font-family:Arial,sans-serif;max-width:600px;margin:auto;'>

                <h2 style='color:#071d49;'>
                    PASCCO PMES Schedule
                </h2>

                <p>Dear {$safeName},</p>

                <p>
                    Your PASCCO membership application has been received.
                    You are invited to attend the
                    <strong>Pre-Membership Education Seminar (PMES)</strong>.
                </p>

                <p>
                    <strong>Date:</strong> {$safeDate}<br>
                    <strong>Time:</strong> {$safeTime}<br>
                    <strong>Mode:</strong> {$safeMode}
                </p>

                {$extra}

                <p>
                    After completing the PMES, please keep your PMES certificate.
                    You will need to upload it together with the required
                    membership documents to continue your application.
                </p>

                <p>
                    Thank you,<br>
                    <strong>Paco Savings and Credit Cooperative</strong>
                </p>

            </div>
        ";

        $mail->AltBody =
            "PASCCO PMES Schedule\n\n" .
            "Dear {$applicantName},\n\n" .
            "Date: {$scheduleDate}\n" .
            "Time: {$scheduleTime}\n" .
            "Mode: {$mode}\n\n" .
            "Please keep your PMES certificate after the seminar.";

        $mail->send();

        return true;

    } catch (Exception $e) {

    echo '<pre>';
    echo 'Mailer Error: ' . htmlspecialchars($mail->ErrorInfo);
    echo '</pre>';

    return false;
    }
}
function sendMembershipApprovedEmail(
    string $recipientEmail,
    string $applicantName,
    string $username,
    string $temporaryPassword,
    string $memberNumber,
    string $accountNumber
): bool {

    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;

        $mail->Username = 'renzpizza172@gmail.com';
        $mail->Password = 'mbotvfwxtvzfidxo';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom(
            'renzpizza172@gmail.com',
            'Paco Savings and Credit Cooperative'
        );

        $mail->addAddress(
            $recipientEmail,
            $applicantName
        );

        $mail->isHTML(true);

        $mail->Subject = 'PASCCO Membership Approved';

        $safeName = htmlspecialchars($applicantName, ENT_QUOTES, 'UTF-8');
        $safeUsername = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
        $safePassword = htmlspecialchars($temporaryPassword, ENT_QUOTES, 'UTF-8');
        $safeMemberNumber = htmlspecialchars($memberNumber, ENT_QUOTES, 'UTF-8');
        $safeAccountNumber = htmlspecialchars($accountNumber, ENT_QUOTES, 'UTF-8');

        $mail->Body = "
            <div style='font-family:Arial,sans-serif;max-width:600px;margin:auto;'>

                <h2 style='color:#071d49;'>
                    PASCCO Membership Approved
                </h2>

                <p>Dear {$safeName},</p>

                <p>
                    Congratulations! Your PASCCO membership application
                    has been approved.
                </p>

                <p>
                    Your member portal account has been created.
                    Please use the credentials below to sign in.
                </p>

                <div style='
                    background:#f4f7fb;
                    border-left:4px solid #e7b84b;
                    padding:16px;
                    margin:20px 0;
                '>

                    <p>
                        <strong>Username:</strong>
                        {$safeUsername}
                    </p>

                    <p>
                        <strong>Temporary Password:</strong>
                        {$safePassword}
                    </p>

                    <p>
                        <strong>Member Number:</strong>
                        {$safeMemberNumber}
                    </p>

                    <p>
                        <strong>Savings Account Number:</strong>
                        {$safeAccountNumber}
                    </p>

                </div>

                <p>
                    Please change your temporary password after signing in.
                </p>

                <p>
                    Thank you,<br>
                    <strong>Paco Savings and Credit Cooperative</strong>
                </p>

            </div>
        ";

        $mail->AltBody =
            "PASCCO Membership Approved\n\n" .
            "Dear {$applicantName},\n\n" .
            "Username: {$username}\n" .
            "Temporary Password: {$temporaryPassword}\n" .
            "Member Number: {$memberNumber}\n" .
            "Savings Account Number: {$accountNumber}\n";

        $mail->send();

        return true;

    } catch (Exception $e) {

        error_log(
            'Membership approval email error: ' .
            $mail->ErrorInfo
        );

        return false;
    }
}

function sendMemberLoginOtpEmail(
    string $recipientEmail,
    string $username,
    string $otp
): bool {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;

        // Reuse the same working PASCCO Gmail SMTP account used by the other emails.
        $mail->Username = 'renzpizza172@gmail.com';
        $mail->Password = 'mbotvfwxtvzfidxo';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom(
            'renzpizza172@gmail.com',
            'Paco Savings and Credit Cooperative'
        );
        $mail->addAddress($recipientEmail, $username);
        $mail->isHTML(true);
        $mail->Subject = 'PASCCO Member Login Verification Code';

        $safeUsername = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
        $safeOtp = htmlspecialchars($otp, ENT_QUOTES, 'UTF-8');

        $mail->Body = "
            <div style='font-family:Arial,sans-serif;max-width:600px;margin:auto;'>
                <h2 style='color:#071d49;'>PASCCO Login Verification</h2>
                <p>Dear {$safeUsername},</p>
                <p>Use the verification code below to continue signing in to your PASCCO Member Portal.</p>
                <div style='margin:24px 0;padding:18px;border-left:4px solid #e7b84b;background:#f4f7fb;text-align:center;'>
                    <div style='font-size:30px;font-weight:700;letter-spacing:8px;color:#071d49;'>{$safeOtp}</div>
                </div>
                <p>This code expires in <strong>5 minutes</strong>. Do not share it with anyone.</p>
                <p>If you did not try to sign in, you can ignore this email.</p>
                <p>Thank you,<br><strong>Paco Savings and Credit Cooperative</strong></p>
            </div>
        ";

        $mail->AltBody =
            "PASCCO Login Verification\n\n" .
            "Username: {$username}\n" .
            "Verification Code: {$otp}\n\n" .
            "This code expires in 5 minutes. Do not share it with anyone.";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Member OTP email error: ' . $mail->ErrorInfo);
        return false;
    }
}

function sendPasswordResetEmail(
    string $recipientEmail,
    string $username,
    string $resetUrl
): bool {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'renzpizza172@gmail.com';
        $mail->Password = 'mbotvfwxtvzfidxo';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('renzpizza172@gmail.com', 'Paco Savings and Credit Cooperative');
        $mail->addAddress($recipientEmail, $username);
        $mail->isHTML(true);
        $mail->Subject = 'PASCCO Password Reset';

        $safeUsername = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
        $safeUrl = htmlspecialchars($resetUrl, ENT_QUOTES, 'UTF-8');

        $mail->Body = "
            <div style='margin:0;padding:0;background:#f4f7fb;font-family:Arial,sans-serif;color:#1f2a44;'>
                <div style='max-width:620px;margin:0 auto;padding:30px 18px;'>
                    <div style='background:#0b2c6a;color:#ffffff;padding:22px 26px;border-radius:12px 12px 0 0;'>
                        <h2 style='margin:0;font-size:27px;'>PASCCO Password Reset</h2>
                    </div>
                    <div style='background:#ffffff;border:1px solid #d7e0ec;border-top:none;border-radius:0 0 12px 12px;padding:30px 28px;'>
                        <p>Dear {$safeUsername},</p>
                        <p>We received a request to reset your PASCCO Member Portal password.</p>
                        <p style='margin:26px 0;'>
                            <a href='{$safeUrl}' style='display:inline-block;padding:13px 22px;background:#1456a0;color:#ffffff;text-decoration:none;border-radius:8px;font-weight:700;'>Reset Password</a>
                        </p>
                        <p>This link expires in <strong>30 minutes</strong> and can only be used once.</p>
                        <p>If you did not request this change, you can ignore this email.</p>
                        <p>Thank you,<br><strong>Paco Savings and Credit Cooperative</strong></p>
                    </div>
                </div>
            </div>
        ";

        $mail->AltBody =
            "PASCCO Password Reset\n\n" .
            "Username: {$username}\n\n" .
            "Reset your password using this link:\n{$resetUrl}\n\n" .
            "This link expires in 30 minutes and can only be used once.";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Password reset email error: ' . $mail->ErrorInfo);
        return false;
    }
}
