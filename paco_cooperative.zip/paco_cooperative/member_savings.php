<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') {
    header('Location: login.php');
    exit;
}

$user_id = (int) $_SESSION['user_id'];

$account_stmt = $pdo->prepare("
    SELECT a.id AS account_id, a.account_number, a.account_type, a.balance, a.status
    FROM members m
    JOIN accounts a ON a.member_id = m.id
    WHERE m.user_id = ? AND a.status = 'active'
    ORDER BY a.id
");
$account_stmt->execute([$user_id]);
$accounts = $account_stmt->fetchAll();

$selected_account_id = (int) ($_GET['account_id'] ?? ($accounts[0]['account_id'] ?? 0));
$selected_account = null;

foreach ($accounts as $account) {
    if ((int) $account['account_id'] === $selected_account_id) {
        $selected_account = $account;
        break;
    }
}

if (!$selected_account && $accounts) {
    $selected_account = $accounts[0];
    $selected_account_id = (int) $selected_account['account_id'];
}

$from_date = trim($_GET['from'] ?? '');
$to_date = trim($_GET['to'] ?? '');
$transaction_type = trim($_GET['type'] ?? '');
$transactions = [];

if ($selected_account) {
    $conditions = ['account_id = ?'];
    $parameters = [(int) $selected_account['account_id']];

    if ($from_date !== '' && DateTime::createFromFormat('Y-m-d', $from_date)) {
        $conditions[] = 'FROM_UNIXTIME(created_at) >= ?';
        $parameters[] = $from_date . ' 00:00:00';
    }

    if ($to_date !== '' && DateTime::createFromFormat('Y-m-d', $to_date)) {
        $conditions[] = 'FROM_UNIXTIME(created_at) <= ?';
        $parameters[] = $to_date . ' 23:59:59';
    }

    if (in_array($transaction_type, ['deposit', 'withdrawal', 'transfer'], true)) {
        $conditions[] = 'transaction_type = ?';
        $parameters[] = $transaction_type;
    }

    $history_stmt = $pdo->prepare("
        SELECT transaction_type, amount, description, reference_number, created_at
        FROM transactions
        WHERE " . implode(' AND ', $conditions) . "
        ORDER BY id DESC
        LIMIT 500
    ");

    $history_stmt->execute($parameters);
    $transactions = $history_stmt->fetchAll();

    if (($_GET['download'] ?? '') === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="pascco-statement-' . $selected_account['account_number'] . '.csv"');

        $output = fopen('php://output', 'w');

        fputcsv($output, [
            'Reference',
            'Type',
            'Amount',
            'Description',
            'Date'
        ]);

        foreach ($transactions as $transaction) {
            fputcsv($output, [
                $transaction['reference_number'],
                $transaction['transaction_type'],
                $transaction['amount'],
                $transaction['description'],
                date('Y-m-d H:i', (int) $transaction['created_at'])
            ]);
        }

        fclose($output);
        exit;
    }
}

$from_query = urlencode($from_date);
$to_query = urlencode($to_date);
$type_query = urlencode($transaction_type);
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php pascco_global_styles(); ?>

    <title>My Savings | PASCCO</title>

    <link rel="stylesheet" href="member-panels.css?v=4">

    <style>
        :root{--navy:#071d49;--blue:#1456a0;--gold:#f4c542;--ink:#17243a;--muted:#6d7c91;--line:#dfe7f0;--panel:#ffffff;--canvas:#f4f7fb;--soft:#eef4fb;--success:#14804a;--danger:#b23b3b}
        html,body{margin:0;padding:0;min-height:100%}
        *,*::before,*::after{box-sizing:border-box}
        body{background:var(--canvas);color:var(--ink)}
        .pascco-global-header{width:100%;margin:0;box-sizing:border-box}
        .savings-page{width:min(1180px,calc(100% - 32px));margin:0 auto;padding:34px 0 64px}
        .savings-welcome{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:24px}
        .savings-eyebrow{margin:0 0 7px;color:var(--blue);font-size:.72rem;font-weight:900;letter-spacing:.15em;text-transform:uppercase}
        .savings-welcome h1{margin:0;color:var(--navy);font-size:clamp(1.7rem,3vw,2.15rem);line-height:1.15}
        .savings-welcome p{margin:8px 0 0;color:var(--muted)}
        .savings-back,.history-action{display:inline-flex;align-items:center;justify-content:center;gap:7px;text-decoration:none;font-weight:800;transition:transform .18s,border-color .18s,background .18s,color .18s}
        .savings-back{min-height:42px;padding:0 15px;border:1px solid var(--line);border-radius:10px;background:#fff;color:var(--navy)}
        .savings-back:hover{transform:translateY(-1px);border-color:var(--blue);color:var(--blue)}
        .savings-main-grid{display:grid;grid-template-columns:minmax(0,1.45fr) minmax(300px,.55fr);gap:18px;margin-bottom:22px}
        .savings-balance{position:relative;min-height:260px;overflow:hidden;padding:28px;border-radius:20px;background:linear-gradient(135deg,var(--navy),var(--blue));color:#fff;box-shadow:0 18px 40px rgba(7,29,73,.16)}
        .savings-balance::before,.savings-balance::after{content:"";position:absolute;border-radius:50%;pointer-events:none;background:rgba(255,255,255,.07)}
        .savings-balance::before{width:260px;height:260px;right:-95px;top:-110px}.savings-balance::after{width:170px;height:170px;right:80px;bottom:-110px}
        .savings-balance-content{position:relative;z-index:1}.savings-balance-label{font-size:.72rem;font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:#d9e7fb}
        .savings-balance h2{margin:24px 0 12px;font-size:clamp(2.25rem,5vw,3.15rem);line-height:1;letter-spacing:-.04em}
        .savings-account-number{display:flex;align-items:center;gap:8px;color:#d9e7fb;font-size:.9rem}.savings-type{display:inline-flex;margin-top:24px;padding:7px 11px;border:1px solid rgba(244,197,66,.6);border-radius:999px;background:rgba(244,197,66,.12);color:var(--gold);font-size:.75rem;font-weight:900}
        .savings-summary,.savings-history,.savings-account-card{background:var(--panel);border:1px solid var(--line);box-shadow:0 10px 28px rgba(15,39,72,.055)}
        .savings-summary{border-radius:20px;padding:22px}.savings-summary-title{display:flex;align-items:center;gap:10px;margin-bottom:12px;color:var(--navy);font-weight:900}
        .savings-summary-title i,.history-icon,.account-card-icon{display:grid;place-items:center;background:var(--soft);color:var(--blue)}
        .savings-summary-title i{width:34px;height:34px;border-radius:10px;font-size:19px}.summary-row{display:flex;justify-content:space-between;gap:16px;padding:14px 0;border-bottom:1px solid #edf1f6}.summary-row:last-child{border-bottom:0}.summary-label{color:var(--muted);font-size:.8rem}.summary-value{color:var(--ink);font-size:.84rem;font-weight:900;text-align:right}
        .accounts-section{margin-bottom:22px}.section-heading{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:12px}.section-heading h2{margin:0;color:var(--navy);font-size:1.12rem}.section-heading span{color:var(--muted);font-size:.8rem}
        .savings-account-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.savings-account-card{position:relative;display:block;padding:18px;border-radius:16px;color:inherit;text-decoration:none;transition:transform .18s,border-color .18s,box-shadow .18s}.savings-account-card:hover{transform:translateY(-2px);border-color:#b8c9df;box-shadow:0 14px 30px rgba(15,39,72,.08)}.savings-account-card.selected{border:2px solid var(--blue);padding:17px}.account-card-top{display:flex;align-items:center;justify-content:space-between}.account-card-icon{width:40px;height:40px;border-radius:11px;font-size:20px}.account-card-check{color:var(--blue);font-size:21px}.savings-account-card h3{margin:15px 0 5px;color:var(--navy);font-size:.95rem}.savings-account-card small{display:block;color:var(--muted);font-size:.76rem}.savings-account-card strong{display:block;margin-top:15px;color:var(--blue);font-size:1.18rem}
        .savings-history{border-radius:20px;overflow:hidden}.history-header{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:22px 24px;border-bottom:1px solid #edf1f6}.history-title{display:flex;align-items:center;gap:12px}.history-icon{width:42px;height:42px;border-radius:12px;font-size:21px}.history-title h2{margin:0;color:var(--navy);font-size:1.1rem}.history-title p{margin:4px 0 0;color:var(--muted);font-size:.78rem}.history-actions{display:flex;flex-wrap:wrap;gap:8px}.history-action{min-height:40px;padding:0 12px;border:1px solid #d7e0ec;border-radius:9px;background:#fff;color:var(--navy);font-size:.77rem}.history-action:hover{border-color:var(--blue);color:var(--blue)}.history-action.primary{border-color:var(--blue);background:var(--blue);color:#fff}.history-action.primary:hover{background:var(--navy);border-color:var(--navy);color:var(--gold)}
        .savings-filter{display:grid;grid-template-columns:repeat(3,minmax(0,1fr)) auto;gap:12px;padding:18px 24px;background:#f8fafd;border-bottom:1px solid #edf1f6}.filter-field{display:flex;flex-direction:column;gap:6px}.filter-field label{color:#52627a;font-size:.73rem;font-weight:900}.filter-field input,.filter-field select{width:100%;min-height:42px;padding:0 11px;border:1px solid #d7e0ec;border-radius:9px;background:#fff;color:var(--ink);font:inherit;font-size:.82rem;outline:0}.filter-field input:focus,.filter-field select:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(20,86,160,.09)}.filter-button{align-self:end;min-height:42px;padding:0 18px;border:0;border-radius:9px;background:var(--navy);color:#fff;font:inherit;font-size:.8rem;font-weight:900;cursor:pointer}.filter-button:hover{background:var(--blue);color:var(--gold)}
        .transaction-table-wrap{width:100%;overflow:auto}.savings-table{width:100%;min-width:760px;border-collapse:collapse}.savings-table th{padding:13px 18px;background:#f5f8fc;color:#65758d;text-align:left;font-size:.69rem;font-weight:900;letter-spacing:.06em;text-transform:uppercase;border-bottom:1px solid #e6ecf3}.savings-table td{padding:15px 18px;color:#334155;font-size:.8rem;border-bottom:1px solid #edf1f6;vertical-align:middle}.savings-table tbody tr:hover{background:#fbfcfe}.transaction-reference{color:var(--navy)!important;font-weight:900!important;font-size:.74rem!important}.transaction-description{color:#52627a!important}.transaction-date{white-space:nowrap;color:var(--muted)!important}.transaction-type-badge{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:.66rem;font-weight:900;text-transform:uppercase}.transaction-type-badge.deposit{background:#eaf7ef;color:var(--success)}.transaction-type-badge.withdrawal,.transaction-type-badge.transfer{background:#fff0f0;color:var(--danger)}.transaction-amount{font-weight:900!important;white-space:nowrap}.transaction-amount.deposit{color:var(--success)!important}.transaction-amount.withdrawal,.transaction-amount.transfer{color:var(--danger)!important}
        .empty-savings{padding:52px 20px;text-align:center;color:var(--muted)}.empty-savings i{display:grid;place-items:center;width:58px;height:58px;margin:0 auto 14px;border-radius:16px;background:var(--soft);color:var(--blue);font-size:27px}.empty-savings h3{margin:0 0 6px;color:var(--navy);font-size:1rem}.empty-savings p{margin:0;font-size:.82rem}
        @media(max-width:900px){.savings-main-grid{grid-template-columns:1fr}.savings-filter{grid-template-columns:repeat(2,1fr)}.filter-button{width:100%}}
        @media(max-width:700px){.savings-page{width:min(100% - 24px,1180px);padding:28px 0 52px}.savings-welcome{align-items:stretch;flex-direction:column}.savings-back{width:100%}.history-header{align-items:flex-start;flex-direction:column}.history-actions{width:100%}.history-action{flex:1}.savings-balance{min-height:230px;padding:24px}}
        @media(max-width:520px){.savings-filter{grid-template-columns:1fr;padding:16px}.filter-button{width:100%}.history-header{padding:18px}.savings-table th,.savings-table td{padding:12px}}
    </style>
</head>

<body>

<?php pascco_member_header('My Savings'); ?>

<main class="savings-page member-content">

    <section class="savings-welcome">
        <div>
            <div class="savings-eyebrow">Member Accounts</div>
            <h1>My Savings</h1>
            <p>View your savings accounts and monitor your transaction history.</p>
        </div>

        <a href="dashboard.php" class="savings-back">
            <i class="bx bx-arrow-back"></i>
            Back to Dashboard
        </a>
    </section>

    <?php if ($accounts && $selected_account): ?>

        <section class="savings-main-grid">

            <article class="savings-balance">
                <div class="savings-balance-content">
                    <div class="savings-balance-label">Available Balance</div>

                    <h2>₱<?php echo number_format((float) $selected_account['balance'], 2); ?></h2>

                    <div class="savings-account-number">
                        <i class="bx bx-credit-card"></i>
                        <span><?php echo htmlspecialchars($selected_account['account_number'], ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>

                    <span class="savings-type">
                        <?php echo htmlspecialchars($selected_account['account_type'], ENT_QUOTES, 'UTF-8'); ?>
                    </span>
                </div>
            </article>

            <article class="savings-summary">

                <div class="savings-summary-title">
                    <i class="bx bx-wallet"></i>
                    Account Information
                </div>

                <div class="summary-row">
                    <span class="summary-label">Account Type</span>
                    <span class="summary-value">
                        <?php echo htmlspecialchars($selected_account['account_type'], ENT_QUOTES, 'UTF-8'); ?>
                    </span>
                </div>

                <div class="summary-row">
                    <span class="summary-label">Account Number</span>
                    <span class="summary-value">
                        <?php echo htmlspecialchars($selected_account['account_number'], ENT_QUOTES, 'UTF-8'); ?>
                    </span>
                </div>

                <div class="summary-row">
                    <span class="summary-label">Status</span>
                    <span class="summary-value">Active</span>
                </div>

                <div class="summary-row">
                    <span class="summary-label">Transactions Shown</span>
                    <span class="summary-value"><?php echo number_format(count($transactions)); ?></span>
                </div>

            </article>

        </section>

        <section class="accounts-section">

            <div class="section-heading">
                <h2>Your Savings Accounts</h2>
                <span><?php echo count($accounts); ?> active account<?php echo count($accounts) !== 1 ? 's' : ''; ?></span>
            </div>

            <div class="savings-account-grid">

                <?php foreach ($accounts as $available_account): ?>

                    <?php $is_selected = (int) $available_account['account_id'] === $selected_account_id; ?>

                    <a
                        href="member_savings.php?account_id=<?php echo (int) $available_account['account_id']; ?>"
                        class="savings-account-card <?php echo $is_selected ? 'selected' : ''; ?>"
                    >

                        <div class="account-card-top">

                            <div class="account-card-icon">
                                <i class="bx bx-wallet"></i>
                            </div>

                            <?php if ($is_selected): ?>
                                <i class="bx bx-check-circle account-card-check"></i>
                            <?php endif; ?>

                        </div>

                        <h3>
                            <?php echo htmlspecialchars($available_account['account_type'], ENT_QUOTES, 'UTF-8'); ?>
                        </h3>

                        <small>
                            <?php echo htmlspecialchars($available_account['account_number'], ENT_QUOTES, 'UTF-8'); ?>
                        </small>

                        <strong>
                            ₱<?php echo number_format((float) $available_account['balance'], 2); ?>
                        </strong>

                    </a>

                <?php endforeach; ?>

            </div>

        </section>

        <section class="savings-history">

            <div class="history-header">

                <div class="history-title">

                    <div class="history-icon">
                        <i class="bx bx-history"></i>
                    </div>

                    <div>
                        <h2>Transaction History</h2>
                        <p>
                            <?php echo htmlspecialchars($selected_account['account_type'], ENT_QUOTES, 'UTF-8'); ?>
                            · <?php echo htmlspecialchars($selected_account['account_number'], ENT_QUOTES, 'UTF-8'); ?>
                        </p>
                    </div>

                </div>

                <div class="history-actions">

                    <a
                        href="statement.php?account_id=<?php echo (int) $selected_account['account_id']; ?>&from=<?php echo $from_query; ?>&to=<?php echo $to_query; ?>&type=<?php echo $type_query; ?>"
                        target="_blank"
                        rel="noopener"
                        class="history-action primary"
                    >
                        <i class="bx bx-printer"></i>
                        Print / Save PDF
                    </a>

                    <a
                        href="member_savings.php?account_id=<?php echo (int) $selected_account['account_id']; ?>&from=<?php echo $from_query; ?>&to=<?php echo $to_query; ?>&type=<?php echo $type_query; ?>&download=csv"
                        class="history-action"
                    >
                        <i class="bx bx-download"></i>
                        Download CSV
                    </a>

                </div>

            </div>

            <form method="GET" class="savings-filter">

                <input
                    type="hidden"
                    name="account_id"
                    value="<?php echo (int) $selected_account['account_id']; ?>"
                >

                <div class="filter-field">
                    <label for="from-date">From Date</label>
                    <input
                        id="from-date"
                        type="date"
                        name="from"
                        value="<?php echo htmlspecialchars($from_date, ENT_QUOTES, 'UTF-8'); ?>"
                    >
                </div>

                <div class="filter-field">
                    <label for="to-date">To Date</label>
                    <input
                        id="to-date"
                        type="date"
                        name="to"
                        value="<?php echo htmlspecialchars($to_date, ENT_QUOTES, 'UTF-8'); ?>"
                    >
                </div>

                <div class="filter-field">
                    <label for="transaction-type">Transaction Type</label>

                    <select id="transaction-type" name="type">

                        <option value="">All Transactions</option>

                        <option value="deposit" <?php echo $transaction_type === 'deposit' ? 'selected' : ''; ?>>
                            Deposits
                        </option>

                        <option value="withdrawal" <?php echo $transaction_type === 'withdrawal' ? 'selected' : ''; ?>>
                            Withdrawals
                        </option>

                        <option value="transfer" <?php echo $transaction_type === 'transfer' ? 'selected' : ''; ?>>
                            Transfers
                        </option>

                    </select>
                </div>

                <button type="submit" class="filter-button">
                    <i class="bx bx-filter-alt"></i>
                    Filter
                </button>

            </form>

            <?php if ($transactions): ?>

                <div class="transaction-table-wrap">

                    <table class="savings-table">

                        <thead>
                            <tr>
                                <th>Reference</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Description</th>
                                <th>Date</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php foreach ($transactions as $transaction): ?>

                            <?php
                            $tx_type = strtolower((string) $transaction['transaction_type']);
                            $tx_class = in_array($tx_type, ['deposit', 'withdrawal', 'transfer'], true) ? $tx_type : '';
                            $is_deposit = $tx_type === 'deposit';
                            ?>

                            <tr>

                                <td class="transaction-reference">
                                    <?php echo htmlspecialchars($transaction['reference_number'], ENT_QUOTES, 'UTF-8'); ?>
                                </td>

                                <td>
                                    <span class="transaction-type-badge <?php echo $tx_class; ?>">
                                        <?php echo strtoupper(htmlspecialchars($transaction['transaction_type'], ENT_QUOTES, 'UTF-8')); ?>
                                    </span>
                                </td>

                                <td class="transaction-amount <?php echo $tx_class; ?>">
                                    <?php echo $is_deposit ? '+' : '-'; ?>₱<?php echo number_format((float) $transaction['amount'], 2); ?>
                                </td>

                                <td class="transaction-description">
                                    <?php echo htmlspecialchars($transaction['description'], ENT_QUOTES, 'UTF-8'); ?>
                                </td>

                                <td class="transaction-date">
                                    <?php echo date('M d, Y · h:i A', (int) $transaction['created_at']); ?>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php else: ?>

                <div class="empty-savings">
                    <i class="bx bx-receipt"></i>
                    <h3>No Transactions Found</h3>
                    <p>No transactions match the selected filters for this savings account.</p>
                </div>

            <?php endif; ?>

        </section>

    <?php else: ?>

        <section class="savings-history">

            <div class="empty-savings">
                <i class="bx bx-wallet-alt"></i>
                <h3>No Active Savings Accounts</h3>
                <p>You currently do not have an active savings account.</p>
            </div>

        </section>

    <?php endif; ?>

</main>

<?php pascco_global_footer(); ?>

<script src="animated-button.js?v=3"></script>

</body>
</html>