<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/pascco_shell.php';
require_once __DIR__ . '/pascco_products.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') {
    header('Location: login.php');
    exit;
}

$user_id = (int) $_SESSION['user_id'];
$message = '';
$error = '';
$account_type = trim($_POST['account_type'] ?? '');
$account_options = pascco_savings_product_names();
$products = pascco_savings_products();

$member_stmt = $pdo->prepare('SELECT id, first_name, last_name FROM members WHERE user_id = ? LIMIT 1');
$member_stmt->execute([$user_id]);
$member = $member_stmt->fetch();

$existing_stmt = $pdo->prepare('SELECT a.account_type FROM accounts a JOIN members m ON m.id = a.member_id WHERE m.user_id = ? AND a.status = "active" ORDER BY a.id');
$existing_stmt->execute([$user_id]);
$existing_accounts = $existing_stmt->fetchAll(PDO::FETCH_COLUMN, 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    if (!$member) {
        $error = 'Member profile not found.';
    } elseif ($account_type === '') {
        $error = 'Please select a savings account type.';
    } elseif (!in_array($account_type, $account_options, true)) {
        $error = 'Invalid account type selected.';
    } elseif (in_array($account_type, $existing_accounts, true)) {
        $error = 'You already have an active account of this type.';
    } else {
        try {
            $insert = $pdo->prepare('INSERT INTO account_requests (member_id, account_type, status) VALUES (?, ?, "pending")');
            $insert->execute([(int) $member['id'], $account_type]);
            record_audit($pdo, $user_id, 'account_request', 'Requested a new savings account: ' . $account_type, 'success');
            $message = 'Your request to open a new savings account has been submitted for admin approval.';
            $account_type = '';
        } catch (Throwable $exception) {
            $error = 'Unable to submit your account request. Please try again later.';
        }
    }
}

$product_lookup = [];
foreach ($products as $group => $items) {
    foreach ($items as $item) {
        $product_lookup[$item['name']] = [
            'group' => $group,
            'description' => $item['description'],
        ];
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <title>Open Savings Account | PASCCO</title>
    <link rel="stylesheet" href="member-panels.css?v=3">
    <style>
        :root{
            --oa-navy:#071d49;
            --oa-blue:#1456a0;
            --oa-blue-2:#1c68ba;
            --oa-gold:#e7b84b;
            --oa-ink:#172b4d;
            --oa-muted:#65758d;
            --oa-soft:#f3f7fc;
            --oa-border:#dfe7f1;
            --oa-success:#18794e;
            --oa-danger:#b42318;
            --oa-shadow:0 18px 45px rgba(7,29,73,.10);
        }

        html,body{margin:0!important;padding:0!important;overflow-x:hidden}
        *{box-sizing:border-box}
        body{background:#f4f7fb;color:var(--oa-ink);font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
        a{text-decoration:none}
        button,select{font:inherit}

        .open-account-page{width:min(100% - 32px,1180px);margin:0 auto;padding:38px 0 68px}
        .open-account-hero{display:flex;align-items:flex-end;justify-content:space-between;gap:24px;margin-bottom:24px}
        .open-account-eyebrow{margin-bottom:8px;color:var(--oa-blue);font-size:.70rem;font-weight:900;letter-spacing:.14em;text-transform:uppercase}
        .open-account-hero h1{margin:0;color:var(--oa-navy);font-size:clamp(1.75rem,3vw,2.35rem);line-height:1.12;letter-spacing:-.035em}
        .open-account-hero p{max-width:680px;margin:9px 0 0;color:var(--oa-muted);font-size:.88rem;line-height:1.65}
        .open-account-back{display:inline-flex;align-items:center;gap:8px;min-height:42px;padding:0 15px;border:1px solid var(--oa-border);border-radius:10px;background:#fff;color:var(--oa-navy);font-size:.78rem;font-weight:900;box-shadow:0 5px 16px rgba(7,29,73,.05);white-space:nowrap;transition:.2s ease}
        .open-account-back:hover{border-color:var(--oa-blue);color:var(--oa-blue);transform:translateY(-1px)}

        .open-account-grid{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(300px,.65fr);gap:20px;align-items:start}
        .open-account-card,.open-account-guide{border:1px solid var(--oa-border);border-radius:20px;background:#fff;box-shadow:var(--oa-shadow);overflow:hidden}
        .open-account-card-head{display:flex;align-items:center;gap:14px;padding:24px 26px;border-bottom:1px solid #edf1f6}
        .open-account-icon{display:grid;place-items:center;width:46px;height:46px;border-radius:13px;background:linear-gradient(135deg,var(--oa-blue),var(--oa-navy));color:#fff;font-size:22px;box-shadow:0 8px 18px rgba(20,86,160,.20)}
        .open-account-card-head h2{margin:0;color:var(--oa-navy);font-size:1.02rem;letter-spacing:-.015em}
        .open-account-card-head p{margin:4px 0 0;color:var(--oa-muted);font-size:.76rem}
        .open-account-form{padding:26px}

        .alert{display:flex;align-items:flex-start;gap:10px;margin:0 0 20px;padding:13px 14px;border-radius:11px;font-size:.78rem;line-height:1.5}
        .alert i{font-size:18px;flex:0 0 auto;margin-top:1px}
        .alert.success{border:1px solid #b9e5ce;background:#eefaf3;color:var(--oa-success)}
        .alert.error{border:1px solid #f0c2bf;background:#fff3f2;color:var(--oa-danger)}

        .field-label{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px;color:var(--oa-navy);font-size:.76rem;font-weight:900}
        .field-label span{color:var(--oa-muted);font-size:.68rem;font-weight:700}
        .account-select-wrap{position:relative}
        .account-select{width:100%;min-height:50px;padding:0 45px 0 14px;border:1px solid #ccd8e6;border-radius:11px;background:#fff;color:var(--oa-ink);font-size:.84rem;font-weight:700;outline:0;appearance:none;cursor:pointer;transition:.2s ease}
        .account-select:hover{border-color:#aebed2}
        .account-select:focus{border-color:var(--oa-blue);box-shadow:0 0 0 4px rgba(20,86,160,.10)}
        .account-select-wrap:after{content:"⌄";position:absolute;right:15px;top:50%;transform:translateY(-58%);pointer-events:none;color:var(--oa-blue);font-size:20px;font-weight:900}

        .selected-product{display:none;margin-top:12px;padding:15px;border:1px solid #dbe6f2;border-radius:12px;background:var(--oa-soft)}
        .selected-product.visible{display:block}
        .selected-product-top{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:5px}
        .selected-product-name{color:var(--oa-navy);font-size:.82rem;font-weight:900}
        .selected-product-group{padding:4px 8px;border-radius:999px;background:#e5eef9;color:var(--oa-blue);font-size:.61rem;font-weight:900;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}
        .selected-product-description{margin:0;color:var(--oa-muted);font-size:.73rem;line-height:1.55}

        .submit-account{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:48px;margin-top:20px;border:0;border-radius:11px;background:linear-gradient(135deg,var(--oa-blue),var(--oa-navy));color:#fff;font-size:.82rem;font-weight:900;cursor:pointer;box-shadow:0 9px 20px rgba(20,86,160,.20);transition:.2s ease}
        .submit-account:hover{transform:translateY(-1px);box-shadow:0 12px 24px rgba(20,86,160,.26);color:#fff}
        .submit-account:active{transform:translateY(0)}

        .approval-note{display:flex;align-items:flex-start;gap:11px;margin-top:18px;padding:14px;border:1px solid #f0dfac;border-radius:12px;background:#fffaf0;color:#6d571c;font-size:.73rem;line-height:1.55}
        .approval-note i{color:#b78413;font-size:19px;flex:0 0 auto}
        .approval-note strong{color:var(--oa-navy)}

        .open-account-guide{position:relative;background:linear-gradient(145deg,var(--oa-navy) 0%,#0b326f 100%);border-color:rgba(255,255,255,.08);color:#fff;overflow:hidden}
        .open-account-guide:before{content:"";position:absolute;width:220px;height:220px;right:-110px;top:-120px;border-radius:50%;border:1px solid rgba(231,184,75,.28);box-shadow:0 0 0 24px rgba(231,184,75,.05),0 0 0 48px rgba(231,184,75,.035)}
        .open-account-guide-inner{position:relative;padding:27px}
        .guide-label{display:inline-flex;align-items:center;gap:7px;margin-bottom:10px;color:var(--oa-gold);font-size:.67rem;font-weight:900;letter-spacing:.12em;text-transform:uppercase}
        .open-account-guide h2{margin:0;color:#fff;font-size:1.25rem;letter-spacing:-.025em}
        .open-account-guide > .open-account-guide-inner > p{margin:8px 0 22px;color:rgba(255,255,255,.70);font-size:.75rem;line-height:1.6}
        .account-steps{display:grid;gap:13px;margin:0;padding:0;list-style:none}
        .account-step{display:grid;grid-template-columns:34px 1fr;gap:11px;align-items:start}
        .step-number{display:grid;place-items:center;width:34px;height:34px;border:1px solid rgba(231,184,75,.45);border-radius:10px;background:rgba(255,255,255,.06);color:var(--oa-gold);font-size:.72rem;font-weight:900}
        .account-step h3{margin:1px 0 4px;color:#fff;font-size:.77rem}
        .account-step p{margin:0;color:rgba(255,255,255,.62);font-size:.69rem;line-height:1.5}
        .guide-divider{height:1px;margin:22px 0;background:rgba(255,255,255,.12)}
        .guide-foot{display:flex;gap:10px;align-items:flex-start}
        .guide-foot i{color:var(--oa-gold);font-size:18px}
        .guide-foot p{margin:0;color:rgba(255,255,255,.68);font-size:.69rem;line-height:1.55}

        .existing-section{margin-top:20px;border:1px solid var(--oa-border);border-radius:20px;background:#fff;box-shadow:0 12px 30px rgba(7,29,73,.07);overflow:hidden}
        .existing-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:20px 24px;border-bottom:1px solid #edf1f6}
        .existing-head h2{margin:0;color:var(--oa-navy);font-size:.96rem}
        .existing-head p{margin:4px 0 0;color:var(--oa-muted);font-size:.72rem}
        .existing-count{padding:5px 9px;border-radius:999px;background:#eaf1f9;color:var(--oa-blue);font-size:.64rem;font-weight:900;white-space:nowrap}
        .existing-list{display:grid;grid-template-columns:repeat(3,minmax(0,1fr))}
        .existing-item{display:flex;align-items:center;gap:11px;padding:16px 20px;border-right:1px solid #edf1f6}
        .existing-item:last-child{border-right:0}
        .existing-item-icon{display:grid;place-items:center;width:36px;height:36px;border-radius:10px;background:#eef4fb;color:var(--oa-blue);font-size:17px;flex:0 0 auto}
        .existing-item strong{display:block;color:var(--oa-navy);font-size:.73rem;line-height:1.3}
        .existing-item span{display:block;margin-top:3px;color:var(--oa-success);font-size:.62rem;font-weight:900;text-transform:uppercase}
        .no-existing{padding:20px 24px;color:var(--oa-muted);font-size:.74rem}

        @media(max-width:900px){
            .open-account-grid{grid-template-columns:1fr}
            .existing-list{grid-template-columns:repeat(2,minmax(0,1fr))}
            .existing-item:nth-child(2n){border-right:0}
        }
        @media(max-width:700px){
            .open-account-page{width:min(100% - 24px,1180px);padding:28px 0 52px}
            .open-account-hero{align-items:stretch;flex-direction:column;gap:14px}
            .open-account-back{width:100%;justify-content:center}
            .open-account-form,.open-account-guide-inner{padding:20px 17px}
            .open-account-card-head{padding:20px 17px}
            .existing-list{grid-template-columns:1fr}
            .existing-item{border-right:0!important;border-bottom:1px solid #edf1f6}
            .existing-item:last-child{border-bottom:0}
        }
        @media(max-width:480px){
            .selected-product-top{align-items:flex-start;flex-direction:column;gap:7px}
            .existing-head{align-items:flex-start;flex-direction:column}
        }
    </style>
</head>
<body>

<?php pascco_member_header('Open Savings Account'); ?>

<main class="open-account-page member-content">
    <section class="open-account-hero">
        <div>
            <div class="open-account-eyebrow">Member Accounts</div>
            <h1>Open a New Savings Account</h1>
            <p>Choose the savings product that fits your financial goal. Your request will be reviewed and approved by the PASCCO administrator before the account becomes active.</p>
        </div>

        <a href="dashboard.php" class="open-account-back">
            <i class="bx bx-arrow-back"></i>
            Back to Dashboard
        </a>
    </section>

    <section class="open-account-grid">
        <article class="open-account-card">
            <header class="open-account-card-head">
                <div class="open-account-icon"><i class="bx bx-wallet"></i></div>
                <div>
                    <h2>Account Request</h2>
                    <p>Select one savings product to submit for approval.</p>
                </div>
            </header>

            <div class="open-account-form">
                <?php if ($message): ?>
                    <div class="alert success" role="status">
                        <i class="bx bx-check-circle"></i>
                        <div><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert error" role="alert">
                        <i class="bx bx-error-circle"></i>
                        <div><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
                    </div>
                <?php endif; ?>

                <form method="POST" action="open_account.php">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

                    <label class="field-label" for="account-type">
                        <span style="color:var(--oa-navy);font-size:.76rem;font-weight:900">Savings Account Type</span>
                        <span>Required</span>
                    </label>

                    <div class="account-select-wrap">
                        <select id="account-type" name="account_type" class="account-select" required>
                            <option value="">Select an account type</option>
                            <?php foreach ($products as $group => $items): ?>
                                <optgroup label="<?php echo htmlspecialchars($group, ENT_QUOTES, 'UTF-8'); ?>">
                                    <?php foreach ($items as $option): ?>
                                        <option value="<?php echo htmlspecialchars($option['name'], ENT_QUOTES, 'UTF-8'); ?>" <?php echo $account_type === $option['name'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($option['name'], ENT_QUOTES, 'UTF-8'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div id="selected-product" class="selected-product" aria-live="polite">
                        <div class="selected-product-top">
                            <div id="selected-product-name" class="selected-product-name"></div>
                            <div id="selected-product-group" class="selected-product-group"></div>
                        </div>
                        <p id="selected-product-description" class="selected-product-description"></p>
                    </div>

                    <button type="submit" class="submit-account">
                        <i class="bx bx-send"></i>
                        Submit Account Request
                    </button>
                </form>

                <div class="approval-note">
                    <i class="bx bx-info-circle"></i>
                    <div><strong>Approval required.</strong> New account requests remain pending until reviewed by the administrator. Once approved, the account becomes active and available for eligible transactions.</div>
                </div>
            </div>
        </article>

        <aside class="open-account-guide">
            <div class="open-account-guide-inner">
                <div class="guide-label"><i class="bx bx-list-check"></i> How it works</div>
                <h2>Account Opening Steps</h2>
                <p>A simple four-step process keeps your new account request clear and secure.</p>

                <ol class="account-steps">
                    <li class="account-step">
                        <div class="step-number">01</div>
                        <div><h3>Choose an account</h3><p>Select the savings product that matches your needs or financial goal.</p></div>
                    </li>
                    <li class="account-step">
                        <div class="step-number">02</div>
                        <div><h3>Submit your request</h3><p>Confirm your selection and send the request securely to PASCCO.</p></div>
                    </li>
                    <li class="account-step">
                        <div class="step-number">03</div>
                        <div><h3>Wait for review</h3><p>The administrator reviews the request before activation.</p></div>
                    </li>
                    <li class="account-step">
                        <div class="step-number">04</div>
                        <div><h3>Start using your account</h3><p>After approval, the new account appears in your member account list.</p></div>
                    </li>
                </ol>

                <div class="guide-divider"></div>
                <div class="guide-foot">
                    <i class="bx bx-shield-quarter"></i>
                    <p>Your request is protected by the same member-session and CSRF safeguards used throughout the PASCCO portal.</p>
                </div>
            </div>
        </aside>
    </section>

    <section class="existing-section">
        <header class="existing-head">
            <div>
                <h2>Your Active Savings Accounts</h2>
                <p>Account types already active on your member profile cannot be requested again.</p>
            </div>
            <span class="existing-count"><?php echo count($existing_accounts); ?> active</span>
        </header>

        <?php if ($existing_accounts): ?>
            <div class="existing-list">
                <?php foreach ($existing_accounts as $existing_account): ?>
                    <div class="existing-item">
                        <div class="existing-item-icon"><i class="bx bx-wallet"></i></div>
                        <div>
                            <strong><?php echo htmlspecialchars($existing_account, ENT_QUOTES, 'UTF-8'); ?></strong>
                            <span>Active</span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="no-existing">You do not have any active savings accounts yet. Choose an account above to begin your request.</div>
        <?php endif; ?>
    </section>
</main>

<?php pascco_global_footer(); ?>

<script>
(function () {
    const select = document.getElementById('account-type');
    const panel = document.getElementById('selected-product');
    const name = document.getElementById('selected-product-name');
    const group = document.getElementById('selected-product-group');
    const description = document.getElementById('selected-product-description');
    const products = <?php echo json_encode($product_lookup, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>;

    function updateProduct() {
        const value = select.value;
        if (!value || !products[value]) {
            panel.classList.remove('visible');
            name.textContent = '';
            group.textContent = '';
            description.textContent = '';
            return;
        }

        name.textContent = value;
        group.textContent = products[value].group;
        description.textContent = products[value].description;
        panel.classList.add('visible');
    }

    select.addEventListener('change', updateProduct);
    updateProduct();
})();
</script>
</body>
</html>
