<?php
require_once 'pascco_layout.php';
require_once 'pascco_products.php';
pascco_header('Savings Products', 'savings');
?>
<style>
    .page-intro { max-width: 820px; margin-bottom: 30px; }
    .product-grid { display:grid; gap:22px; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); }
    .product-card { background:#fff; border:1px solid #d8e0ee; border-radius:20px; padding:26px; box-shadow:0 10px 28px rgba(7,29,73,.07); }
    .product-card h2 { color:#071d49; font-size:1.45rem; margin-bottom:18px; }
    .product { padding:16px 0; border-top:1px solid #edf1f7; }
    .product:first-of-type { border-top:0; padding-top:0; }
    .product h3 { margin:0 0 7px; color:#1456a0; font-size:1.08rem; }
    .product p { margin:0; line-height:1.65; }
    .rate-box { margin-top:18px; border-radius:14px; overflow:hidden; border:1px solid #d8e0ee; }
    .rate-label { padding:12px 14px; background:#071d49; color:#fff; font-weight:bold; }
    .rate-table { width:100%; border-collapse:collapse; }
    .rate-table th, .rate-table td { padding:13px 14px; border-bottom:1px solid #e6ebf3; text-align:left; }
    .rate-table th { background:#e6edf8; color:#071d49; }
    .rate-table tr:last-child td { border-bottom:0; }
    .info-banner { margin-top:24px; padding:18px 20px; border-left:4px solid #e7b84b; border-radius:12px; background:#fff8e4; color:#182a45; line-height:1.65; }
</style>
<main class="page-shell">
    <div class="eyebrow">Save with purpose</div>
    <h1>Deposit Products</h1>
    <p class="intro page-intro">Build a stronger financial future with savings options for children, regular members, and specific life goals. Choose the product that best matches how you plan to save.</p>

    <section class="product-grid">
        <?php foreach (pascco_savings_products() as $category => $products): ?>
            <article class="product-card">
                <h2><?php echo htmlspecialchars($category, ENT_QUOTES, 'UTF-8'); ?></h2>
                <?php foreach ($products as $product): ?>
                    <div class="product">
                        <h3><?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?></h3>
                        <p><?php echo htmlspecialchars($product['description'], ENT_QUOTES, 'UTF-8'); ?></p>
                    </div>
                <?php endforeach; ?>

                <?php if ($category === 'Time Deposit'): ?>
                    <div class="rate-box">
                        <div class="rate-label">Time Deposit Rates</div>
                        <table class="rate-table">
                            <thead><tr><th>Amount</th><th>Interest</th></tr></thead>
                            <tbody>
                                <tr><td>PHP 10,000 - 99,000</td><td>1.5%</td></tr>
                                <tr><td>PHP 100,000 - 499,000</td><td>2%</td></tr>
                                <tr><td>PHP 500,000 and above</td><td>2.5%</td></tr>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </article>
        <?php endforeach; ?>
    </section>

    <div class="info-banner"><strong>Member access:</strong> Already a member? Sign in to view your savings accounts, request deposits, transfer funds, and manage your cooperative services.</div>
    <p><a class="button" href="login.php">Open Member Portal</a></p>
</main>
<?php pascco_footer(); ?>
