<?php
require_once __DIR__ . '/security/session.php';

function pascco_header(string $title, string $active = ''): void
{
    $logged_in = isset($_SESSION['user_id']);
    $role = $_SESSION['role'] ?? '';

    if ($logged_in && $role === 'admin') {
        $destination = 'admin_dashboard.php';
        $account_label = 'Admin Dashboard';
    } elseif ($logged_in && $role === 'member') {
        $destination = 'dashboard.php';
        $account_label = 'Member Dashboard';
    } else {
        $destination = 'login.php';
        $account_label = 'Login';
    }

    $nav_items = [
        'home' => ['Home', 'home.php'],
        'savings' => ['Savings', 'savings.php'],
        'credit' => ['Credit', 'credit.php'],
        'requirements' => ['Requirements', 'requirements.php'],
        'about' => ['About', 'about.php'],
    ];
    ?>
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?> | PASCCO</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
        <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
        <style>
            :root {
                --pascco-navy: #071d49;
                --pascco-blue: #1456a0;
                --pascco-blue-light: #2b74c8;
                --pascco-gold: #e7b84b;
                --pascco-gold-light: #ffe7a1;
                --pascco-bg: #f4f7fb;
                --pascco-surface: #ffffff;
                --pascco-text: #182a45;
                --pascco-muted: #64748b;
                --pascco-line: #dbe5f0;
            }

            *, *::before, *::after {
                box-sizing: border-box;
            }

            html,
            body {
                margin: 0 !important;
                padding: 0 !important;
                min-height: 100%;
                overflow-x: hidden;
            }

            html {
                scroll-behavior: smooth;
            }

            body {
                color: var(--pascco-text);
                background: linear-gradient(180deg, #edf4fb 0, #f7f9fc 420px, var(--pascco-bg) 100%);
                font-family: 'Poppins', Arial, Helvetica, sans-serif;
                line-height: 1.6;
            }

            a,
            button,
            input,
            select,
            textarea {
                font: inherit;
            }

            a {
                color: inherit;
            }

            .site-header {
                position: relative;
                z-index: 1000;
                display: flex;
                align-items: center;
                gap: 12px;
                min-height: 54px;
                padding: 4px clamp(14px, 3vw, 42px);
                background: linear-gradient(135deg, var(--pascco-navy), var(--pascco-blue));
                color: #fff;
                box-shadow: 0 8px 24px rgba(7, 29, 73, .12);
                white-space: nowrap;
            }

            .brand {
                display: inline-flex;
                align-items: center;
                gap: 10px;
                flex: 0 0 auto;
                color: #fff;
                text-decoration: none;
            }

            .brand img {
                width: 42px;
                height: 42px;
                object-fit: contain;
            }

            .brand strong {
                color: #fff;
                font-size: 1.08rem;
                font-weight: 800;
                letter-spacing: .07em;
                white-space: nowrap;
            }

            .site-nav {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 2px;
                flex: 1 1 auto;
                min-width: 0;
                margin: 0 auto;
                overflow: hidden;
            }

            .site-nav a {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                flex: 0 0 auto;
                padding: 7px 9px;
                border: 1px solid transparent;
                border-radius: 8px;
                color: rgba(255, 255, 255, .94);
                font-size: .79rem;
                font-weight: 600;
                text-decoration: none;
                white-space: nowrap;
                transition: color .18s ease, border-color .18s ease, background .18s ease;
            }

            .site-nav a:hover,
            .site-nav a.active {
                background: rgba(255, 255, 255, .08);
                border-color: rgba(231, 184, 75, .42);
                color: var(--pascco-gold-light);
            }

            .header-action {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                flex: 0 0 auto;
                min-height: 38px;
                padding: 7px 12px;
                border: 1px solid var(--pascco-gold);
                border-radius: 9px;
                background: rgba(255, 255, 255, .05);
                color: var(--pascco-gold-light);
                font-size: .78rem;
                font-weight: 700;
                text-decoration: none;
                transition: background .18s ease, color .18s ease, transform .18s ease;
            }

            .header-action:hover {
                background: var(--pascco-gold);
                color: var(--pascco-navy);
                transform: translateY(-1px);
            }

            .mobile-nav-toggle {
                display: none;
                align-items: center;
                justify-content: center;
                width: 42px;
                height: 42px;
                padding: 0;
                border: 1px solid rgba(255, 255, 255, .25);
                border-radius: 10px;
                background: transparent;
                color: #fff;
                font-size: 26px;
                cursor: pointer;
            }

            .page-shell {
                width: min(100% - 36px, 1180px);
                margin: 0 auto;
                padding: 42px 0 64px;
            }

            .page-shell h1,
            .page-shell h2,
            .page-shell h3 {
                color: var(--pascco-navy);
                line-height: 1.2;
            }

            .page-shell h1 {
                margin: 9px 0 15px;
                font-size: clamp(2.2rem, 5vw, 3.8rem);
                font-weight: 800;
                letter-spacing: -.025em;
            }

            .page-shell h2 {
                margin: 0 0 12px;
                font-size: 1.35rem;
                font-weight: 700;
            }

            .page-shell h3 {
                margin: 0 0 8px;
                font-size: 1.05rem;
                font-weight: 700;
            }

            .eyebrow {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                color: var(--pascco-blue);
                font-size: .76rem;
                font-weight: 800;
                letter-spacing: .16em;
                text-transform: uppercase;
            }

            .eyebrow::before {
                content: '';
                width: 28px;
                height: 3px;
                border-radius: 999px;
                background: var(--pascco-gold);
            }

            .intro {
                max-width: 820px;
                margin: 0;
                color: var(--pascco-muted);
                font-size: 1rem;
                line-height: 1.75;
            }

            .hero-panel {
                position: relative;
                overflow: hidden;
                margin-bottom: 26px;
                padding: clamp(30px, 6vw, 56px);
                border-radius: 24px;
                background: linear-gradient(135deg, rgba(7, 29, 73, .98), rgba(20, 86, 160, .94));
                color: #fff;
                box-shadow: 0 18px 42px rgba(7, 29, 73, .14);
            }

            .hero-panel::after {
                content: '';
                position: absolute;
                width: 260px;
                height: 260px;
                right: -90px;
                top: -120px;
                border: 1px solid rgba(255, 255, 255, .12);
                border-radius: 50%;
                box-shadow: 0 0 0 34px rgba(255, 255, 255, .025), 0 0 0 70px rgba(255, 255, 255, .018);
            }

            .hero-panel h1,
            .hero-panel h2 {
                color: #fff;
            }

            .hero-panel .eyebrow {
                color: var(--pascco-gold-light);
            }

            .hero-panel .intro {
                color: rgba(255, 255, 255, .9);
            }

            .button {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 7px;
                min-height: 44px;
                margin: 10px 8px 0 0;
                padding: 10px 17px;
                border: 1px solid transparent;
                border-radius: 10px;
                background: var(--pascco-blue);
                color: #fff;
                font-size: .9rem;
                font-weight: 700;
                text-decoration: none;
                box-shadow: 0 8px 18px rgba(20, 86, 160, .14);
                transition: transform .18s ease, box-shadow .18s ease, background .18s ease;
            }

            .button:hover {
                transform: translateY(-1px);
                box-shadow: 0 12px 24px rgba(20, 86, 160, .18);
            }

            .button.secondary {
                border-color: var(--pascco-blue);
                background: transparent;
                color: var(--pascco-blue);
                box-shadow: none;
            }

            .panel,
            .product-card,
            .credit-card,
            .requirement-card,
            .about-card,
            .member-callout,
            .credit-callout,
            .steps,
            .info-banner {
                border: 1px solid var(--pascco-line);
                border-radius: 18px;
                background: var(--pascco-surface);
                box-shadow: 0 12px 30px rgba(7, 29, 73, .06);
            }

            .panel {
                padding: 24px;
                text-align: center;
            }

            .panel p,
            .panel li,
            .product-card p,
            .credit-card li,
            .requirement-card li,
            .about-card p,
            .about-card li {
                line-height: 1.7;
            }

            .data-table {
                overflow: hidden;
                width: 100%;
                margin-top: 22px;
                border: 1px solid var(--pascco-line);
                border-radius: 14px;
                background: #fff;
                border-collapse: separate;
                border-spacing: 0;
                box-shadow: 0 10px 26px rgba(7, 29, 73, .05);
            }

            .data-table th,
            .data-table td {
                padding: 13px 15px;
                border-bottom: 1px solid #e8eef5;
                text-align: left;
            }

            .data-table th {
                background: #eef4fb;
                color: var(--pascco-navy);
                font-size: .86rem;
                font-weight: 700;
            }

            .data-table tr:last-child td {
                border-bottom: 0;
            }

            .site-footer {
                margin-top: 18px;
                padding: 20px 22px 11px;
                border-top: 2px solid var(--pascco-gold);
                background: linear-gradient(135deg, var(--pascco-navy), var(--pascco-blue));
                color: #edf3ff;
            }

            .footer-main {
                display: grid;
                grid-template-columns: 1.2fr 1fr 1.25fr;
                align-items: center;
                gap: 18px;
                width: min(100%, 1180px);
                margin: 0 auto;
            }

            .footer-brand,
            .footer-links,
            .footer-contact {
                min-width: 0;
            }

            .footer-brand {
                display: flex;
                flex-direction: column;
                gap: 3px;
            }

            .footer-heading {
                color: var(--pascco-gold-light);
                font-size: .68rem;
                font-weight: 800;
                letter-spacing: .12em;
                text-transform: uppercase;
            }

            .footer-brand strong {
                color: #fff;
                font-size: .86rem;
            }

            .footer-tagline {
                color: #dbe7fa;
                font-size: .73rem;
            }

            .footer-links {
                display: flex;
                align-items: center;
                justify-content: center;
                flex-wrap: wrap;
                gap: 5px 12px;
            }

            .footer-links a,
            .footer-contact a {
                display: inline-flex;
                align-items: center;
                gap: 5px;
                color: #edf3ff;
                font-size: .73rem;
                text-decoration: none;
                white-space: nowrap;
                transition: color .18s ease, transform .18s ease;
            }

            .footer-links a:hover,
            .footer-contact a:hover {
                color: var(--pascco-gold-light);
                transform: translateY(-1px);
            }

            .footer-links i,
            .footer-contact i {
                font-size: .95rem;
            }

            .footer-contact {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                flex-wrap: wrap;
                gap: 7px 12px;
            }

            .footer-address {
                display: inline-flex;
                align-items: center;
                gap: 7px;
                color: #edf3ff;
                font-size: .7rem;
            }
            .footer-contact-text {
                display: inline-flex;
                align-items: center;
                gap: 5px;
                color: #edf3ff;
                font-size: .73rem;
                white-space: nowrap;
            }

            .footer-contact-text i {
                font-size: .95rem;
            }

            .footer-logo {
                width: 28px;
                height: 28px;
                object-fit: contain;
                flex: 0 0 auto;
            }

            .copyright {
                width: min(100%, 1180px);
                margin: 10px auto 0;
                padding-top: 8px;
                border-top: 1px solid rgba(255, 255, 255, .14);
                color: #cbd8eb;
                font-size: .67rem;
                text-align: center;
            }


            @media (max-width: 1050px) and (min-width: 851px) {
                .site-header { gap: 8px; padding-left: 12px; padding-right: 12px; }
                .brand { gap: 7px; }
                .brand img { width: 38px; height: 38px; }
                .brand strong { font-size: 1rem; }
                .site-nav { gap: 0; }
                .site-nav a { padding: 6px 7px; font-size: .72rem; }
                .header-action { min-height: 36px; padding: 6px 10px; font-size: .72rem; }
            }

            @media (max-width: 850px) {
                .site-header {
                    flex-wrap: wrap;
                }

                .site-nav {
                    flex-basis: 100%;
                    order: 4;
                    justify-content: flex-start;
                    overflow-x: auto;
                    margin: 2px 0 0;
                    padding-bottom: 2px;
                }

                .footer-main {
                    grid-template-columns: 1fr 1fr;
                }

                .footer-brand {
                    grid-column: 1 / -1;
                    align-items: center;
                    text-align: center;
                }

                .footer-contact {
                    justify-content: center;
                }
            }

            @media (max-width: 700px) {
                .site-header {
                    gap: 10px;
                    padding: 12px 16px;
                }

                .brand img {
                    width: 42px;
                    height: 42px;
                }

                .brand strong {
                    font-size: 1.05rem;
                }

                .mobile-nav-toggle {
                    display: inline-flex;
                    margin-left: auto;
                }

                .site-nav {
                    display: none;
                    width: 100%;
                    margin: 0;
                    padding: 5px 0;
                    overflow: visible;
                }

                .site-nav.is-open {
                    display: grid;
                    grid-template-columns: repeat(2, minmax(0, 1fr));
                    gap: 5px;
                }

                .site-nav a {
                    width: 100%;
                    padding: 10px 8px;
                    border: 1px solid rgba(255, 255, 255, .18);
                    border-radius: 8px;
                    text-align: center;
                }

                .header-action {
                    order: 3;
                    margin-left: 0;
                }

                .page-shell {
                    width: min(100% - 24px, 1180px);
                    padding: 30px 0 48px;
                }

                .page-shell h1 {
                    font-size: 2.1rem;
                }

                .hero-panel {
                    padding: 28px 20px;
                    border-radius: 20px;
                }

                .footer-main {
                    grid-template-columns: 1fr;
                    gap: 10px;
                }

                .footer-links,
                .footer-contact {
                    justify-content: center;
                }
            }

            @media print {
                .site-header,
                .site-footer,
                .no-print {
                    display: none !important;
                }

                .page-shell {
                    width: 100%;
                    padding: 0;
                }
            }
        </style>
    </head>
    <body>
        <header class="site-header">
            <a class="brand" href="home.php">
                <img src="LOGO.png" alt="PASCCO logo">
                <strong>PASCCO</strong>
            </a>

            <nav class="site-nav" id="pascco-public-nav" aria-label="Primary navigation">
                <?php foreach ($nav_items as $key => [$label, $url]): ?>
                    <a
                        class="<?php echo $active === $key ? 'active' : ''; ?>"
                        href="<?php echo htmlspecialchars($url, ENT_QUOTES, 'UTF-8'); ?>"
                        <?php echo $active === $key ? 'aria-current="page"' : ''; ?>
                    >
                        <?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8'); ?>
                    </a>
                <?php endforeach; ?>
            </nav>

            <a class="header-action" href="<?php echo htmlspecialchars($destination, ENT_QUOTES, 'UTF-8'); ?>">
                <?php echo htmlspecialchars($account_label, ENT_QUOTES, 'UTF-8'); ?>
            </a>

            <button
                class="mobile-nav-toggle"
                type="button"
                aria-label="Open navigation"
                aria-controls="pascco-public-nav"
                aria-expanded="false"
            >
                <i class="bx bx-menu" aria-hidden="true"></i>
            </button>
        </header>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const toggle = document.querySelector('.mobile-nav-toggle');
                const nav = document.querySelector('.site-nav');

                if (!toggle || !nav) {
                    return;
                }

                toggle.addEventListener('click', function () {
                    const isOpen = nav.classList.toggle('is-open');
                    toggle.setAttribute('aria-expanded', String(isOpen));
                });

                nav.querySelectorAll('a').forEach(function (link) {
                    link.addEventListener('click', function () {
                        nav.classList.remove('is-open');
                        toggle.setAttribute('aria-expanded', 'false');
                    });
                });
            });
        </script>
    <?php
}

function pascco_footer(): void
{
    ?>
    <footer class="site-footer">
        <div class="footer-main">
            <div class="footer-brand">
                <span class="footer-heading">PASCCO</span>
                <strong>Paco Savings &amp; Credit Cooperative</strong>
                <span class="footer-tagline">Helping People Help Themselves.</span>
            </div>

            <nav class="footer-links" aria-label="Footer navigation">
                <a href="home.php"><i class="bx bx-home-alt" aria-hidden="true"></i><span>Home</span></a>
                <a href="about.php"><i class="bx bx-buildings" aria-hidden="true"></i><span>About</span></a>
                <a href="savings.php"><i class="bx bx-wallet" aria-hidden="true"></i><span>Savings</span></a>
                <a href="credit.php"><i class="bx bx-credit-card" aria-hidden="true"></i><span>Credit</span></a>
                <a href="requirements.php"><i class="bx bx-check-shield" aria-hidden="true"></i><span>Requirements</span></a>
                <a href="support.php"><i class="bx bx-help-circle" aria-hidden="true"></i><span>Help</span></a>
                <a href="privacy.php"><i class="bx bx-shield" aria-hidden="true"></i><span>Privacy</span></a>
            </nav>

            <div class="footer-contact">
                <span class="footer-address">
                    <img class="footer-logo" src="LOGO.png" alt="PASCCO logo">
                    <span>1461 Merced corner Perdigon Sts., Paco, Manila</span>
                </span>
                <span class="footer-contact-text">
                    <i class="bx bx-envelope" aria-hidden="true"></i>
                    <span>pascco30@gmail.com</span>
                </span>
                <span class="footer-contact-text">
                    <i class="bx bx-mobile" aria-hidden="true"></i>
                    <span>0908-3688038</span>
                </span>
                <a href="https://www.facebook.com/pacopascco"
                target="_blank"
                rel="noopener noreferrer">
                    <i class="bx bxl-facebook-square" aria-hidden="true"></i>
                    <span>Facebook</span>
                </a>
            </div>
        </div>

        <div class="copyright">
            &copy; <?php echo date('1983'); ?> PASCCO &middot; Paco Savings &amp; Credit Cooperative. All rights reserved.
        </div>
    </footer>
    <script src="animated-button.js"></script>
    </body>
    </html>
    <?php
}
