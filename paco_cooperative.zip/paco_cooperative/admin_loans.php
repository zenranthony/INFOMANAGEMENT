<?php
require_once 'db.php';
require_once 'pascco_shell.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access Denied: You must be logged in as an Admin to view this page. <a href='login.php'>Login here</a>");
}

$message = '';
$query = trim($_GET['q'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    verify_csrf(); // Verify CSRF Token

    $loan_id   = intval($_POST['loan_id']);
    $action    = $_POST['action'];

    $loan_check = $pdo->prepare("SELECT member_id, loan_amount, identity_status FROM loans WHERE id = ? AND status = 'pending'");
    $loan_check->execute([$loan_id]);
    $loan = $loan_check->fetch();

    if (!$loan) {
        $message = "This loan is no longer pending or could not be found.";
    } elseif ($action === 'verify_identity' || $action === 'reject_identity') {
        $identity_status = $action === 'verify_identity' ? 'verified' : 'rejected';
        $identity_notes = trim($_POST['identity_notes'] ?? '');
        if ($identity_status === 'rejected' && $identity_notes === '') {
            $message = 'Add a note explaining why the identity documents were rejected.';
        } else {
            $identity_update = $pdo->prepare('UPDATE loans SET identity_status = ?, identity_verified_by = ?, identity_verified_at = NOW(), identity_notes = ? WHERE id = ? AND status = \'pending\'');
            $identity_update->execute([$identity_status, (int) $_SESSION['user_id'], $identity_notes, $loan_id]);
            record_audit($pdo, (int) $_SESSION['user_id'], 'identity_review', ucfirst($identity_status) . ' identity for loan ' . $loan_id, 'success');
            $message = $identity_status === 'verified' ? 'Identity verified. The loan can now be approved.' : 'Identity rejected. The member must submit corrected documents.';
        }
    } elseif ($action === 'approve') {
        if ($loan['identity_status'] !== 'verified') {
            $message = 'Verify the member identity documents before approving this loan.';
        } else {
        $member_id = (int) $loan['member_id'];
        $amount = (float) $loan['loan_amount'];
        $pdo->beginTransaction();
        try {
            $update = $pdo->prepare("UPDATE loans SET status = 'approved' WHERE id = ? AND status = 'pending' AND identity_status = 'verified'");
            $update->execute([$loan_id]);
            if ($update->rowCount() !== 1) {
                throw new RuntimeException('This loan was already processed by another administrator.');
            }

            $acc_stmt = $pdo->prepare("SELECT id FROM accounts WHERE member_id = ? AND status = 'active'");
            $acc_stmt->execute([$member_id]);
            $acc = $acc_stmt->fetch();

            if (!$acc) {
                throw new RuntimeException('The member has no active savings account.');
            }

            $ref_number = 'OR-' . date('YmdHis') . '-' . random_int(100000, 999999);
            $tx = $pdo->prepare("
                INSERT INTO transactions (account_id, transaction_type, amount, recipient_account_id, description, status, reference_number, transaction_date, created_at)
                VALUES (?, 'deposit', ?, NULL, 'Loan Disbursement', 'completed', ?, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())
            ");
            $tx->execute([$acc['id'], $amount, $ref_number]);
            $balance_update = $pdo->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ? AND status = 'active'");
            $balance_update->execute([$amount, (int) $acc['id']]);
            $pdo->commit();
            record_audit($pdo, (int) $_SESSION['user_id'], 'loan_approval', 'Approved and disbursed loan ' . $loan_id, 'success');
            $message = "Loan approved and funds disbursed to the member's account.";
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $message = $exception->getMessage();
        }
        }

    } elseif ($action === 'reject') {
        $update = $pdo->prepare("UPDATE loans SET status = 'rejected' WHERE id = ? AND status = 'pending'");
        $update->execute([$loan_id]);
        record_audit($pdo, (int) $_SESSION['user_id'], 'loan_rejection', 'Rejected loan ' . $loan_id, 'success');

        $message = "Loan application rejected.";
    }
}

$loan_query = "
    SELECT 
        l.id AS loan_id, 
        l.loan_number, 
        l.loan_product,
        l.loan_amount,
        l.loan_term,
        l.loan_purpose,
        l.contact_number,
        l.birth_date,
        l.civil_status,
        l.address,
        l.occupation,
        l.employer,
        l.monthly_income,
        l.id_type,
        l.id_number,
        l.id_document_path,
        l.proof_income_path,
        l.identity_status,
        l.identity_notes,
        l.application_date, 
        m.id AS member_id,
        m.first_name, 
        m.last_name, 
        m.member_number 
    FROM loans l
    JOIN members m ON l.member_id = m.id
    WHERE l.status = 'pending'";
$loan_parameters = [];
if ($query !== '') {
    $loan_query .= " AND (l.loan_number LIKE ? OR l.loan_product LIKE ? OR m.first_name LIKE ? OR m.last_name LIKE ? OR m.member_number LIKE ?)";
    $search = '%' . $query . '%';
    $loan_parameters = [$search, $search, $search, $search, $search];
}
$loan_query .= ' ORDER BY l.id DESC';
$stmt = $pdo->prepare($loan_query);
$stmt->execute($loan_parameters);
$pending_loans = $stmt->fetchAll();
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php pascco_global_styles(); ?>
<title>Loan Approvals | PASCCO Admin</title>

<style>
:root{--navy:#071d49;--blue:#1456a0;--blue2:#2b74c8;--gold:#e7b84b;--gold-light:#ffe7a1;--ink:#18324f;--muted:#6e7e93;--line:#dce5ef;--bg:#f4f7fb;--surface:#fff;--soft:#eef4fb;--success:#1c7442;--danger:#b52f38;--shadow:0 16px 40px rgba(7,29,73,.08)}
html,body{margin:0!important;padding:0!important;overflow-x:hidden}body{background:linear-gradient(180deg,#edf4fb 0,#f7f9fc 360px,var(--bg) 100%);color:var(--ink);font-family:Poppins,Arial,sans-serif}.admin-wrap{width:min(100% - 40px,1200px);margin:0 auto;padding:34px 0 58px}.page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:22px}.eyebrow{display:inline-flex;align-items:center;gap:8px;color:var(--blue);font-size:.74rem;font-weight:800;letter-spacing:.15em;text-transform:uppercase}.eyebrow:before{content:"";width:28px;height:3px;background:var(--gold);border-radius:999px}.page-head h1{margin:8px 0 0;color:var(--navy);font-size:clamp(2rem,4vw,3rem);line-height:1.05}.page-head p{margin:10px 0 0;color:var(--muted);line-height:1.6}.head-actions,.quick-actions{display:flex;gap:9px;flex-wrap:wrap}.button{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:11px 15px;border-radius:11px;background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;text-decoration:none;font-weight:800;font-size:.86rem;box-shadow:0 8px 18px rgba(20,86,160,.15)}.button.secondary{background:#fff;border:1px solid #cdd8e5;color:var(--navy);box-shadow:none}.button.gold{background:var(--gold);color:var(--navy)}.surface{background:var(--surface);border:1px solid rgba(7,29,73,.07);border-radius:20px;box-shadow:var(--shadow);overflow:hidden}.surface-head{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:21px 23px;border-bottom:1px solid var(--line)}.surface-head h2,.surface-head h3{margin:0;color:var(--navy);font-size:1.15rem}.surface-head p{margin:5px 0 0;color:var(--muted);font-size:.86rem}.surface-body{padding:22px}.stat-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin-bottom:20px}.stat{position:relative;padding:20px;border-radius:18px;background:#fff;border:1px solid rgba(7,29,73,.07);box-shadow:var(--shadow);overflow:hidden}.stat:after{content:"";position:absolute;right:-35px;top:-35px;width:120px;height:120px;border:1px solid rgba(20,86,160,.10);border-radius:50%;box-shadow:0 0 0 22px rgba(20,86,160,.025)}.stat .label{color:#78889b;font-size:.72rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase}.stat .value{margin-top:8px;color:var(--navy);font-size:1.65rem;font-weight:800;line-height:1.15}.stat.gold{border-top:4px solid var(--gold)}.stat.blue{border-top:4px solid var(--blue)}.grid-2{display:grid;grid-template-columns:1.35fr .65fr;gap:20px}.grid-2.equal{grid-template-columns:1fr 1fr}.stack{display:grid;gap:20px}.status-grid{display:grid;grid-template-columns:1fr 1fr;gap:11px}.status-tile{padding:14px;border-radius:13px;background:var(--soft);border:1px solid var(--line)}.status-tile span{display:block;color:var(--muted);font-size:.75rem}.status-tile strong{display:block;margin-top:4px;color:var(--navy);font-size:1.3rem}.status-tile.gold{background:#fff8df;border-color:#f0dda2}.status-tile.green{background:#eef9f2;border-color:#cde8d6}.status-tile.red{background:#fff1f1;border-color:#f0cccc}.table-wrap{overflow:auto}.admin-table{width:100%;min-width:640px;border-collapse:collapse}.admin-table th,.admin-table td{padding:13px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.82rem}.admin-table th{background:#f3f7fc;color:var(--navy);font-weight:800;position:sticky;top:0}.admin-table tr:hover td{background:#fbfdff}.sub{display:block;color:#8694a5;font-size:.72rem;margin-top:3px}.badge,.status-pill{display:inline-flex;align-items:center;gap:5px;padding:5px 9px;border-radius:999px;background:#e8f0fa;color:var(--navy);font-size:.7rem;font-weight:800;text-transform:uppercase}.badge.pending,.status-pill.pending{background:#fff0bf;color:#8a6500}.badge.approved,.status-pill.approved,.badge.paid{background:#e4f6ea;color:#17673b}.badge.rejected,.status-pill.rejected{background:#fde7e7;color:#a52f37}.badge.under_review,.status-pill.under_review{background:#efe8ff;color:#6945a6}.badge.scheduled,.status-pill.scheduled{background:#e9f3ff;color:#2966a8}.badge.certificate_uploaded,.status-pill.certificate_uploaded{background:#e5f8ed;color:#25714a}.notice{padding:13px 15px;border-radius:12px;margin-bottom:18px;font-weight:700;font-size:.86rem}.notice.success{background:#eaf8f0;border:1px solid #cfe9d9;color:var(--success)}.notice.error{background:#fff0f0;border:1px solid #f0cfd0;color:var(--danger)}.toolbar{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}.search-form{display:flex;gap:8px;width:min(100%,480px)}.field{margin-bottom:15px}.field label{display:block;margin-bottom:7px;color:var(--navy);font-size:.78rem;font-weight:800}.field input,.field select,.field textarea,.search-form input{width:100%;box-sizing:border-box;min-height:46px;padding:11px 13px;border:1px solid #cad6e3;border-radius:11px;background:#fff;color:var(--ink);font:inherit;outline:none}.field textarea{min-height:110px;resize:vertical}.field input:focus,.field select:focus,.field textarea:focus,.search-form input:focus{border-color:var(--blue2);box-shadow:0 0 0 4px rgba(20,86,160,.09)}.search-form input{flex:1}.search-form button,.action-btn{border:0;border-radius:11px;padding:11px 15px;background:var(--navy);color:#fff;font:inherit;font-weight:800;cursor:pointer}.filter-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.filter-row select{min-height:44px;border:1px solid #cad6e3;border-radius:11px;padding:9px 12px;background:#fff;font:inherit}.detail-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.detail-box{padding:13px;border:1px solid var(--line);border-radius:13px;background:#f8fbff}.detail-box small{display:block;color:#8291a2;font-size:.7rem}.detail-box strong{display:block;margin-top:4px;color:var(--navy);font-size:.84rem;line-height:1.45}.record-list{display:grid;gap:12px}.record{padding:17px;border:1px solid var(--line);border-radius:15px;background:#fbfdff}.record-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.record h3{margin:0;color:var(--navy);font-size:1rem}.record p{margin:5px 0;color:var(--muted);font-size:.82rem;line-height:1.5}.record-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:13px}.mini-link{color:var(--blue);font-weight:800;text-decoration:none;font-size:.82rem}.empty{padding:26px;text-align:center;color:var(--muted);background:#f8fbff;border:1px dashed #cdd9e5;border-radius:14px}.amount{color:var(--blue);font-weight:800;white-space:nowrap}.approval-card{padding:19px;border:1px solid var(--line);border-radius:17px;background:#fff}.approval-card+.approval-card{margin-top:12px}.approval-meta{color:var(--muted);font-size:.78rem}.approval-top{display:flex;justify-content:space-between;gap:15px;align-items:flex-start}.approval-top h3{margin:0;color:var(--navy);font-size:1rem}.approval-details{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:16px 0}.approval-details div{padding-top:9px;border-top:1px solid var(--line)}.approval-details small,.identity-grid small{display:block;color:#8291a2;font-size:.7rem}.approval-details strong,.identity-grid strong{display:block;margin-top:3px;color:var(--navy);font-size:.82rem;line-height:1.45}.identity-panel{padding:16px;border-radius:15px;background:#fffaf0;border:1px solid #ecdca8}.identity-panel h4{margin:0 0 12px;color:var(--navy)}.identity-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 14px}.document-links{display:flex;flex-wrap:wrap;gap:9px;margin-top:13px}.document-links a,.receipt-link{color:var(--blue);font-weight:800;text-decoration:none;font-size:.8rem}.review-form{display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;margin-top:13px}.review-form textarea{flex:1;min-width:220px;min-height:45px;padding:10px;border:1px solid #cad6e3;border-radius:10px;font:inherit}.btn-success,.btn-danger,.btn-primary{border:0;border-radius:10px;padding:10px 13px;font:inherit;font-weight:800;cursor:pointer}.btn-success{background:#267748;color:#fff}.btn-danger{background:#b8323b;color:#fff}.btn-primary{background:var(--blue);color:#fff}.announcement-grid{display:grid;grid-template-columns:.7fr 1.3fr;gap:20px}.announcement-card{padding:18px;border:1px solid var(--line);border-radius:16px;background:#fff}.announcement-card img{width:100%;max-height:190px;object-fit:cover;border-radius:12px;margin-bottom:12px}.announcement-card h3{margin:0;color:var(--navy);font-size:1rem}.announcement-card p{color:var(--muted);line-height:1.55;font-size:.82rem;white-space:pre-line}.announcement-card+.announcement-card{margin-top:12px}.profile-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.quick-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.quick-card{padding:16px;border-radius:15px;background:#f8fbff;border:1px solid var(--line)}.quick-card i{font-size:1.35rem;color:var(--blue)}.quick-card strong{display:block;margin-top:8px;color:var(--navy)}.quick-card span{display:block;margin-top:4px;color:var(--muted);font-size:.76rem;line-height:1.45}.mt{margin-top:20px}@media(max-width:1000px){.stat-grid{grid-template-columns:repeat(2,1fr)}.grid-2,.grid-2.equal,.announcement-grid{grid-template-columns:1fr}.detail-grid,.profile-grid,.approval-details,.identity-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.quick-grid{grid-template-columns:1fr 1fr}}@media(max-width:700px){.admin-wrap{width:min(100% - 28px,1200px);padding-top:24px}.page-head{align-items:flex-start;flex-direction:column}.head-actions,.quick-actions{width:100%}.button{flex:1}.stat-grid{grid-template-columns:1fr}.surface-head,.surface-body{padding:17px}.detail-grid,.profile-grid,.approval-details,.identity-grid,.quick-grid{grid-template-columns:1fr}.search-form{width:100%}.search-form button{white-space:nowrap}.approval-top,.record-head{flex-direction:column}.review-form{align-items:stretch;flex-direction:column}.review-form textarea{min-width:0}.review-form button{width:100%}}
</style>

</head>
<body>
<?php pascco_admin_header(); ?>

<main class="admin-wrap">
<section class="page-head"><div><div class="eyebrow">Credit operations</div><h1>Loan Approvals</h1><p>Review identity documents, confirm eligibility, and approve or reject pending loan applications.</p></div><a class="button secondary" href="admin_dashboard.php"><i class="bx bx-arrow-back"></i> Dashboard</a></section>
<div class="surface"><div class="surface-head"><div><h2>Pending Loan Applications</h2><p><?php echo count($pending_loans); ?> application<?php echo count($pending_loans)===1?'':'s'; ?> waiting for review.</p></div><form class="search-form" method="GET" action="admin_loans.php"><input name="q" value="<?php echo htmlspecialchars($query,ENT_QUOTES,'UTF-8'); ?>" placeholder="Search member, loan, or product"><button type="submit"><i class="bx bx-search"></i> Search</button></form></div><div class="surface-body"><?php if($message): ?><div class="notice success"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?><?php if($pending_loans): ?><div class="record-list"><?php foreach($pending_loans as $loan): ?><article class="approval-card"><div class="approval-top"><div><h3><?php echo htmlspecialchars($loan['loan_product'],ENT_QUOTES,'UTF-8'); ?></h3><p class="approval-meta"><?php echo htmlspecialchars($loan['loan_number'],ENT_QUOTES,'UTF-8'); ?> · Applied <?php echo htmlspecialchars($loan['application_date'],ENT_QUOTES,'UTF-8'); ?></p><a class="mini-link" href="loan_application_print.php?loan_id=<?php echo (int)$loan['loan_id']; ?>" target="_blank" rel="noopener">View / Print Application</a></div><div class="amount">₱<?php echo number_format($loan['loan_amount'],2); ?></div></div><div class="approval-details"><div><small>Member</small><strong><?php echo htmlspecialchars($loan['first_name'].' '.$loan['last_name'],ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>Member Number</small><strong><?php echo htmlspecialchars($loan['member_number'],ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>Term</small><strong><?php echo htmlspecialchars($loan['loan_term'],ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>Contact</small><strong><?php echo htmlspecialchars($loan['contact_number'],ENT_QUOTES,'UTF-8'); ?></strong></div></div><section class="identity-panel"><h4>Identity &amp; Eligibility <span class="status-pill <?php echo htmlspecialchars($loan['identity_status'],ENT_QUOTES,'UTF-8'); ?>"><?php echo htmlspecialchars($loan['identity_status'],ENT_QUOTES,'UTF-8'); ?></span></h4><div class="identity-grid"><div><small>Birth Date</small><strong><?php echo htmlspecialchars($loan['birth_date']??'-',ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>Civil Status</small><strong><?php echo htmlspecialchars($loan['civil_status']??'-',ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>Occupation</small><strong><?php echo htmlspecialchars($loan['occupation']??'-',ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>Monthly Income</small><strong>₱<?php echo number_format((float)($loan['monthly_income']??0),2); ?></strong></div><div><small>Employer / Business</small><strong><?php echo htmlspecialchars($loan['employer']??'-',ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>ID Type</small><strong><?php echo htmlspecialchars($loan['id_type']??'-',ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>ID Number</small><strong><?php echo htmlspecialchars($loan['id_number']??'-',ENT_QUOTES,'UTF-8'); ?></strong></div><div><small>Address</small><strong><?php echo htmlspecialchars($loan['address']??'-',ENT_QUOTES,'UTF-8'); ?></strong></div></div><div class="document-links"><?php if($loan['id_document_path']): ?><a href="loan_document.php?loan_id=<?php echo (int)$loan['loan_id']; ?>&type=id" target="_blank" rel="noopener"><i class="bx bx-id-card"></i> Government ID</a><?php endif; ?><?php if($loan['proof_income_path']): ?><a href="loan_document.php?loan_id=<?php echo (int)$loan['loan_id']; ?>&type=income" target="_blank" rel="noopener"><i class="bx bx-file"></i> Proof of Income</a><?php endif; ?></div><form method="POST" class="review-form"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="loan_id" value="<?php echo (int)$loan['loan_id']; ?>"><textarea name="identity_notes" placeholder="Verification note, required when rejecting"><?php echo htmlspecialchars($loan['identity_notes']??'',ENT_QUOTES,'UTF-8'); ?></textarea><button type="submit" name="action" value="verify_identity" class="btn-success"><i class="bx bx-check-shield"></i> Verify Identity</button><button type="submit" name="action" value="reject_identity" class="btn-danger"><i class="bx bx-x-circle"></i> Reject Identity</button></form></section><div class="detail-box mt"><small>Loan Purpose</small><strong><?php echo htmlspecialchars($loan['loan_purpose'],ENT_QUOTES,'UTF-8'); ?></strong></div><form method="POST" action="admin_loans.php" class="record-actions"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="loan_id" value="<?php echo (int)$loan['loan_id']; ?>"><button type="submit" name="action" value="approve" class="btn-success" <?php echo $loan['identity_status']!=='verified'?'disabled title="Verify identity first"':''; ?>><i class="bx bx-check"></i> Approve &amp; Disburse</button><button type="submit" name="action" value="reject" class="btn-danger" onclick="return confirm('Reject this loan application?');"><i class="bx bx-x"></i> Reject Application</button></form></article><?php endforeach; ?></div><?php else: ?><div class="empty">All loan applications are up to date. No pending requests found.</div><?php endif; ?></div></div>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
