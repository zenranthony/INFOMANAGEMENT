<?php
require_once 'db.php';
require_once 'pascco_shell.php';
require_once 'mail_config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    $ipAllowed = pascco_take_attempt(
        $pdo,
        'password-ip',
        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        60
    );

    $stmt = $pdo->prepare(
        'SELECT id, username, email, password, role, status FROM users WHERE username = ?'
    );
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    $accountIdentity = $user
        ? 'id:' . $user['id']
        : mb_strtolower($username, 'UTF-8');

    $accountAllowed = $ipAllowed && pascco_take_attempt(
        $pdo,
        'password-account',
        $accountIdentity,
        10
    );

    if (!$ipAllowed || !$accountAllowed) {
        http_response_code(429);
        header('Retry-After: 900');
        $error = 'Too many login attempts. Please wait 15 minutes before trying again.';
    } else {
        // Use a real hash for unknown accounts too to reduce timing differences.
        $valid = password_verify(
            $password,
            $user['password'] ?? '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.'
        );

        if (
            $valid &&
            $user &&
            $user['status'] === 'active' &&
            in_array($user['role'], ['admin', 'member'], true)
        ) {
            // ADMIN: keep the existing authenticator workflow unchanged.
            if ($user['role'] === 'admin') {
                $_SESSION = [];
                session_regenerate_id(true);
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                $_SESSION['otp_user_id'] = (int) $user['id'];
                $_SESSION['otp_started_at'] = time();
                $_SESSION['otp_password_version'] = hash('sha256', $user['password']);

                record_audit(
                    $pdo,
                    (int) $user['id'],
                    'password_verified',
                    'Password verified; authenticator verification required.',
                    'success'
                );

                header('Location: otp_verify.php');
                exit;
            }

            // MEMBER: send a one-time code to the registered email address.
            $email = trim((string) ($user['email'] ?? ''));

            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = 'No valid email address is registered for this member account. Please contact PASCCO.';
                record_audit(
                    $pdo,
                    (int) $user['id'],
                    'member_otp_email_missing',
                    'Member login could not continue because no valid email address is registered.',
                    'failed'
                );
            } else {
                $otp = (string) random_int(100000, 999999);
                $otpHash = password_hash($otp, PASSWORD_DEFAULT);

                try {
                    $update = $pdo->prepare(
                        "UPDATE users
                         SET otp_code = ?,
                             otp_expires_at = DATE_ADD(NOW(), INTERVAL 5 MINUTE),
                             otp_attempts = 0
                         WHERE id = ? AND role = 'member' AND status = 'active'"
                    );
                    $update->execute([$otpHash, (int) $user['id']]);

                    if ($update->rowCount() !== 1) {
                        throw new RuntimeException('Unable to prepare member verification.');
                    }

                    $emailSent = sendMemberLoginOtpEmail(
                        $email,
                        (string) $user['username'],
                        $otp
                    );

                    if (!$emailSent) {
                        $clear = $pdo->prepare(
                            'UPDATE users SET otp_code = NULL, otp_expires_at = NULL, otp_attempts = 0 WHERE id = ?'
                        );
                        $clear->execute([(int) $user['id']]);
                        throw new RuntimeException('The verification email could not be sent. Please try again.');
                    }

                    $_SESSION = [];
                    session_regenerate_id(true);
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    $_SESSION['member_otp_user_id'] = (int) $user['id'];
                    $_SESSION['member_otp_started_at'] = time();
                    $_SESSION['member_otp_last_sent'] = time();
                    $_SESSION['member_otp_password_version'] = hash('sha256', $user['password']);

                    record_audit(
                        $pdo,
                        (int) $user['id'],
                        'member_otp_sent',
                        'Email OTP sent after successful member password login.',
                        'success'
                    );

                    header('Location: member_otp_verify.php');
                    exit;
                } catch (Throwable $exception) {
                    error_log('PASCCO member email OTP generation failed: ' . $exception->getMessage());
                    $error = 'Verification could not be started. Please try again.';
                }
            }
        } else {
            $error = 'Invalid username or password.';

            record_audit(
                $pdo,
                null,
                'login',
                'Failed login attempt.',
                'failed'
            );
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <title>Login | PASCCO</title>
    <style>
        :root {
            --login-navy: #071d49;
            --login-blue: #1456a0;
            --login-blue-light: #2b74c8;
            --login-gold: #e7b84b;
            --login-gold-light: #ffe7a1;
            --login-ink: #172d4b;
            --login-muted: #6d7e94;
            --login-line: #dbe5f0;
            --login-bg: #f4f7fb;
            --login-soft: #eef4fb;
            --login-danger-bg: #fff1f1;
            --login-danger: #a33434;
        }

        html,
        body {
            margin: 0 !important;
            padding: 0 !important;
            overflow-x: hidden;
        }

        body {
            min-height: 100vh;
            background:
                radial-gradient(circle at 12% 10%, rgba(20, 86, 160, .12), transparent 32%),
                radial-gradient(circle at 88% 8%, rgba(231, 184, 75, .12), transparent 28%),
                linear-gradient(180deg, #edf4fb 0, #f7f9fc 430px, var(--login-bg) 100%);
            color: var(--login-ink);
            font-family: Poppins, Arial, Helvetica, sans-serif;
        }

        .login-page {
            width: min(1180px, calc(100% - 40px));
            margin: 0 auto;
            padding: 44px 0 64px;
        }

        .login-hero {
            display: grid;
            grid-template-columns: minmax(0, 1.05fr) minmax(360px, 500px);
            gap: 28px;
            align-items: stretch;
        }

        .login-welcome {
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: center;
            min-height: 540px;
            padding: clamp(34px, 5vw, 58px);
            border-radius: 26px;
            background: linear-gradient(135deg, var(--login-navy), var(--login-blue));
            color: #fff;
            box-shadow: 0 18px 42px rgba(7, 29, 73, .16);
        }

        .login-welcome::before,
        .login-welcome::after {
            content: '';
            position: absolute;
            border: 1px solid rgba(255, 255, 255, .13);
            border-radius: 50%;
            pointer-events: none;
        }

        .login-welcome::before {
            width: 290px;
            height: 290px;
            right: -130px;
            top: -120px;
            box-shadow: 0 0 0 28px rgba(255, 255, 255, .025), 0 0 0 58px rgba(255, 255, 255, .02);
        }

        .login-welcome::after {
            width: 180px;
            height: 180px;
            left: -100px;
            bottom: -95px;
            opacity: .55;
        }

        .login-brand-mark {
            width: 88px;
            height: 88px;
            object-fit: contain;
            margin-bottom: 22px;
            filter: drop-shadow(0 12px 18px rgba(0, 0, 0, .18));
        }

        .login-eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            width: fit-content;
            margin-bottom: 14px;
            color: var(--login-gold-light);
            font-size: .74rem;
            font-weight: 800;
            letter-spacing: .16em;
            text-transform: uppercase;
        }

        .login-eyebrow::before {
            content: '';
            width: 28px;
            height: 3px;
            border-radius: 999px;
            background: var(--login-gold);
        }

        .login-welcome h1 {
            max-width: 610px;
            margin: 0;
            color: #fff;
            font-size: clamp(2.3rem, 5vw, 4rem);
            line-height: 1.04;
            letter-spacing: -.03em;
        }

        .login-welcome p {
            max-width: 560px;
            margin: 18px 0 0;
            color: rgba(255, 255, 255, .86);
            line-height: 1.7;
            font-size: .98rem;
        }

        .welcome-note {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            width: fit-content;
            margin-top: 26px;
            padding: 10px 13px;
            border: 1px solid rgba(255, 255, 255, .13);
            border-radius: 999px;
            background: rgba(255, 255, 255, .08);
            color: #edf4ff;
            font-size: .78rem;
            font-weight: 700;
        }

        .welcome-note i {
            color: var(--login-gold);
            font-size: 1rem;
        }

        .login-card {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: clamp(26px, 4vw, 38px);
            border: 1px solid rgba(7, 29, 73, .07);
            border-radius: 26px;
            background: #fff;
            box-shadow: 0 18px 42px rgba(7, 29, 73, .09);
        }

        .login-card-head {
            margin-bottom: 24px;
        }

        .login-card-head h2 {
            margin: 0;
            color: var(--login-navy);
            font-size: 1.75rem;
            line-height: 1.2;
        }

        .login-card-head p {
            margin: 8px 0 0;
            color: var(--login-muted);
            line-height: 1.55;
            font-size: .88rem;
        }

        .secure-pill {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            width: fit-content;
            margin-bottom: 18px;
            padding: 7px 10px;
            border-radius: 999px;
            background: var(--login-soft);
            color: var(--login-blue);
            font-size: .72rem;
            font-weight: 800;
            letter-spacing: .04em;
        }

        .secure-pill i {
            font-size: 1rem;
        }

        .login-alert {
            display: flex;
            align-items: flex-start;
            gap: 9px;
            margin-bottom: 18px;
            padding: 12px 13px;
            border: 1px solid #f1cccc;
            border-radius: 12px;
            background: var(--login-danger-bg);
            color: var(--login-danger);
            font-size: .84rem;
            font-weight: 700;
            line-height: 1.5;
        }

        .login-alert i {
            margin-top: 1px;
            font-size: 1.05rem;
        }

        .login-field {
            margin-bottom: 18px;
        }

        .login-field label {
            display: block;
            margin-bottom: 7px;
            color: var(--login-navy);
            font-size: .82rem;
            font-weight: 800;
        }

        .login-input-wrap {
            position: relative;
        }

        .login-input-wrap i {
            position: absolute;
            top: 50%;
            left: 14px;
            transform: translateY(-50%);
            color: #8393a7;
            font-size: 1rem;
            pointer-events: none;
        }

        .login-field input {
            width: 100%;
            min-height: 48px;
            box-sizing: border-box;
            padding: 11px 13px 11px 41px;
            border: 1px solid #cdd9e7;
            border-radius: 12px;
            outline: none;
            background: #fff;
            color: var(--login-ink);
            font: inherit;
            font-size: .92rem;
            transition: border-color .18s ease, box-shadow .18s ease;
        }

        .login-field input:focus {
            border-color: var(--login-blue-light);
            box-shadow: 0 0 0 4px rgba(20, 86, 160, .1);
        }

        .login-field input::placeholder {
            color: #9aa8b8;
        }

        .login-options {
            display: flex;
            justify-content: flex-end;
            margin: 2px 0 20px;
        }

        .login-options a,
        .login-register a {
            color: var(--login-blue);
            font-size: .82rem;
            font-weight: 800;
            text-decoration: none;
        }

        .login-options a:hover,
        .login-register a:hover {
            color: var(--login-navy);
            text-decoration: underline;
        }

        .login-submit {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            min-height: 50px;
            padding: 13px 18px;
            border: 0;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--login-blue), var(--login-blue-light));
            color: #fff;
            font: inherit;
            font-size: .92rem;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 10px 22px rgba(20, 86, 160, .18);
            transition: transform .18s ease, box-shadow .18s ease, filter .18s ease;
        }

        .login-submit:hover {
            transform: translateY(-1px);
            filter: brightness(1.04);
            box-shadow: 0 14px 26px rgba(20, 86, 160, .22);
        }

        .login-register {
            margin: 18px 0 0;
            color: var(--login-muted);
            font-size: .82rem;
            text-align: center;
            line-height: 1.5;
        }

        .login-security {
            display: flex;
            align-items: flex-start;
            gap: 9px;
            margin-top: 20px;
            padding-top: 16px;
            border-top: 1px solid var(--login-line);
            color: #7b8a9d;
            font-size: .73rem;
            line-height: 1.5;
        }

        .login-security i {
            flex: 0 0 auto;
            margin-top: 1px;
            color: var(--login-blue);
            font-size: 1rem;
        }

        @media (max-width: 900px) {
            .login-hero {
                grid-template-columns: 1fr;
            }

            .login-welcome {
                min-height: auto;
            }
        }

        @media (max-width: 600px) {
            .login-page {
                width: min(100% - 24px, 1180px);
                padding: 26px 0 52px;
            }

            .login-welcome,
            .login-card {
                border-radius: 20px;
            }

            .login-welcome {
                padding: 30px 22px;
            }

            .login-card {
                padding: 24px 20px;
            }

            .login-brand-mark {
                width: 70px;
                height: 70px;
            }
        }
    </style>
</head>
<body>
    <?php pascco_public_header('Sign Up', 'register.php'); ?>

    <main class="login-page">
        <section class="login-hero">
            <div class="login-welcome">
                <img
                    class="login-brand-mark"
                    src="LOGO.png"
                    alt="Paco Savings and Credit Cooperative logo"
                >
                <div class="login-eyebrow">Member Portal</div>
                <h1>Welcome back to PASCCO.</h1>
                <p>
                    Sign in to securely access your savings accounts, transfers,
                    deposits, loan services, announcements, and other cooperative services.
                </p>
                <div class="welcome-note">
                    <i class="bx bx-shield-quarter" aria-hidden="true"></i>
                    Secure member access with account verification
                </div>
            </div>

            <section class="login-card" aria-labelledby="login-title">
                <div class="secure-pill">
                    <i class="bx bx-lock-alt" aria-hidden="true"></i>
                    Secure sign-in
                </div>

                <div class="login-card-head">
                    <h2 id="login-title">Member Login</h2>
                    <p>Enter your PASCCO credentials to continue to account verification.</p>
                </div>

                <?php if ($error): ?>
                    <div class="login-alert" role="alert">
                        <i class="bx bx-error-circle" aria-hidden="true"></i>
                        <div><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
                    </div>
                <?php endif; ?>

                <form method="POST" action="login.php">
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"
                    >

                    <div class="login-field">
                        <label for="username">Username</label>
                        <div class="login-input-wrap">
                            <i class="bx bx-user" aria-hidden="true"></i>
                            <input
                                id="username"
                                type="text"
                                name="username"
                                autocomplete="username"
                                placeholder="Enter your username"
                                required
                            >
                        </div>
                    </div>

                    <div class="login-field">
                        <label for="password">Password</label>
                        <div class="login-input-wrap">
                            <i class="bx bx-lock-alt" aria-hidden="true"></i>
                            <input
                                id="password"
                                type="password"
                                name="password"
                                autocomplete="current-password"
                                placeholder="Enter your password"
                                required
                            >
                        </div>
                    </div>

                    <div class="login-options">
                        <a href="forgot_password.php">Forgot password?</a>
                    </div>

                    <button class="login-submit" type="submit">
                        <i class="bx bx-log-in-circle" aria-hidden="true"></i>
                        Sign In
                    </button>
                </form>

                <p class="login-register">
                    Not yet a member?
                    <a href="register.php">Create an account</a>
                </p>

                <div class="login-security">
                    <i class="bx bx-shield-quarter" aria-hidden="true"></i>
                    <span>
                        After your password is verified, PASCCO will continue with the
                        account verification step before granting portal access.
                    </span>
                </div>
            </section>
        </section>
    </main>

    <?php pascco_global_footer(); ?>
</body>
</html>
