<?php
require_once 'db.php';
require_once 'pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: login.php');
    exit;
}

$query = trim($_GET['q'] ?? '');
$selected_id = (int) ($_GET['member_id'] ?? 0);

$from_date = trim($_GET['from'] ?? '');
$to_date = trim($_GET['to'] ?? '');
$transaction_type = trim($_GET['type'] ?? '');
$account_filter = (int) ($_GET['account_id'] ?? 0);

$members = [];
$selected_member = null;
$accounts = [];
$loans = [];
$transactions = [];

if ($query !== '') {
    $search = '%' . $query . '%';

    $member_stmt = $pdo->prepare("
        SELECT DISTINCT
            m.id,
            m.user_id,
            m.member_number,
            m.first_name,
            m.last_name,
            m.email,
            m.phone,
            m.created_at,
            u.username
        FROM members m
        JOIN users u ON u.id = m.user_id
        LEFT JOIN accounts a ON a.member_id = m.id
        LEFT JOIN transactions t ON t.account_id = a.id
        WHERE
            m.member_number LIKE ?
            OR m.first_name LIKE ?
            OR m.last_name LIKE ?
            OR m.email LIKE ?
            OR u.username LIKE ?
            OR a.account_number LIKE ?
            OR t.reference_number LIKE ?
        ORDER BY m.last_name, m.first_name
        LIMIT 30
    ");

    $member_stmt->execute([
        $search,
        $search,
        $search,
        $search,
        $search,
        $search,
        $search
    ]);

    $members = $member_stmt->fetchAll();
}

if ($selected_id > 0) {
    $detail_stmt = $pdo->prepare("
        SELECT
            m.id,
            m.member_number,
            m.first_name,
            m.last_name,
            m.email,
            m.phone,
            m.created_at,
            u.username
        FROM members m
        JOIN users u ON u.id = m.user_id
        WHERE m.id = ?
        LIMIT 1
    ");

    $detail_stmt->execute([$selected_id]);
    $selected_member = $detail_stmt->fetch();

    if ($selected_member) {
        $account_stmt = $pdo->prepare("
            SELECT
                id,
                account_number,
                account_type,
                balance,
                status,
                created_at
            FROM accounts
            WHERE member_id = ?
            ORDER BY id DESC
        ");

        $account_stmt->execute([$selected_id]);
        $accounts = $account_stmt->fetchAll();

        $loan_stmt = $pdo->prepare("
            SELECT
                loan_number,
                loan_amount,
                remaining_balance,
                status,
                application_date,
                created_at
            FROM loans
            WHERE member_id = ?
            ORDER BY id DESC
        ");

        $loan_stmt->execute([$selected_id]);
        $loans = $loan_stmt->fetchAll();

        $conditions = ['a.member_id = ?'];
        $parameters = [$selected_id];

        if ($account_filter > 0) {
            $valid_account = false;

            foreach ($accounts as $account) {
                if ((int) $account['id'] === $account_filter) {
                    $valid_account = true;
                    break;
                }
            }

            if ($valid_account) {
                $conditions[] = 'a.id = ?';
                $parameters[] = $account_filter;
            } else {
                $account_filter = 0;
            }
        }

        if (
            $from_date !== '' &&
            DateTime::createFromFormat('Y-m-d', $from_date)
        ) {
            $conditions[] = 'FROM_UNIXTIME(t.transaction_date) >= ?';
            $parameters[] = $from_date . ' 00:00:00';
        }

        if (
            $to_date !== '' &&
            DateTime::createFromFormat('Y-m-d', $to_date)
        ) {
            $conditions[] = 'FROM_UNIXTIME(t.transaction_date) <= ?';
            $parameters[] = $to_date . ' 23:59:59';
        }

        if (
            in_array(
                $transaction_type,
                ['deposit', 'withdrawal', 'transfer'],
                true
            )
        ) {
            $conditions[] = 't.transaction_type = ?';
            $parameters[] = $transaction_type;
        } else {
            $transaction_type = '';
        }

        $transaction_stmt = $pdo->prepare("
            SELECT
                t.transaction_type,
                t.amount,
                t.description,
                t.reference_number,
                t.status,
                t.transaction_date,
                a.account_number,
                a.account_type
            FROM transactions t
            JOIN accounts a ON a.id = t.account_id
            WHERE " . implode(' AND ', $conditions) . "
            ORDER BY t.id DESC
            LIMIT 500
        ");

        $transaction_stmt->execute($parameters);
        $transactions = $transaction_stmt->fetchAll();

        if (($_GET['download'] ?? '') === 'csv') {
            $safe_member_number = preg_replace(
                '/[^A-Za-z0-9_-]/',
                '_',
                (string) $selected_member['member_number']
            );

            header('Content-Type: text/csv; charset=utf-8');
            header(
                'Content-Disposition: attachment; filename="PASCCO-' .
                $safe_member_number .
                '-transactions.csv"'
            );

            $output = fopen('php://output', 'w');

            // Excel UTF-8 BOM
            fwrite($output, "\xEF\xBB\xBF");

            fputcsv($output, [
                'Date',
                'Member Number',
                'Account',
                'Account Type',
                'Transaction Type',
                'Amount',
                'Description',
                'Reference Number',
                'Status'
            ]);

            foreach ($transactions as $transaction) {
                fputcsv($output, [
                    date(
                        'Y-m-d H:i:s',
                        (int) $transaction['transaction_date']
                    ),
                    $selected_member['member_number'],
                    $transaction['account_number'],
                    $transaction['account_type'],
                    strtoupper($transaction['transaction_type']),
                    number_format((float) $transaction['amount'], 2, '.', ''),
                    $transaction['description'],
                    $transaction['reference_number'],
                    strtoupper($transaction['status'])
                ]);
            }

            fclose($output);
            exit;
        }
    }
}

$is_print_view =
    $selected_member &&
    (($_GET['print'] ?? '') === '1');

if ($is_print_view) {
    ?>
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PASCCO Transaction Report</title>
        <style>
            body {
                margin: 30px;
                color: #111827;
                font-family: Arial, Helvetica, sans-serif;
            }
            .report-head {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 20px;
                padding-bottom: 16px;
                border-bottom: 2px solid #071d49;
            }
            .report-head h1 {
                margin: 0 0 4px;
                color: #071d49;
                font-size: 22px;
            }
            .report-head p {
                margin: 2px 0;
                color: #475569;
                font-size: 13px;
            }
            .print-button {
                padding: 10px 14px;
                border: 0;
                background: #1456a0;
                color: #fff;
                cursor: pointer;
                font-weight: 700;
            }
            .filters {
                margin: 18px 0;
                padding: 12px;
                background: #f4f7fb;
                font-size: 12px;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                font-size: 11px;
            }
            th,
            td {
                padding: 8px;
                border: 1px solid #d8e0ee;
                text-align: left;
            }
            th {
                background: #e6edf8;
                color: #071d49;
            }
            .footer-note {
                margin-top: 18px;
                color: #64748b;
                font-size: 11px;
            }
            @media print {
                .print-button {
                    display: none;
                }
                body {
                    margin: 12mm;
                }
            }
        </style>
    </head>
    <body>

    <div class="report-head">
        <div>
            <h1>PASCCO Transaction Report</h1>
            <p>
                <?php
                echo htmlspecialchars(
                    $selected_member['first_name'] . ' ' .
                    $selected_member['last_name'],
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>
                ·
                <?php
                echo htmlspecialchars(
                    $selected_member['member_number'],
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>
            </p>
            <p>
                Generated:
                <?php echo date('F j, Y h:i A'); ?>
            </p>
        </div>

        <button
            class="print-button"
            type="button"
            onclick="window.print()"
        >
            Print / Save PDF
        </button>
    </div>

    <div class="filters">
        <strong>Applied filters:</strong>
        Account:
        <?php
        if ($account_filter > 0) {
            $label = 'Selected account';
            foreach ($accounts as $account) {
                if ((int) $account['id'] === $account_filter) {
                    $label =
                        $account['account_type'] . ' · ' .
                        $account['account_number'];
                    break;
                }
            }
            echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
        } else {
            echo 'All accounts';
        }
        ?>
        · From: <?php echo $from_date !== '' ? htmlspecialchars($from_date) : 'Any date'; ?>
        · To: <?php echo $to_date !== '' ? htmlspecialchars($to_date) : 'Any date'; ?>
        · Type: <?php echo $transaction_type !== '' ? htmlspecialchars(ucfirst($transaction_type)) : 'All'; ?>
    </div>

    <?php if ($transactions): ?>
        <table>
            <thead>
            <tr>
                <th>Date</th>
                <th>Account</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Description</th>
                <th>Reference</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($transactions as $transaction): ?>
                <tr>
                    <td>
                        <?php
                        echo date(
                            'M j, Y H:i',
                            (int) $transaction['transaction_date']
                        );
                        ?>
                    </td>
                    <td>
                        <?php
                        echo htmlspecialchars(
                            $transaction['account_number'],
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </td>
                    <td>
                        <?php
                        echo strtoupper(
                            htmlspecialchars(
                                $transaction['transaction_type'],
                                ENT_QUOTES,
                                'UTF-8'
                            )
                        );
                        ?>
                    </td>
                    <td>
                        ₱<?php echo number_format((float) $transaction['amount'], 2); ?>
                    </td>
                    <td>
                        <?php
                        echo htmlspecialchars(
                            $transaction['description'],
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </td>
                    <td>
                        <?php
                        echo htmlspecialchars(
                            $transaction['reference_number'],
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </td>
                    <td>
                        <?php
                        echo strtoupper(
                            htmlspecialchars(
                                $transaction['status'],
                                ENT_QUOTES,
                                'UTF-8'
                            )
                        );
                        ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No transactions match the selected filters.</p>
    <?php endif; ?>

    <div class="footer-note">
        Paco Savings and Credit Cooperative · Administrative transaction report
    </div>

    </body>
    </html>
    <?php
    exit;
}

$base_params = [
    'q' => $query,
    'member_id' => $selected_id,
    'account_id' => $account_filter,
    'from' => $from_date,
    'to' => $to_date,
    'type' => $transaction_type
];

$print_url =
    'admin_members.php?' .
    http_build_query(
        array_merge(
            $base_params,
            ['print' => '1']
        )
    );

$csv_url =
    'admin_members.php?' .
    http_build_query(
        array_merge(
            $base_params,
            ['download' => 'csv']
        )
    );
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <?php pascco_global_styles(); ?>

    <title>Member Search | PASCCO Admin</title>

    <style>
        body {
            margin: 0;
            background: #f4f7fb;
            color: #182a45;
            font-family: 'Poppins', Arial, Helvetica, sans-serif;
        }

        .admin-page {
            width: min(1180px, calc(100% - 32px));
            margin: 0 auto;
            padding: 42px 0 70px;
        }

        .heading {
            display: flex;
            align-items: end;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 24px;
        }

        .heading h1 {
            margin: 8px 0 0;
            color: #071d49;
            font-size: clamp(2rem, 4vw, 3.2rem);
        }

        .eyebrow {
            color: #1456a0;
            font-size: .8rem;
            font-weight: 700;
            letter-spacing: .16em;
            text-transform: uppercase;
        }

        .back-link {
            color: #1456a0;
            font-weight: 700;
            text-decoration: none;
        }

        .search-card,
        .card {
            margin-bottom: 22px;
            padding: 24px;
            border: 1px solid #d8e0ee;
            border-radius: 14px;
            background: #fff;
            box-shadow: 0 4px 14px rgba(7,29,73,.08);
        }

        .search-card {
            border-top: 4px solid #1456a0;
        }

        .search-form {
            display: flex;
            gap: 10px;
        }

        .search-form input,
        .filter-grid input,
        .filter-grid select {
            min-height: 44px;
            padding: 10px 12px;
            border: 1px solid #b8c8d9;
            border-radius: 8px;
            background: #fff;
            color: #182a45;
            font: inherit;
        }

        .search-form input {
            flex: 1;
        }

        .search-form button,
        .filter-submit,
        .action-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            min-height: 42px;
            padding: 0 15px;
            border: 0;
            border-radius: 8px;
            font: inherit;
            font-size: .82rem;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
        }

        .search-form button {
            background: #e7b84b;
            color: #071d49;
        }

        .results {
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(230px, 1fr)
            );
            gap: 10px;
        }

        .result {
            padding: 15px;
            border-left: 4px solid #1456a0;
            border-radius: 8px;
            background: #e6edf8;
        }

        .result h3 {
            margin: 0 0 5px;
            color: #071d49;
        }

        .result p {
            margin: 4px 0;
        }

        .result a {
            color: #1456a0;
            font-weight: 700;
        }

        .profile {
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(180px, 1fr)
            );
            gap: 10px;
        }

        .profile-item {
            padding: 13px;
            border-radius: 8px;
            background: #e6edf8;
        }

        .profile-item small {
            display: block;
            color: #5d6b7e;
        }

        .profile-item strong {
            display: block;
            margin-top: 4px;
            color: #071d49;
        }

        .transaction-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            margin-bottom: 18px;
        }

        .transaction-head h2 {
            margin: 0;
        }

        .transaction-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .action-link {
            border: 1px solid #1456a0;
            background: #fff;
            color: #1456a0;
        }

        .action-link.primary {
            background: #1456a0;
            color: #fff;
        }

        .filter-grid {
            display: grid;
            grid-template-columns:
                minmax(180px, 1fr)
                repeat(3, minmax(145px, .7fr))
                auto;
            gap: 10px;
            margin-bottom: 18px;
            padding: 16px;
            border-radius: 10px;
            background: #f4f7fb;
        }

        .filter-field {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .filter-field label {
            color: #52627a;
            font-size: .73rem;
            font-weight: 700;
        }

        .filter-submit {
            align-self: end;
            background: #071d49;
            color: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 11px 9px;
            border-bottom: 1px solid #d8e0ee;
            text-align: left;
        }

        th {
            background: #e6edf8;
            color: #071d49;
        }

        .table-wrap {
            overflow-x: auto;
        }

        .badge {
            padding: 4px 8px;
            background: #cfe0f5;
            color: #071d49;
            font-size: .78rem;
            font-weight: 700;
        }

        .badge.pending {
            background: #e7b84b;
        }

        .badge.rejected {
            background: #f8d7da;
            color: #721c24;
        }

        .empty {
            padding: 12px 0;
            color: #5d6b7e;
        }

        .history-count {
            color: #64748b;
            font-size: .82rem;
        }

        @media (max-width: 850px) {
            .filter-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .filter-submit {
                width: 100%;
            }
        }

        @media (max-width: 650px) {
            .heading,
            .transaction-head {
                align-items: flex-start;
                flex-direction: column;
            }

            .search-form,
            .filter-grid {
                grid-template-columns: 1fr;
                flex-direction: column;
            }

            .transaction-actions {
                width: 100%;
            }

            .action-link {
                flex: 1;
            }
        }
    </style>
</head>

<body>

<?php pascco_admin_header(); ?>

<main class="admin-page">

    <section class="heading">
        <div>
            <div class="eyebrow">
                Member Records
            </div>

            <h1>Search Members</h1>
        </div>

        <a
            class="back-link"
            href="admin_dashboard.php"
        >
            Back to Dashboard
        </a>
    </section>

    <section class="search-card">
        <h2>Find a member</h2>

        <form
            class="search-form"
            method="GET"
            action="admin_members.php"
        >
            <input
                name="q"
                value="<?php
                    echo htmlspecialchars(
                        $query,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                ?>"
                placeholder="Name, member number, email, username, account, or OR number"
                required
            >

            <button type="submit">
                Search
            </button>
        </form>
    </section>

    <?php if ($query !== '' && !$selected_member): ?>

        <section class="card">
            <h2>Search Results</h2>

            <?php if ($members): ?>

                <div class="results">

                    <?php foreach ($members as $member): ?>

                        <article class="result">
                            <h3>
                                <?php
                                echo htmlspecialchars(
                                    $member['first_name'] .
                                    ' ' .
                                    $member['last_name']
                                );
                                ?>
                            </h3>

                            <p>
                                <?php
                                echo htmlspecialchars(
                                    $member['member_number']
                                );
                                ?>
                            </p>

                            <p>
                                <?php
                                echo htmlspecialchars(
                                    $member['email']
                                );
                                ?>
                            </p>

                            <a
                                href="admin_members.php?q=<?php
                                    echo urlencode($query);
                                ?>&member_id=<?php
                                    echo (int) $member['id'];
                                ?>"
                            >
                                View financial history
                            </a>
                        </article>

                    <?php endforeach; ?>

                </div>

            <?php else: ?>

                <p class="empty">
                    No members matched your search.
                </p>

            <?php endif; ?>

        </section>

    <?php endif; ?>

    <?php if ($selected_member): ?>

        <section class="card">
            <h2>
                <?php
                echo htmlspecialchars(
                    $selected_member['first_name'] .
                    ' ' .
                    $selected_member['last_name']
                );
                ?>
            </h2>

            <div class="profile">
                <div class="profile-item">
                    <small>Member Number</small>
                    <strong>
                        <?php
                        echo htmlspecialchars(
                            $selected_member['member_number']
                        );
                        ?>
                    </strong>
                </div>

                <div class="profile-item">
                    <small>Email</small>
                    <strong>
                        <?php
                        echo htmlspecialchars(
                            $selected_member['email']
                        );
                        ?>
                    </strong>
                </div>

                <div class="profile-item">
                    <small>Phone</small>
                    <strong>
                        <?php
                        echo htmlspecialchars(
                            $selected_member['phone']
                        );
                        ?>
                    </strong>
                </div>

                <div class="profile-item">
                    <small>Username</small>
                    <strong>
                        <?php
                        echo htmlspecialchars(
                            $selected_member['username']
                        );
                        ?>
                    </strong>
                </div>
            </div>
        </section>

        <section class="card">
            <h2>Savings Accounts</h2>

            <?php if ($accounts): ?>

                <div class="table-wrap">
                    <table>
                        <thead>
                        <tr>
                            <th>Account</th>
                            <th>Type</th>
                            <th>Balance</th>
                            <th>Status</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php foreach ($accounts as $account): ?>
                            <tr>
                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $account['account_number']
                                    );
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $account['account_type']
                                    );
                                    ?>
                                </td>
                                <td>
                                    <strong>
                                        ₱<?php
                                        echo number_format(
                                            (float) $account['balance'],
                                            2
                                        );
                                        ?>
                                    </strong>
                                </td>
                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $account['status']
                                    );
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php else: ?>

                <p class="empty">
                    No savings accounts found.
                </p>

            <?php endif; ?>
        </section>

        <section class="card">
            <h2>Loan History</h2>

            <?php if ($loans): ?>

                <div class="table-wrap">
                    <table>
                        <thead>
                        <tr>
                            <th>Loan</th>
                            <th>Original Amount</th>
                            <th>Remaining</th>
                            <th>Status</th>
                            <th>Applied</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php foreach ($loans as $loan): ?>
                            <tr>
                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $loan['loan_number']
                                    );
                                    ?>
                                </td>
                                <td>
                                    ₱<?php
                                    echo number_format(
                                        (float) $loan['loan_amount'],
                                        2
                                    );
                                    ?>
                                </td>
                                <td>
                                    ₱<?php
                                    echo number_format(
                                        (float) $loan['remaining_balance'],
                                        2
                                    );
                                    ?>
                                </td>
                                <td>
                                    <span
                                        class="badge <?php
                                            echo htmlspecialchars(
                                                $loan['status']
                                            );
                                        ?>"
                                    >
                                        <?php
                                        echo strtoupper(
                                            htmlspecialchars(
                                                $loan['status']
                                            )
                                        );
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $loan['application_date']
                                    );
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php else: ?>

                <p class="empty">
                    No loan history found.
                </p>

            <?php endif; ?>
        </section>

        <section class="card">

            <div class="transaction-head">
                <div>
                    <h2>Transaction History</h2>
                    <div class="history-count">
                        <?php echo count($transactions); ?>
                        transaction<?php echo count($transactions) === 1 ? '' : 's'; ?>
                        in this view
                    </div>
                </div>

                <div class="transaction-actions">
                    <a
                        class="action-link primary"
                        href="<?php
                            echo htmlspecialchars(
                                $print_url,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?>"
                        target="_blank"
                        rel="noopener"
                    >
                        <i class="bx bx-printer"></i>
                        Print / Save PDF
                    </a>

                    <a
                        class="action-link"
                        href="<?php
                            echo htmlspecialchars(
                                $csv_url,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?>"
                    >
                        <i class="bx bx-download"></i>
                        Download CSV
                    </a>
                </div>
            </div>

            <form
                method="GET"
                action="admin_members.php"
                class="filter-grid"
            >
                <input
                    type="hidden"
                    name="q"
                    value="<?php
                        echo htmlspecialchars(
                            $query,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                    ?>"
                >

                <input
                    type="hidden"
                    name="member_id"
                    value="<?php echo $selected_id; ?>"
                >

                <div class="filter-field">
                    <label for="account-filter">
                        Savings Account
                    </label>

                    <select
                        id="account-filter"
                        name="account_id"
                    >
                        <option value="0">
                            All Accounts
                        </option>

                        <?php foreach ($accounts as $account): ?>
                            <option
                                value="<?php
                                    echo (int) $account['id'];
                                ?>"
                                <?php
                                echo
                                    (int) $account['id'] === $account_filter
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                <?php
                                echo htmlspecialchars(
                                    $account['account_type'] .
                                    ' · ' .
                                    $account['account_number'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="filter-field">
                    <label for="from-date">
                        From Date
                    </label>

                    <input
                        id="from-date"
                        type="date"
                        name="from"
                        value="<?php
                            echo htmlspecialchars(
                                $from_date,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?>"
                    >
                </div>

                <div class="filter-field">
                    <label for="to-date">
                        To Date
                    </label>

                    <input
                        id="to-date"
                        type="date"
                        name="to"
                        value="<?php
                            echo htmlspecialchars(
                                $to_date,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?>"
                    >
                </div>

                <div class="filter-field">
                    <label for="type-filter">
                        Transaction Type
                    </label>

                    <select
                        id="type-filter"
                        name="type"
                    >
                        <option value="">
                            All Transactions
                        </option>

                        <option
                            value="deposit"
                            <?php
                            echo
                                $transaction_type === 'deposit'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            Deposits
                        </option>

                        <option
                            value="withdrawal"
                            <?php
                            echo
                                $transaction_type === 'withdrawal'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            Withdrawals
                        </option>

                        <option
                            value="transfer"
                            <?php
                            echo
                                $transaction_type === 'transfer'
                                ? 'selected'
                                : '';
                            ?>
                        >
                            Transfers
                        </option>
                    </select>
                </div>

                <button
                    type="submit"
                    class="filter-submit"
                >
                    <i class="bx bx-filter-alt"></i>
                    Filter
                </button>
            </form>

            <?php if ($transactions): ?>

                <div class="table-wrap">
                    <table>
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Account</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Description</th>
                            <th>OR Number</th>
                            <th>Status</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php foreach ($transactions as $transaction): ?>
                            <tr>
                                <td>
                                    <?php
                                    echo date(
                                        'M j, Y H:i',
                                        (int) $transaction['transaction_date']
                                    );
                                    ?>
                                </td>

                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $transaction['account_number']
                                    );
                                    ?>
                                </td>

                                <td>
                                    <?php
                                    echo strtoupper(
                                        htmlspecialchars(
                                            $transaction['transaction_type']
                                        )
                                    );
                                    ?>
                                </td>

                                <td>
                                    ₱<?php
                                    echo number_format(
                                        (float) $transaction['amount'],
                                        2
                                    );
                                    ?>
                                </td>

                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $transaction['description']
                                    );
                                    ?>
                                </td>

                                <td>
                                    <small>
                                        <?php
                                        echo htmlspecialchars(
                                            $transaction['reference_number']
                                        );
                                        ?>
                                    </small>
                                </td>

                                <td>
                                    <?php
                                    echo strtoupper(
                                        htmlspecialchars(
                                            $transaction['status']
                                        )
                                    );
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php else: ?>

                <p class="empty">
                    No transactions match the selected filters.
                </p>

            <?php endif; ?>

        </section>

    <?php endif; ?>

</main>

<?php pascco_global_footer(); ?>

</body>
</html>
