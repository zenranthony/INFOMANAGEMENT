<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: login.php');
    exit;
}

$message = '';
$error = '';
$status_filter = $_GET['status'] ?? 'pending';
$allowed_statuses = ['pending', 'approved', 'rejected'];
if (!in_array($status_filter, $allowed_statuses, true)) {
    $status_filter = 'pending';
}

$requests_stmt = $pdo->prepare('SELECT ar.id, ar.member_id, ar.account_type, ar.status, ar.requested_at, ar.admin_notes, m.first_name, m.last_name, m.member_number FROM account_requests ar JOIN members m ON m.id = ar.member_id WHERE ar.status = ? ORDER BY ar.requested_at DESC');
$requests_stmt->execute([$status_filter]);
$requests = $requests_stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $request_id = (int) ($_POST['request_id'] ?? 0);
    $decision = trim($_POST['decision'] ?? '');
    $admin_notes = trim($_POST['admin_notes'] ?? '');

    if ($request_id <= 0 || !in_array($decision, ['approved', 'rejected'], true)) {
        $error = 'Invalid account request.';
    } else {
        try {
            $request = $pdo->prepare('SELECT ar.member_id, ar.account_type, m.user_id FROM account_requests ar JOIN members m ON m.id = ar.member_id WHERE ar.id = ? LIMIT 1');
            $request->execute([$request_id]);
            $record = $request->fetch();

            if (!$record) {
                throw new RuntimeException('Account request not found.');
            }

            $pdo->beginTransaction();

            $update = $pdo->prepare('UPDATE account_requests SET status = ?, admin_notes = ?, reviewed_by = ?, reviewed_at = NOW() WHERE id = ?');
            $update->execute([$decision, $admin_notes, (int) $_SESSION['user_id'], $request_id]);

            if ($decision === 'approved') {
                $account_number = 'ACC-' . str_pad((string) ((int) $pdo->query('SELECT COUNT(*) FROM accounts')->fetchColumn() + 10000001), 8, '0', STR_PAD_LEFT);
                $insert_account = $pdo->prepare('INSERT INTO accounts (member_id, account_number, account_type, balance, status) VALUES (?, ?, ?, 0, "active")');
                $insert_account->execute([(int) $record['member_id'], $account_number, $record['account_type']]);
            }

            $pdo->commit();
            record_audit($pdo, (int) $_SESSION['user_id'], 'account_request_review', 'Reviewed account request #' . $request_id . ' -> ' . $decision, 'success');
            $message = 'Account request updated successfully.';
            $requests_stmt->execute([$status_filter]);
            $requests = $requests_stmt->fetchAll();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $exception->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php pascco_global_styles(); ?>
<title>Account Requests | PASCCO Admin</title>

<style>
:root{--navy:#071d49;--blue:#1456a0;--blue2:#2b74c8;--gold:#e7b84b;--gold-light:#ffe7a1;--ink:#18324f;--muted:#6e7e93;--line:#dce5ef;--bg:#f4f7fb;--surface:#fff;--soft:#eef4fb;--success:#1c7442;--danger:#b52f38;--shadow:0 16px 40px rgba(7,29,73,.08)}
html,body{margin:0!important;padding:0!important;overflow-x:hidden}body{background:linear-gradient(180deg,#edf4fb 0,#f7f9fc 360px,var(--bg) 100%);color:var(--ink);font-family:Poppins,Arial,sans-serif}.admin-wrap{width:min(100% - 40px,1200px);margin:0 auto;padding:34px 0 58px}.page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:22px}.eyebrow{display:inline-flex;align-items:center;gap:8px;color:var(--blue);font-size:.74rem;font-weight:800;letter-spacing:.15em;text-transform:uppercase}.eyebrow:before{content:"";width:28px;height:3px;background:var(--gold);border-radius:999px}.page-head h1{margin:8px 0 0;color:var(--navy);font-size:clamp(2rem,4vw,3rem);line-height:1.05}.page-head p{margin:10px 0 0;color:var(--muted);line-height:1.6}.head-actions,.quick-actions{display:flex;gap:9px;flex-wrap:wrap}.button{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:11px 15px;border-radius:11px;background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;text-decoration:none;font-weight:800;font-size:.86rem;box-shadow:0 8px 18px rgba(20,86,160,.15)}.button.secondary{background:#fff;border:1px solid #cdd8e5;color:var(--navy);box-shadow:none}.button.gold{background:var(--gold);color:var(--navy)}.surface{background:var(--surface);border:1px solid rgba(7,29,73,.07);border-radius:20px;box-shadow:var(--shadow);overflow:hidden}.surface-head{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:21px 23px;border-bottom:1px solid var(--line)}.surface-head h2,.surface-head h3{margin:0;color:var(--navy);font-size:1.15rem}.surface-head p{margin:5px 0 0;color:var(--muted);font-size:.86rem}.surface-body{padding:22px}.stat-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin-bottom:20px}.stat{position:relative;padding:20px;border-radius:18px;background:#fff;border:1px solid rgba(7,29,73,.07);box-shadow:var(--shadow);overflow:hidden}.stat:after{content:"";position:absolute;right:-35px;top:-35px;width:120px;height:120px;border:1px solid rgba(20,86,160,.10);border-radius:50%;box-shadow:0 0 0 22px rgba(20,86,160,.025)}.stat .label{color:#78889b;font-size:.72rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase}.stat .value{margin-top:8px;color:var(--navy);font-size:1.65rem;font-weight:800;line-height:1.15}.stat.gold{border-top:4px solid var(--gold)}.stat.blue{border-top:4px solid var(--blue)}.grid-2{display:grid;grid-template-columns:1.35fr .65fr;gap:20px}.grid-2.equal{grid-template-columns:1fr 1fr}.stack{display:grid;gap:20px}.status-grid{display:grid;grid-template-columns:1fr 1fr;gap:11px}.status-tile{padding:14px;border-radius:13px;background:var(--soft);border:1px solid var(--line)}.status-tile span{display:block;color:var(--muted);font-size:.75rem}.status-tile strong{display:block;margin-top:4px;color:var(--navy);font-size:1.3rem}.status-tile.gold{background:#fff8df;border-color:#f0dda2}.status-tile.green{background:#eef9f2;border-color:#cde8d6}.status-tile.red{background:#fff1f1;border-color:#f0cccc}.table-wrap{overflow:auto}.admin-table{width:100%;min-width:640px;border-collapse:collapse}.admin-table th,.admin-table td{padding:13px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.82rem}.admin-table th{background:#f3f7fc;color:var(--navy);font-weight:800;position:sticky;top:0}.admin-table tr:hover td{background:#fbfdff}.sub{display:block;color:#8694a5;font-size:.72rem;margin-top:3px}.badge,.status-pill{display:inline-flex;align-items:center;gap:5px;padding:5px 9px;border-radius:999px;background:#e8f0fa;color:var(--navy);font-size:.7rem;font-weight:800;text-transform:uppercase}.badge.pending,.status-pill.pending{background:#fff0bf;color:#8a6500}.badge.approved,.status-pill.approved,.badge.paid{background:#e4f6ea;color:#17673b}.badge.rejected,.status-pill.rejected{background:#fde7e7;color:#a52f37}.badge.under_review,.status-pill.under_review{background:#efe8ff;color:#6945a6}.badge.scheduled,.status-pill.scheduled{background:#e9f3ff;color:#2966a8}.badge.certificate_uploaded,.status-pill.certificate_uploaded{background:#e5f8ed;color:#25714a}.notice{padding:13px 15px;border-radius:12px;margin-bottom:18px;font-weight:700;font-size:.86rem}.notice.success{background:#eaf8f0;border:1px solid #cfe9d9;color:var(--success)}.notice.error{background:#fff0f0;border:1px solid #f0cfd0;color:var(--danger)}.toolbar{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}.search-form{display:flex;gap:8px;width:min(100%,480px)}.field{margin-bottom:15px}.field label{display:block;margin-bottom:7px;color:var(--navy);font-size:.78rem;font-weight:800}.field input,.field select,.field textarea,.search-form input{width:100%;box-sizing:border-box;min-height:46px;padding:11px 13px;border:1px solid #cad6e3;border-radius:11px;background:#fff;color:var(--ink);font:inherit;outline:none}.field textarea{min-height:110px;resize:vertical}.field input:focus,.field select:focus,.field textarea:focus,.search-form input:focus{border-color:var(--blue2);box-shadow:0 0 0 4px rgba(20,86,160,.09)}.search-form input{flex:1}.search-form button,.action-btn{border:0;border-radius:11px;padding:11px 15px;background:var(--navy);color:#fff;font:inherit;font-weight:800;cursor:pointer}.filter-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.filter-row select{min-height:44px;border:1px solid #cad6e3;border-radius:11px;padding:9px 12px;background:#fff;font:inherit}.detail-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.detail-box{padding:13px;border:1px solid var(--line);border-radius:13px;background:#f8fbff}.detail-box small{display:block;color:#8291a2;font-size:.7rem}.detail-box strong{display:block;margin-top:4px;color:var(--navy);font-size:.84rem;line-height:1.45}.record-list{display:grid;gap:12px}.record{padding:17px;border:1px solid var(--line);border-radius:15px;background:#fbfdff}.record-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.record h3{margin:0;color:var(--navy);font-size:1rem}.record p{margin:5px 0;color:var(--muted);font-size:.82rem;line-height:1.5}.record-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:13px}.mini-link{color:var(--blue);font-weight:800;text-decoration:none;font-size:.82rem}.empty{padding:26px;text-align:center;color:var(--muted);background:#f8fbff;border:1px dashed #cdd9e5;border-radius:14px}.amount{color:var(--blue);font-weight:800;white-space:nowrap}.approval-card{padding:19px;border:1px solid var(--line);border-radius:17px;background:#fff}.approval-card+.approval-card{margin-top:12px}.approval-meta{color:var(--muted);font-size:.78rem}.approval-top{display:flex;justify-content:space-between;gap:15px;align-items:flex-start}.approval-top h3{margin:0;color:var(--navy);font-size:1rem}.approval-details{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:16px 0}.approval-details div{padding-top:9px;border-top:1px solid var(--line)}.approval-details small,.identity-grid small{display:block;color:#8291a2;font-size:.7rem}.approval-details strong,.identity-grid strong{display:block;margin-top:3px;color:var(--navy);font-size:.82rem;line-height:1.45}.identity-panel{padding:16px;border-radius:15px;background:#fffaf0;border:1px solid #ecdca8}.identity-panel h4{margin:0 0 12px;color:var(--navy)}.identity-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 14px}.document-links{display:flex;flex-wrap:wrap;gap:9px;margin-top:13px}.document-links a,.receipt-link{color:var(--blue);font-weight:800;text-decoration:none;font-size:.8rem}.review-form{display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;margin-top:13px}.review-form textarea{flex:1;min-width:220px;min-height:45px;padding:10px;border:1px solid #cad6e3;border-radius:10px;font:inherit}.btn-success,.btn-danger,.btn-primary{border:0;border-radius:10px;padding:10px 13px;font:inherit;font-weight:800;cursor:pointer}.btn-success{background:#267748;color:#fff}.btn-danger{background:#b8323b;color:#fff}.btn-primary{background:var(--blue);color:#fff}.announcement-grid{display:grid;grid-template-columns:.7fr 1.3fr;gap:20px}.announcement-card{padding:18px;border:1px solid var(--line);border-radius:16px;background:#fff}.announcement-card img{width:100%;max-height:190px;object-fit:cover;border-radius:12px;margin-bottom:12px}.announcement-card h3{margin:0;color:var(--navy);font-size:1rem}.announcement-card p{color:var(--muted);line-height:1.55;font-size:.82rem;white-space:pre-line}.announcement-card+.announcement-card{margin-top:12px}.profile-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.quick-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.quick-card{padding:16px;border-radius:15px;background:#f8fbff;border:1px solid var(--line)}.quick-card i{font-size:1.35rem;color:var(--blue)}.quick-card strong{display:block;margin-top:8px;color:var(--navy)}.quick-card span{display:block;margin-top:4px;color:var(--muted);font-size:.76rem;line-height:1.45}.mt{margin-top:20px}@media(max-width:1000px){.stat-grid{grid-template-columns:repeat(2,1fr)}.grid-2,.grid-2.equal,.announcement-grid{grid-template-columns:1fr}.detail-grid,.profile-grid,.approval-details,.identity-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.quick-grid{grid-template-columns:1fr 1fr}}@media(max-width:700px){.admin-wrap{width:min(100% - 28px,1200px);padding-top:24px}.page-head{align-items:flex-start;flex-direction:column}.head-actions,.quick-actions{width:100%}.button{flex:1}.stat-grid{grid-template-columns:1fr}.surface-head,.surface-body{padding:17px}.detail-grid,.profile-grid,.approval-details,.identity-grid,.quick-grid{grid-template-columns:1fr}.search-form{width:100%}.search-form button{white-space:nowrap}.approval-top,.record-head{flex-direction:column}.review-form{align-items:stretch;flex-direction:column}.review-form textarea{min-width:0}.review-form button{width:100%}}
</style>

</head>
<body>
<?php pascco_admin_header(); ?>

<main class="admin-wrap">
<section class="page-head"><div><div class="eyebrow">Account services</div><h1>Account Requests</h1><p>Review member requests to open new savings accounts and activate approved products.</p></div><a class="button secondary" href="admin_dashboard.php"><i class="bx bx-arrow-back"></i> Dashboard</a></section>
<?php if($message): ?><div class="notice success"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?><?php if($error): ?><div class="notice error"><?php echo htmlspecialchars($error,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<section class="surface"><div class="surface-head"><div><h2>Request Filter</h2><p>Switch between pending, approved, and rejected account requests.</p></div></div><div class="surface-body"><div class="filter-row"><label for="status-filter"><strong>Status</strong></label><select id="status-filter" onchange="window.location='admin_account_requests.php?status='+encodeURIComponent(this.value)"><?php foreach($allowed_statuses as $status): ?><option value="<?php echo htmlspecialchars($status,ENT_QUOTES,'UTF-8'); ?>" <?php echo $status_filter===$status?'selected':''; ?>><?php echo ucfirst($status); ?></option><?php endforeach; ?></select></div></div></section>
<section class="surface mt"><div class="surface-head"><div><h2>Account Requests</h2><p><?php echo count($requests); ?> request<?php echo count($requests)===1?'':'s'; ?> in this status.</p></div></div><div class="surface-body"><div class="record-list"><?php if($requests): foreach($requests as $request): ?><article class="record"><div class="record-head"><div><h3><?php echo htmlspecialchars($request['first_name'].' '.$request['last_name']); ?></h3><p><?php echo htmlspecialchars($request['member_number']); ?> · Requested <?php echo htmlspecialchars($request['requested_at']); ?></p></div><span class="status-pill <?php echo htmlspecialchars($request['status']); ?>"><?php echo strtoupper(htmlspecialchars($request['status'])); ?></span></div><div class="detail-grid mt"><div class="detail-box"><small>Account Type</small><strong><?php echo htmlspecialchars($request['account_type']); ?></strong></div><div class="detail-box"><small>Request ID</small><strong>#<?php echo (int)$request['id']; ?></strong></div><div class="detail-box"><small>Member</small><strong><?php echo htmlspecialchars($request['first_name'].' '.$request['last_name']); ?></strong></div><div class="detail-box"><small>Admin Notes</small><strong><?php echo htmlspecialchars($request['admin_notes']?:'None'); ?></strong></div></div><?php if($request['status']==='pending'): ?><form method="POST" action="admin_account_requests.php?status=<?php echo urlencode($status_filter); ?>" class="review-form"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="request_id" value="<?php echo (int)$request['id']; ?>"><select name="decision" aria-label="Decision" required><option value="approved">Approve</option><option value="rejected">Reject</option></select><textarea name="admin_notes" placeholder="Add notes for the member"><?php echo htmlspecialchars($request['admin_notes']??'',ENT_QUOTES,'UTF-8'); ?></textarea><button class="btn-success" type="submit"><i class="bx bx-check"></i> Save Decision</button></form><?php endif; ?></article><?php endforeach; else: ?><div class="empty">No account requests found in this status.</div><?php endif; ?></div></div></section>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
