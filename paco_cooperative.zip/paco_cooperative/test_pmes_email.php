<?php

require_once 'db.php';
require_once 'mail_config.php';

if (
    !isset($_SESSION['user_id']) ||
    ($_SESSION['role'] ?? '') !== 'admin'
) {
    exit('Admin access required.');
}

// Put your own email here first
$recipientEmail = 'YOUR_PERSONAL_EMAIL@gmail.com';

$sent = sendPmesScheduleEmail(
    $recipientEmail,
    'Test Applicant',
    'September 20, 2026',
    '1:00 PM',
    'Online',
    '',
    'https://meet.google.com/test-link'
);

if ($sent) {
    echo 'PMES test email sent successfully.';
} else {
    echo 'Email could not be sent. Check the PHP error log.';
}