<?php
require_once 'pascco_layout.php';
pascco_header('Membership Requirements', 'requirements');
?>
<style>
    .requirements-intro { max-width:800px; }
    .requirements-grid { display:grid; gap:22px; grid-template-columns:repeat(3,minmax(0,1fr)); margin-top:30px; }
    .requirement-card { background:#fff; border:1px solid #d8e0ee; border-radius:20px; padding:27px; box-shadow:0 10px 28px rgba(7,29,73,.07); }
    .requirement-icon { width:48px; height:48px; display:grid; place-items:center; border-radius:14px; background:#e6edf8; color:#1456a0; font-size:1.4rem; margin-bottom:15px; }
    .requirement-card h2 { color:#071d49; margin-bottom:15px; }
    .requirement-card ul { list-style:none; padding:0; margin:0; }
    .requirement-card li { position:relative; padding:11px 0 11px 28px; border-top:1px solid #edf1f7; line-height:1.5; }
    .requirement-card li::before { content:'•'; position:absolute; left:8px; color:#e7b84b; font-size:1.3rem; line-height:1.2; }
    .steps { margin-top:24px; background:#071d49; color:#fff; border-radius:20px; padding:28px; }
    .steps h2 { color:#fff; margin-top:0; }
    .steps p { color:rgba(255,255,255,.86); line-height:1.65; margin-bottom:0; }
    .requirement-actions { margin-top:24px; display:flex; flex-wrap:wrap; gap:10px; }
    .requirement-actions .button { margin:0; }
    @media(max-width:900px){ .requirements-grid{grid-template-columns:1fr;} }
</style>
<main class="page-shell">
    <div class="eyebrow">Start your membership journey</div>
    <h1>Qualifications &amp; Requirements</h1>
    <p class="intro requirements-intro">Review the basic qualifications, documents, and required payments before completing your PASCCO membership application.</p>

    <section class="requirements-grid">
        <article class="requirement-card">
            <div class="requirement-icon"><i class='bx bx-user-check'></i></div>
            <h2>Qualifications</h2>
            <ul><li>Legitimate Filipino citizen</li><li>18 years old and above</li><li>Willing and able to save</li></ul>
        </article>
        <article class="requirement-card">
            <div class="requirement-icon"><i class='bx bx-file'></i></div>
            <h2>Documents</h2>
            <ul><li>2x2 ID picture</li><li>Barangay certification</li><li>PSA birth certificate</li><li>Valid government-issued ID</li><li>Proof of billing</li><li>TIN</li></ul>
        </article>
        <article class="requirement-card">
            <div class="requirement-icon"><i class='bx bx-wallet'></i></div>
            <h2>Required Payments</h2>
            <ul><li>Seminar fee</li><li>Membership fee</li><li>ID</li><li>Damay Fund</li><li>Saving deposit</li></ul>
        </article>
    </section>

    <section class="steps">
        <h2>Before you register</h2>
        <p>Prepare your identification documents and review the membership process. Completing your requirements early can help make your application smoother and easier to process.</p>
        <div class="requirement-actions">
            <a class="button" href="register.php">Register Online</a>
            <a class="button secondary" href="membership_documents.php">Complete Membership Application</a>
        </div>
    </section>
</main>
<?php pascco_footer(); ?>
