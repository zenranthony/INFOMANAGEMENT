(function () {
    "use strict";

    function initPASCCOSidebar() {

        /* =========================================================
           1. CHECK IF USER IS LOGGED IN
        ========================================================= */

        const accountElement = document.querySelector(
            ".pascco-global-account"
        );

        const accountName = document.querySelector(
            ".pascco-account-name"
        );

        const logoutLink = document.querySelector(
            '.pascco-global-account a[href*="logout"], a[href*="logout.php"]'
        );

        // Sidebar is only for logged-in members
        if (!accountElement && !accountName && !logoutLink) {
            return;
        }


        /* =========================================================
           2. PREVENT DUPLICATE INITIALIZATION
        ========================================================= */

        if (document.getElementById("pascco-sidebar")) {
            return;
        }


        /* =========================================================
           3. LOAD BOXICONS IF NOT ALREADY LOADED
        ========================================================= */

        if (!document.getElementById("boxicons-cdn")) {

            const boxicons = document.createElement("link");

            boxicons.id = "boxicons-cdn";
            boxicons.rel = "stylesheet";
            boxicons.href =
                "https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css";

            document.head.appendChild(boxicons);
        }


        /* =========================================================
           4. LOAD POPPINS FONT IF NOT ALREADY LOADED
        ========================================================= */

        if (!document.getElementById("sidebar-font")) {

            const font = document.createElement("link");

            font.id = "sidebar-font";
            font.rel = "stylesheet";
            font.href =
                "https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap";

            document.head.appendChild(font);
        }


        /* =========================================================
           5. SIDEBAR CSS
        ========================================================= */

        if (!document.getElementById("pascco-sidebar-styles")) {

            const style = document.createElement("style");

            style.id = "pascco-sidebar-styles";

            style.textContent = `

                :root {
                    --pascco-blue: #092e5c;
                    --pascco-gold: #f4c542;
                    --pascco-sidebar-width: 280px;
                    --pascco-sidebar-text: #333333;
                }


                /* =================================================
                   HAMBURGER / SIDEBAR TOGGLE
                ================================================= */

                .pascco-sidebar-toggle {

                    display: inline-flex !important;

                    align-items: center;
                    justify-content: center;

                    width: 46px;
                    height: 46px;

                    margin: 0 10px 0 0;

                    padding: 0;

                    border: none;

                    background: transparent;

                    color: #ffffff;

                    font-size: 30px;

                    cursor: pointer;

                    flex: 0 0 46px;

                    z-index: 1000000;

                    transition:
                        color 0.2s ease,
                        transform 0.2s ease;
                }


                .pascco-sidebar-toggle:hover {
                    color: var(--pascco-gold);
                }


                .pascco-sidebar-toggle:focus-visible {
                    outline: 2px solid var(--pascco-gold);
                    outline-offset: 2px;
                    border-radius: 6px;
                }


                .pascco-sidebar-toggle i {
                    font-size: 30px;
                    line-height: 1;
                }


                /* =================================================
                   OVERLAY
                ================================================= */

                #pascco-sidebar-overlay {

                    position: fixed !important;

                    inset: 0 !important;

                    width: 100vw !important;
                    height: 100vh !important;

                    background: rgba(0, 0, 0, 0.50) !important;

                    z-index: 999998 !important;

                    opacity: 0 !important;

                    visibility: hidden !important;

                    pointer-events: none !important;

                    transition:
                        opacity 0.3s ease,
                        visibility 0.3s ease !important;
                }


                #pascco-sidebar-overlay.is-open {

                    opacity: 1 !important;

                    visibility: visible !important;

                    pointer-events: auto !important;
                }


                /* =================================================
                   SIDEBAR
                ================================================= */

                #pascco-sidebar {

                    position: fixed !important;

                    top: 0 !important;
                    left: 0 !important;

                    width: var(--pascco-sidebar-width) !important;

                    height: 100vh !important;

                    max-height: 100vh !important;

                    padding: 20px 15px !important;

                    box-sizing: border-box !important;

                    background: #ffffff !important;

                    box-shadow:
                        5px 0 25px rgba(0, 0, 0, 0.25) !important;

                    z-index: 999999 !important;

                    font-family:
                        "Poppins",
                        sans-serif !important;

                    overflow-y: auto !important;
                    overflow-x: hidden !important;

                    transform: translateX(-100%) !important;

                    transition:
                        transform 0.35s
                        cubic-bezier(0.25, 1, 0.5, 1) !important;
                }


                #pascco-sidebar.is-open {

                    transform: translateX(0) !important;
                }


                /* =================================================
                   SIDEBAR HEADER
                ================================================= */

                .pascco-sidebar-header {

                    display: flex !important;

                    align-items: center !important;

                    justify-content: space-between !important;

                    gap: 10px !important;

                    padding: 4px 4px 16px !important;

                    margin-bottom: 16px !important;

                    border-bottom:
                        2px solid #f0f0f0 !important;
                }


                .pascco-sidebar-user {

                    display: flex !important;

                    flex-direction: column !important;

                    min-width: 0 !important;
                }


                .pascco-sidebar-user-name {

                    display: block !important;

                    color: var(--pascco-blue) !important;

                    font-size: 17px !important;

                    font-weight: 700 !important;

                    line-height: 1.3 !important;

                    white-space: nowrap !important;

                    overflow: hidden !important;

                    text-overflow: ellipsis !important;

                    max-width: 210px !important;
                }


                .pascco-sidebar-profile {

                    display: inline-flex !important;

                    align-items: center !important;

                    gap: 5px !important;

                    margin-top: 4px !important;

                    color: #707070 !important;

                    font-size: 12px !important;

                    font-weight: 500 !important;

                    text-decoration: none !important;
                }


                .pascco-sidebar-profile:hover {

                    color: var(--pascco-blue) !important;
                }


                .pascco-sidebar-profile i {

                    font-size: 16px !important;
                }


                /* =================================================
                   CLOSE BUTTON
                ================================================= */

                .pascco-sidebar-close {

                    display: inline-flex !important;

                    align-items: center !important;

                    justify-content: center !important;

                    width: 38px !important;
                    height: 38px !important;

                    padding: 0 !important;

                    border: none !important;

                    border-radius: 8px !important;

                    background: transparent !important;

                    color: #444444 !important;

                    font-size: 27px !important;

                    cursor: pointer !important;

                    flex-shrink: 0 !important;

                    transition:
                        background 0.2s ease,
                        color 0.2s ease !important;
                }


                .pascco-sidebar-close:hover {

                    background: #f2f4f7 !important;

                    color: var(--pascco-blue) !important;
                }


                .pascco-sidebar-close:focus-visible {

                    outline:
                        2px solid var(--pascco-blue) !important;

                    outline-offset: 2px !important;
                }


                /* =================================================
                   SIDEBAR NAVIGATION
                ================================================= */

                .pascco-sidebar-nav {

                    display: flex !important;

                    flex-direction: column !important;

                    gap: 6px !important;

                    padding: 0 !important;

                    margin: 0 !important;
                }


                .pascco-sidebar-link {

                    display: flex !important;

                    align-items: center !important;

                    width: 100% !important;

                    min-height: 46px !important;

                    padding: 10px 14px !important;

                    box-sizing: border-box !important;

                    border-radius: 9px !important;

                    color: var(--pascco-sidebar-text) !important;

                    background: transparent !important;

                    text-decoration: none !important;

                    font-size: 14px !important;

                    font-weight: 500 !important;

                    transition:
                        background 0.2s ease,
                        color 0.2s ease,
                        transform 0.2s ease !important;
                }


                .pascco-sidebar-link i {

                    width: 25px !important;

                    margin-right: 12px !important;

                    color: #555555 !important;

                    font-size: 21px !important;

                    line-height: 1 !important;

                    flex-shrink: 0 !important;

                    transition: color 0.2s ease !important;
                }


                .pascco-sidebar-link span {

                    flex: 1 !important;
                }


                .pascco-sidebar-link:hover {

                    background: #f1f4f8 !important;

                    color: var(--pascco-blue) !important;

                    transform: translateX(2px);
                }


                .pascco-sidebar-link:hover i {

                    color: var(--pascco-blue) !important;
                }


                /* =================================================
                   ACTIVE SIDEBAR ITEM
                ================================================= */

                .pascco-sidebar-link.is-active {

                    background: var(--pascco-blue) !important;

                    color: var(--pascco-gold) !important;
                }


                .pascco-sidebar-link.is-active i {

                    color: var(--pascco-gold) !important;
                }


                .pascco-sidebar-link.is-active:hover {

                    background: var(--pascco-blue) !important;

                    color: var(--pascco-gold) !important;

                    transform: none !important;
                }


                /* =================================================
                   PREVENT PAGE SCROLL WHEN SIDEBAR IS OPEN
                ================================================= */

                body.pascco-sidebar-open {

                    overflow: hidden !important;
                }


                /* =================================================
                   MOBILE
                ================================================= */

                @media (max-width: 600px) {

                    #pascco-sidebar {

                        width: min(
                            var(--pascco-sidebar-width),
                            86vw
                        ) !important;
                    }

                    .pascco-sidebar-toggle {

                        width: 42px !important;
                        height: 42px !important;

                        flex-basis: 42px !important;

                        margin-right: 6px !important;
                    }

                    .pascco-sidebar-toggle i {

                        font-size: 28px !important;
                    }
                }

            `;

            document.head.appendChild(style);
        }


        /* =========================================================
           6. GET USER NAME FROM PASCCO SHELL
        ========================================================= */

        let userName = "PASCCO Member";

        const nameElement = document.querySelector(
            ".pascco-account-name"
        );

        if (nameElement) {

            const cleanName =
                nameElement.textContent.trim();

            if (cleanName) {
                userName = cleanName;
            }
        }


        /* =========================================================
           7. CREATE OVERLAY
        ========================================================= */

        const overlay =
            document.createElement("div");

        overlay.id =
            "pascco-sidebar-overlay";

        overlay.setAttribute(
            "aria-hidden",
            "true"
        );


        /* =========================================================
           8. CREATE SIDEBAR
        ========================================================= */

        const sidebar =
            document.createElement("aside");

        sidebar.id =
            "pascco-sidebar";

        sidebar.className =
            "pascco-sidebar";

        sidebar.setAttribute(
            "aria-hidden",
            "true"
        );


        sidebar.innerHTML = `

            <div class="pascco-sidebar-header">

                <div class="pascco-sidebar-user">

                    <strong class="pascco-sidebar-user-name">
                    </strong>

                    <a
                        href="profile.php"
                        class="pascco-sidebar-profile"
                    >
                        <i
                            class="bx bx-user-circle"
                            aria-hidden="true"
                        ></i>

                        <span>My Profile</span>
                    </a>

                </div>


                <button
                    type="button"
                    class="pascco-sidebar-close"
                    id="close-pascco-sidebar"
                    aria-label="Close sidebar"
                >

                    <i
                        class="bx bx-x"
                        aria-hidden="true"
                    ></i>

                </button>

            </div>


            <nav
                class="pascco-sidebar-nav"
                aria-label="Member navigation"
            >

                <a
                    href="index.php"
                    class="pascco-sidebar-link"
                >
                    <i
                        class="bx bx-home-alt"
                        aria-hidden="true"
                    ></i>

                    <span>Home</span>
                </a>


                <a
                    href="dashboard.php"
                    class="pascco-sidebar-link"
                >
                    <i
                        class="bx bx-user-pin"
                        aria-hidden="true"
                    ></i>

                    <span>Member's Dashboard</span>
                </a>


                <a
                    href="member_savings.php"
                    class="pascco-sidebar-link"
                >
                    <i
                        class="bx bx-wallet"
                        aria-hidden="true"
                    ></i>

                    <span>My Savings</span>
                </a>


                <a
                    href="open_account.php"
                    class="pascco-sidebar-link"
                >
                    <i
                        class="bx bx-folder-plus"
                        aria-hidden="true"
                    ></i>

                    <span>Open Account</span>
                </a>


                <a
                    href="deposit.php"
                    class="pascco-sidebar-link"
                >
                    <i
                        class="bx bx-plus-circle"
                        aria-hidden="true"
                    ></i>

                    <span>Deposit Money</span>
                </a>


                <a
                    href="announcements.php"
                    class="pascco-sidebar-link"
                >
                    <i
                        class="bx bx-group"
                        aria-hidden="true"
                    ></i>

                    <span>Community</span>
                </a>


                <a
                    href="transfer.php"
                    class="pascco-sidebar-link"
                >
                    <i
                        class="bx bx-transfer-alt"
                        aria-hidden="true"
                    ></i>

                    <span>Transfer Funds</span>
                </a>


                <a
                    href="apply_loan.php"
                    class="pascco-sidebar-link"
                >
                    <i
                        class="bx bx-credit-card"
                        aria-hidden="true"
                    ></i>

                    <span>Apply for Loan</span>
                </a>

            </nav>
        `;


        /* =========================================================
           9. INSERT USER NAME
        ========================================================= */

        const sidebarUserName =
            sidebar.querySelector(
                ".pascco-sidebar-user-name"
            );

        if (sidebarUserName) {
            sidebarUserName.textContent = userName;
        }


        /* =========================================================
           10. ADD ELEMENTS TO PAGE
        ========================================================= */

        document.body.appendChild(overlay);
        document.body.appendChild(sidebar);


        /* =========================================================
           11. GET HAMBURGER FROM PASCCO SHELL
        ========================================================= */

        let hamburgerBtn =
            document.getElementById(
                "open-pascco-sidebar"
            );


        /*
         * The updated pascco_shell.php should already
         * contain this button.
         *
         * This fallback creates one if it is missing.
         */

        if (!hamburgerBtn) {

            const header =
                document.querySelector(
                    ".pascco-global-header"
                );

            if (header) {

                hamburgerBtn =
                    document.createElement("button");

                hamburgerBtn.type = "button";

                hamburgerBtn.id =
                    "open-pascco-sidebar";

                hamburgerBtn.className =
                    "pascco-sidebar-toggle";

                hamburgerBtn.setAttribute(
                    "aria-label",
                    "Open sidebar"
                );

                hamburgerBtn.setAttribute(
                    "aria-controls",
                    "pascco-sidebar"
                );

                hamburgerBtn.setAttribute(
                    "aria-expanded",
                    "false"
                );

                hamburgerBtn.innerHTML = `
                    <i
                        class="bx bx-menu"
                        aria-hidden="true"
                    ></i>
                `;

                /*
                 * Put hamburger at the beginning
                 * of the header so it stays on the
                 * same row as the PASCCO logo.
                 */

                header.insertBefore(
                    hamburgerBtn,
                    header.firstChild
                );
            }
        }


        /* =========================================================
           12. STOP IF HAMBURGER STILL DOES NOT EXIST
        ========================================================= */

        if (!hamburgerBtn) {

            console.warn(
                "PASCCO Sidebar: Hamburger button could not be created."
            );

            sidebar.remove();
            overlay.remove();

            return;
        }


        /* =========================================================
           13. ACCESSIBILITY ATTRIBUTES
        ========================================================= */

        hamburgerBtn.setAttribute(
            "aria-controls",
            "pascco-sidebar"
        );

        hamburgerBtn.setAttribute(
            "aria-expanded",
            "false"
        );


        /* =========================================================
           14. DETECT ACTIVE PAGE
        ========================================================= */

        const currentPath =
            window.location.pathname
                .split("/")
                .pop()
                .toLowerCase();


        const menuLinks =
            sidebar.querySelectorAll(
                ".pascco-sidebar-link"
            );


        menuLinks.forEach(function (link) {

            const href =
                link.getAttribute("href");

            if (!href) return;

            const linkPath =
                href
                    .split("/")
                    .pop()
                    .split("?")[0]
                    .toLowerCase();


            if (
                linkPath === currentPath ||
                (
                    currentPath === "" &&
                    linkPath === "index.php"
                )
            ) {

                link.classList.add(
                    "is-active"
                );

            } else {

                link.classList.remove(
                    "is-active"
                );
            }
        });


        /* =========================================================
           15. OPEN SIDEBAR
        ========================================================= */

        function openSidebar(event) {

            if (event) {
                event.preventDefault();
                event.stopPropagation();
            }


            sidebar.classList.add(
                "is-open"
            );

            overlay.classList.add(
                "is-open"
            );


            sidebar.setAttribute(
                "aria-hidden",
                "false"
            );

            overlay.setAttribute(
                "aria-hidden",
                "false"
            );


            hamburgerBtn.setAttribute(
                "aria-expanded",
                "true"
            );


            document.body.classList.add(
                "pascco-sidebar-open"
            );
        }


        /* =========================================================
           16. CLOSE SIDEBAR
        ========================================================= */

        function closeSidebar(event) {

            if (event) {
                event.preventDefault();
                event.stopPropagation();
            }


            sidebar.classList.remove(
                "is-open"
            );

            overlay.classList.remove(
                "is-open"
            );


            sidebar.setAttribute(
                "aria-hidden",
                "true"
            );

            overlay.setAttribute(
                "aria-hidden",
                "true"
            );


            hamburgerBtn.setAttribute(
                "aria-expanded",
                "false"
            );


            document.body.classList.remove(
                "pascco-sidebar-open"
            );
        }


        /* =========================================================
           17. HAMBURGER CLICK
        ========================================================= */

        hamburgerBtn.addEventListener(
            "click",
            openSidebar
        );


        /* =========================================================
           18. CLOSE BUTTON
        ========================================================= */

        const closeBtn =
            document.getElementById(
                "close-pascco-sidebar"
            );


        if (closeBtn) {

            closeBtn.addEventListener(
                "click",
                closeSidebar
            );
        }


        /* =========================================================
           19. CLICK OVERLAY TO CLOSE
        ========================================================= */

        overlay.addEventListener(
            "click",
            closeSidebar
        );


        /* =========================================================
           20. CLOSE WHEN CLICKING A MENU LINK
        ========================================================= */

        menuLinks.forEach(function (link) {

            link.addEventListener(
                "click",
                function () {
                    closeSidebar();
                }
            );

        });


        /* =========================================================
           21. ESCAPE KEY CLOSE
        ========================================================= */

        document.addEventListener(
            "keydown",
            function (event) {

                if (
                    event.key === "Escape" &&
                    sidebar.classList.contains("is-open")
                ) {

                    closeSidebar();
                }

            }
        );


        /* =========================================================
           22. DEBUG MESSAGE
        ========================================================= */

        console.log(
            "PASCCO Sidebar initialized successfully."
        );
    }


    /* =============================================================
       INITIALIZE AFTER DOM LOAD
    ============================================================= */

    if (document.readyState === "loading") {

        document.addEventListener(
            "DOMContentLoaded",
            initPASCCOSidebar
        );

    } else {

        initPASCCOSidebar();
    }

})();