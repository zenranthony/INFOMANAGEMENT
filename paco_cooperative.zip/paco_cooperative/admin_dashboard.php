<?php

require_once 'db.php';
require_once 'pascco_shell.php';

// Restrict access to Admin role only
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access Denied: Admin authorization required. <a href='login.php'>Login here</a>");
}

// 1. Fetch Total Cooperative Savings
$savings_stmt = $pdo->query("SELECT SUM(balance) AS total_savings FROM accounts");
$total_savings = $savings_stmt->fetch()['total_savings'] ?? 0;

// 2. Fetch Total Outstanding Loans
$loans_stmt = $pdo->query("SELECT SUM(remaining_balance) AS total_loans FROM loans WHERE status = 'approved'");
$total_loans = $loans_stmt->fetch()['total_loans'] ?? 0;

// 3. Fetch Total Active Members
$members_stmt = $pdo->query("SELECT COUNT(*) AS total_members FROM members");
$total_members = $members_stmt->fetch()['total_members'] ?? 0;

// 4. Fetch Count of Pending Loan Applications
$pending_stmt = $pdo->query("SELECT COUNT(*) AS pending_count FROM loans WHERE status = 'pending'");
$pending_count = $pending_stmt->fetch()['pending_count'] ?? 0;
$pending_deposits = 0;
try {
    $pending_deposits = (int) $pdo->query("SELECT COUNT(*) FROM deposit_requests WHERE status = 'pending'")->fetchColumn();
} catch (PDOException $exception) {
}

$pending_account_requests = 0;
try {
    $pending_account_requests = (int) $pdo->query("SELECT COUNT(*) FROM account_requests WHERE status = 'pending'")->fetchColumn();
} catch (PDOException $exception) {
}

// 5. Fetch loan status summary for operational monitoring.
$loan_status_stmt = $pdo->query("SELECT status, COUNT(*) AS total FROM loans GROUP BY status");
$loan_status = ['pending' => 0, 'approved' => 0, 'rejected' => 0, 'paid' => 0];
foreach ($loan_status_stmt->fetchAll() as $row) {
    $loan_status[$row['status']] = (int) $row['total'];
}

// 6. Fetch recent applications and newly registered members.
$recent_loans_stmt = $pdo->query("
    SELECT l.id AS loan_id, l.loan_number, l.loan_amount, l.status, l.application_date,
           m.first_name, m.last_name, m.member_number
    FROM loans l
    JOIN members m ON m.id = l.member_id
    ORDER BY l.id DESC LIMIT 6
");
$recent_loans = $recent_loans_stmt->fetchAll();

$recent_members_stmt = $pdo->query("
    SELECT member_number, first_name, last_name, email, created_at
    FROM members
    ORDER BY id DESC LIMIT 6
");
$recent_members = $recent_members_stmt->fetchAll();

$transaction_count = (int) $pdo->query("SELECT COUNT(*) FROM transactions")->fetchColumn();

// 7. Fetch Recent Audit Logs
$audit_stmt = $pdo->query("
    SELECT a.action, a.description, a.ip_address, a.created_at, u.username 
    FROM audit_logs a 
    LEFT JOIN users u ON a.user_id = u.id 
    ORDER BY a.id DESC LIMIT 10
");
$audit_logs = $audit_stmt->fetchAll();
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php pascco_global_styles(); ?>
<title>Admin Dashboard | PASCCO</title>

<style>
:root{--navy:#071d49;--blue:#1456a0;--blue2:#2b74c8;--gold:#e7b84b;--gold-light:#ffe7a1;--ink:#18324f;--muted:#6e7e93;--line:#dce5ef;--bg:#f4f7fb;--surface:#fff;--soft:#eef4fb;--success:#1c7442;--danger:#b52f38;--shadow:0 16px 40px rgba(7,29,73,.08)}
html,body{margin:0!important;padding:0!important;overflow-x:hidden}body{background:linear-gradient(180deg,#edf4fb 0,#f7f9fc 360px,var(--bg) 100%);color:var(--ink);font-family:Poppins,Arial,sans-serif}.admin-wrap{width:min(100% - 40px,1200px);margin:0 auto;padding:34px 0 58px}.page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:22px}.eyebrow{display:inline-flex;align-items:center;gap:8px;color:var(--blue);font-size:.74rem;font-weight:800;letter-spacing:.15em;text-transform:uppercase}.eyebrow:before{content:"";width:28px;height:3px;background:var(--gold);border-radius:999px}.page-head h1{margin:8px 0 0;color:var(--navy);font-size:clamp(2rem,4vw,3rem);line-height:1.05}.page-head p{margin:10px 0 0;color:var(--muted);line-height:1.6}.head-actions,.quick-actions{display:flex;gap:9px;flex-wrap:wrap}.button{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:11px 15px;border-radius:11px;background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;text-decoration:none;font-weight:800;font-size:.86rem;box-shadow:0 8px 18px rgba(20,86,160,.15)}.button.secondary{background:#fff;border:1px solid #cdd8e5;color:var(--navy);box-shadow:none}.button.gold{background:var(--gold);color:var(--navy)}.surface{background:var(--surface);border:1px solid rgba(7,29,73,.07);border-radius:20px;box-shadow:var(--shadow);overflow:hidden}.surface-head{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:21px 23px;border-bottom:1px solid var(--line)}.surface-head h2,.surface-head h3{margin:0;color:var(--navy);font-size:1.15rem}.surface-head p{margin:5px 0 0;color:var(--muted);font-size:.86rem}.surface-body{padding:22px}.stat-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin-bottom:20px}.stat{position:relative;padding:20px;border-radius:18px;background:#fff;border:1px solid rgba(7,29,73,.07);box-shadow:var(--shadow);overflow:hidden}.stat:after{content:"";position:absolute;right:-35px;top:-35px;width:120px;height:120px;border:1px solid rgba(20,86,160,.10);border-radius:50%;box-shadow:0 0 0 22px rgba(20,86,160,.025)}.stat .label{color:#78889b;font-size:.72rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase}.stat .value{margin-top:8px;color:var(--navy);font-size:1.65rem;font-weight:800;line-height:1.15}.stat.gold{border-top:4px solid var(--gold)}.stat.blue{border-top:4px solid var(--blue)}.grid-2{display:grid;grid-template-columns:1.35fr .65fr;gap:20px}.grid-2.equal{grid-template-columns:1fr 1fr}.stack{display:grid;gap:20px}.status-grid{display:grid;grid-template-columns:1fr 1fr;gap:11px}.status-tile{padding:14px;border-radius:13px;background:var(--soft);border:1px solid var(--line)}.status-tile span{display:block;color:var(--muted);font-size:.75rem}.status-tile strong{display:block;margin-top:4px;color:var(--navy);font-size:1.3rem}.status-tile.gold{background:#fff8df;border-color:#f0dda2}.status-tile.green{background:#eef9f2;border-color:#cde8d6}.status-tile.red{background:#fff1f1;border-color:#f0cccc}.table-wrap{overflow:auto}.admin-table{width:100%;min-width:640px;border-collapse:collapse}.admin-table th,.admin-table td{padding:13px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.82rem}.admin-table th{background:#f3f7fc;color:var(--navy);font-weight:800;position:sticky;top:0}.admin-table tr:hover td{background:#fbfdff}.sub{display:block;color:#8694a5;font-size:.72rem;margin-top:3px}.badge,.status-pill{display:inline-flex;align-items:center;gap:5px;padding:5px 9px;border-radius:999px;background:#e8f0fa;color:var(--navy);font-size:.7rem;font-weight:800;text-transform:uppercase}.badge.pending,.status-pill.pending{background:#fff0bf;color:#8a6500}.badge.approved,.status-pill.approved,.badge.paid{background:#e4f6ea;color:#17673b}.badge.rejected,.status-pill.rejected{background:#fde7e7;color:#a52f37}.badge.under_review,.status-pill.under_review{background:#efe8ff;color:#6945a6}.badge.scheduled,.status-pill.scheduled{background:#e9f3ff;color:#2966a8}.badge.certificate_uploaded,.status-pill.certificate_uploaded{background:#e5f8ed;color:#25714a}.notice{padding:13px 15px;border-radius:12px;margin-bottom:18px;font-weight:700;font-size:.86rem}.notice.success{background:#eaf8f0;border:1px solid #cfe9d9;color:var(--success)}.notice.error{background:#fff0f0;border:1px solid #f0cfd0;color:var(--danger)}.toolbar{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}.search-form{display:flex;gap:8px;width:min(100%,480px)}.field{margin-bottom:15px}.field label{display:block;margin-bottom:7px;color:var(--navy);font-size:.78rem;font-weight:800}.field input,.field select,.field textarea,.search-form input{width:100%;box-sizing:border-box;min-height:46px;padding:11px 13px;border:1px solid #cad6e3;border-radius:11px;background:#fff;color:var(--ink);font:inherit;outline:none}.field textarea{min-height:110px;resize:vertical}.field input:focus,.field select:focus,.field textarea:focus,.search-form input:focus{border-color:var(--blue2);box-shadow:0 0 0 4px rgba(20,86,160,.09)}.search-form input{flex:1}.search-form button,.action-btn{border:0;border-radius:11px;padding:11px 15px;background:var(--navy);color:#fff;font:inherit;font-weight:800;cursor:pointer}.filter-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.filter-row select{min-height:44px;border:1px solid #cad6e3;border-radius:11px;padding:9px 12px;background:#fff;font:inherit}.detail-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.detail-box{padding:13px;border:1px solid var(--line);border-radius:13px;background:#f8fbff}.detail-box small{display:block;color:#8291a2;font-size:.7rem}.detail-box strong{display:block;margin-top:4px;color:var(--navy);font-size:.84rem;line-height:1.45}.record-list{display:grid;gap:12px}.record{padding:17px;border:1px solid var(--line);border-radius:15px;background:#fbfdff}.record-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.record h3{margin:0;color:var(--navy);font-size:1rem}.record p{margin:5px 0;color:var(--muted);font-size:.82rem;line-height:1.5}.record-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:13px}.mini-link{color:var(--blue);font-weight:800;text-decoration:none;font-size:.82rem}.empty{padding:26px;text-align:center;color:var(--muted);background:#f8fbff;border:1px dashed #cdd9e5;border-radius:14px}.amount{color:var(--blue);font-weight:800;white-space:nowrap}.approval-card{padding:19px;border:1px solid var(--line);border-radius:17px;background:#fff}.approval-card+.approval-card{margin-top:12px}.approval-meta{color:var(--muted);font-size:.78rem}.approval-top{display:flex;justify-content:space-between;gap:15px;align-items:flex-start}.approval-top h3{margin:0;color:var(--navy);font-size:1rem}.approval-details{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:16px 0}.approval-details div{padding-top:9px;border-top:1px solid var(--line)}.approval-details small,.identity-grid small{display:block;color:#8291a2;font-size:.7rem}.approval-details strong,.identity-grid strong{display:block;margin-top:3px;color:var(--navy);font-size:.82rem;line-height:1.45}.identity-panel{padding:16px;border-radius:15px;background:#fffaf0;border:1px solid #ecdca8}.identity-panel h4{margin:0 0 12px;color:var(--navy)}.identity-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 14px}.document-links{display:flex;flex-wrap:wrap;gap:9px;margin-top:13px}.document-links a,.receipt-link{color:var(--blue);font-weight:800;text-decoration:none;font-size:.8rem}.review-form{display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;margin-top:13px}.review-form textarea{flex:1;min-width:220px;min-height:45px;padding:10px;border:1px solid #cad6e3;border-radius:10px;font:inherit}.btn-success,.btn-danger,.btn-primary{border:0;border-radius:10px;padding:10px 13px;font:inherit;font-weight:800;cursor:pointer}.btn-success{background:#267748;color:#fff}.btn-danger{background:#b8323b;color:#fff}.btn-primary{background:var(--blue);color:#fff}.announcement-grid{display:grid;grid-template-columns:.7fr 1.3fr;gap:20px}.announcement-card{padding:18px;border:1px solid var(--line);border-radius:16px;background:#fff}.announcement-card img{width:100%;max-height:190px;object-fit:cover;border-radius:12px;margin-bottom:12px}.announcement-card h3{margin:0;color:var(--navy);font-size:1rem}.announcement-card p{color:var(--muted);line-height:1.55;font-size:.82rem;white-space:pre-line}.announcement-card+.announcement-card{margin-top:12px}.profile-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.quick-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.quick-card{padding:16px;border-radius:15px;background:#f8fbff;border:1px solid var(--line)}.quick-card i{font-size:1.35rem;color:var(--blue)}.quick-card strong{display:block;margin-top:8px;color:var(--navy)}.quick-card span{display:block;margin-top:4px;color:var(--muted);font-size:.76rem;line-height:1.45}.mt{margin-top:20px}@media(max-width:1000px){.stat-grid{grid-template-columns:repeat(2,1fr)}.grid-2,.grid-2.equal,.announcement-grid{grid-template-columns:1fr}.detail-grid,.profile-grid,.approval-details,.identity-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.quick-grid{grid-template-columns:1fr 1fr}}@media(max-width:700px){.admin-wrap{width:min(100% - 28px,1200px);padding-top:24px}.page-head{align-items:flex-start;flex-direction:column}.head-actions,.quick-actions{width:100%}.button{flex:1}.stat-grid{grid-template-columns:1fr}.surface-head,.surface-body{padding:17px}.detail-grid,.profile-grid,.approval-details,.identity-grid,.quick-grid{grid-template-columns:1fr}.search-form{width:100%}.search-form button{white-space:nowrap}.approval-top,.record-head{flex-direction:column}.review-form{align-items:stretch;flex-direction:column}.review-form textarea{min-width:0}.review-form button{width:100%}}
</style>

</head>
<body>
<?php pascco_admin_header(); ?>

<main class="admin-wrap">
<section class="page-head"><div><div class="eyebrow">Administration</div><h1>Admin Dashboard</h1><p>Monitor cooperative activity, member services, approvals, and recent system activity from one place.</p></div><div class="head-actions"><a class="button secondary" href="admin_members.php"><i class="bx bx-group"></i> Members</a><a class="button secondary" href="admin_announcements.php"><i class="bx bx-megaphone"></i> Announcements</a></div></section>
<section class="stat-grid">
<div class="stat gold"><div class="label">Total Member Savings</div><div class="value">₱<?php echo number_format($total_savings,2); ?></div></div>
<div class="stat gold"><div class="label">Outstanding Loans</div><div class="value">₱<?php echo number_format($total_loans,2); ?></div></div>
<div class="stat blue"><div class="label">Registered Members</div><div class="value"><?php echo $total_members; ?></div></div>
<div class="stat blue"><div class="label">Transactions</div><div class="value"><?php echo number_format($transaction_count); ?></div></div>
<div class="stat"><div class="label">Pending Loan Requests</div><div class="value"><?php echo $pending_count; ?></div></div>
<div class="stat gold"><div class="label">Pending Deposit Reviews</div><div class="value"><?php echo $pending_deposits; ?></div></div>
<div class="stat gold"><div class="label">Pending Account Requests</div><div class="value"><?php echo $pending_account_requests; ?></div></div>
</section>
<div class="grid-2">
<section class="surface"><div class="surface-head"><div><h2>Recent Loan Applications</h2><p>Newest loan requests requiring administrative attention.</p></div><a class="mini-link" href="admin_loans.php">View all</a></div><div class="surface-body"><div class="table-wrap"><?php if($recent_loans): ?><table class="admin-table"><thead><tr><th>Loan</th><th>Member</th><th>Amount</th><th>Status</th></tr></thead><tbody><?php foreach($recent_loans as $loan): ?><tr><td><strong><?php echo htmlspecialchars($loan['loan_number']); ?></strong><span class="sub"><?php echo htmlspecialchars($loan['application_date']); ?></span><a class="mini-link" href="loan_application_print.php?loan_id=<?php echo (int)$loan['loan_id']; ?>" target="_blank" rel="noopener">View form</a></td><td><?php echo htmlspecialchars($loan['first_name'].' '.$loan['last_name']); ?><span class="sub"><?php echo htmlspecialchars($loan['member_number']); ?></span></td><td class="amount">₱<?php echo number_format($loan['loan_amount'],2); ?></td><td><span class="badge <?php echo htmlspecialchars($loan['status']); ?>"><?php echo strtoupper(htmlspecialchars($loan['status'])); ?></span></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="empty">No loan applications found.</div><?php endif; ?></div></div></section>
<section class="surface"><div class="surface-head"><div><h2>Loan Status</h2><p>Current portfolio workflow.</p></div></div><div class="surface-body"><div class="status-grid"><div class="status-tile gold"><span>Pending</span><strong><?php echo $loan_status['pending']; ?></strong></div><div class="status-tile green"><span>Approved</span><strong><?php echo $loan_status['approved']; ?></strong></div><div class="status-tile"><span>Paid</span><strong><?php echo $loan_status['paid']; ?></strong></div><div class="status-tile red"><span>Rejected</span><strong><?php echo $loan_status['rejected']; ?></strong></div></div><a class="button mt" href="admin_loans.php"><i class="bx bx-right-arrow-alt"></i> Open Loan Approvals</a></div></section>
</div>
<section class="surface mt"><div class="surface-head"><div><h2>Recently Registered Members</h2><p>Latest member registrations in the cooperative.</p></div><a class="mini-link" href="admin_members.php">Search members</a></div><div class="surface-body"><div class="table-wrap"><?php if($recent_members): ?><table class="admin-table"><thead><tr><th>Member</th><th>Email</th><th>Registered</th></tr></thead><tbody><?php foreach($recent_members as $member): ?><tr><td><strong><?php echo htmlspecialchars($member['first_name'].' '.$member['last_name']); ?></strong><span class="sub"><?php echo htmlspecialchars($member['member_number']); ?></span></td><td><?php echo htmlspecialchars($member['email']); ?></td><td><?php echo htmlspecialchars($member['created_at']); ?></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="empty">No members found.</div><?php endif; ?></div></div></section>
<section class="surface mt"><div class="surface-head"><div><h2>System Audit Activity</h2><p>Recent administrative and member-system events.</p></div></div><div class="surface-body"><div class="table-wrap"><?php if($audit_logs): ?><table class="admin-table"><thead><tr><th>User</th><th>Action</th><th>Description</th><th>IP Address</th><th>Timestamp</th></tr></thead><tbody><?php foreach($audit_logs as $log): ?><tr><td><strong><?php echo htmlspecialchars($log['username']??'System'); ?></strong></td><td><code><?php echo htmlspecialchars($log['action']); ?></code></td><td><?php echo htmlspecialchars($log['description']); ?></td><td><small><?php echo htmlspecialchars($log['ip_address']); ?></small></td><td><small><?php echo htmlspecialchars($log['created_at']); ?></small></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="empty">No audit log records found.</div><?php endif; ?></div></div></section>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
