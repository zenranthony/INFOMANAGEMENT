<?php

/* =========================================================
   PASCCO MEMBER HEADER
========================================================= */

function pascco_member_header(string $title = 'PASCCO'): void
{
    ?>
    <header class="pascco-global-header pascco-member-header">

        <!-- Member Sidebar Toggle -->
        <button
            type="button"
            id="open-pascco-sidebar"
            class="pascco-sidebar-toggle"
            aria-label="Open member sidebar"
            aria-controls="pascco-sidebar"
            aria-expanded="false"
        >
            <i class="bx bx-menu" aria-hidden="true"></i>
        </button>

        <!-- PASCCO BRAND -->
        <a
            class="pascco-global-brand"
            href="dashboard.php"
        >
            <img
                src="LOGO.png"
                alt="PASCCO logo"
            >

            <strong>PASCCO</strong>
        </a>

        <!-- MEMBER ACCOUNT -->
        <div class="pascco-global-account">

            <span class="pascco-account-name">
                <?php
                echo htmlspecialchars(
                    $_SESSION['username'] ?? 'Member',
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>
            </span>

            <a
                href="logout.php"
                class="Btn"
                aria-label="Logout"
            >
                <div class="sign">

                    <svg
                        viewBox="0 0 512 512"
                        aria-hidden="true"
                    >
                        <path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z"></path>
                    </svg>

                </div>

                <span class="text">Logout</span>
            </a>

        </div>

    </header>
    <?php
}

/* =========================================================
   PASCCO ADMIN HEADER
========================================================= */

function pascco_admin_header(): void
{
    $current_page = basename($_SERVER['PHP_SELF']);

    $admin_links = [

        [
            'admin_dashboard.php',
            'Dashboard',
            'bx-grid-alt'
        ],

        [
            'admin_members.php',
            'Members',
            'bx-group'
        ],

        [
            'admin_membership.php',
            'Membership',
            'bx-id-card'
        ],

        [
            'admin_account_requests.php',
            'Account Requests',
            'bx-folder-open'
        ],

        [
            'admin_loans.php',
            'Loan Approvals',
            'bx-credit-card'
        ],

        [
            'admin_deposits.php',
            'Deposit Reviews',
            'bx-money'
        ],

        [
            'admin_announcements.php',
            'Announcements',
            'bx-bell'
        ],

    ];

    ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            document.body.classList.add('pascco-admin-page');
        });
    </script>

    <header class="pascco-global-header pascco-admin-header">

        <!-- ADMIN SIDEBAR TOGGLE -->
        <button
            type="button"
            id="open-pascco-admin-sidebar"
            class="pascco-admin-sidebar-toggle"
            aria-label="Open admin sidebar"
            aria-controls="pascco-admin-sidebar"
            aria-expanded="false"
        >
            <i
                class="bx bx-menu"
                aria-hidden="true"
            ></i>
        </button>

        <!-- ADMIN BRAND -->
        <a
            class="pascco-global-brand"
            href="admin_dashboard.php"
        >

            <img
                src="LOGO.png"
                alt="PASCCO logo"
            >

            <strong>PASCCO ADMIN</strong>

        </a>

        <!-- ADMIN ACCOUNT -->
        <div class="pascco-global-account">

            <span class="pascco-admin-account-name">
                Administrator
            </span>

            <a
                href="logout.php"
                class="Btn"
                aria-label="Logout"
            >

                <div class="sign">

                    <svg
                        viewBox="0 0 512 512"
                        aria-hidden="true"
                    >
                        <path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z"></path>
                    </svg>

                </div>

                <span class="text">
                    Logout
                </span>

            </a>

        </div>

    </header>

    <!-- =====================================================
         ADMIN SIDEBAR
    ====================================================== -->

    <div
        id="pascco-admin-sidebar-overlay"
        class="pascco-admin-sidebar-overlay"
        aria-hidden="true"
    ></div>

    <aside
        id="pascco-admin-sidebar"
        class="pascco-admin-sidebar"
        aria-hidden="true"
    >

        <!-- SIDEBAR HEADER -->
        <div class="pascco-admin-sidebar-header">

            <div class="pascco-admin-sidebar-user">

                <strong>
                    PASCCO ADMIN
                </strong>

                <span>
                    Administrator Panel
                </span>

            </div>

            <button
                type="button"
                id="close-pascco-admin-sidebar"
                class="pascco-admin-sidebar-close"
                aria-label="Close admin sidebar"
            >

                <i
                    class="bx bx-x"
                    aria-hidden="true"
                ></i>

            </button>

        </div>

        <!-- SIDEBAR NAVIGATION -->
        <nav
            class="pascco-admin-sidebar-nav"
            aria-label="Admin sidebar navigation"
        >

            <?php foreach ($admin_links as [$url, $label, $icon]): ?>

                <a
                    href="<?php echo htmlspecialchars($url, ENT_QUOTES, 'UTF-8'); ?>"
                    class="pascco-admin-sidebar-link <?php echo $current_page === $url ? 'is-active' : ''; ?>"
                    <?php
                    echo $current_page === $url
                        ? 'aria-current="page"'
                        : '';
                    ?>
                >

                    <i
                        class="bx <?php echo htmlspecialchars($icon, ENT_QUOTES, 'UTF-8'); ?>"
                        aria-hidden="true"
                    ></i>

                    <span>
                        <?php
                        echo htmlspecialchars(
                            $label,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </span>

                </a>

            <?php endforeach; ?>

            <!-- PUBLIC SITE -->
            <div class="pascco-admin-sidebar-divider"></div>

            <a
                href="home.php"
                class="pascco-admin-sidebar-link"
            >

                <i
                    class="bx bx-globe"
                    aria-hidden="true"
                ></i>

                <span>
                    Public Site
                </span>

            </a>

            <!-- LOGOUT -->
            <a
                href="logout.php"
                class="pascco-admin-sidebar-link pascco-admin-sidebar-logout"
            >

                <i
                    class="bx bx-log-out"
                    aria-hidden="true"
                ></i>

                <span>
                    Logout
                </span>

            </a>

        </nav>

    </aside>

    <?php
}

/* =========================================================
   PASCCO PUBLIC HEADER
========================================================= */

function pascco_public_header(
    string $action_label,
    string $action_url
): void {

    $current_page = basename($_SERVER['PHP_SELF']);

    $public_links = [

        ['home.php', 'Home'],

        ['savings.php', 'Savings'],

        ['credit.php', 'Credit'],

        ['requirements.php', 'Requirements'],

        ['about.php', 'About'],

    ];

    ?>

    <header class="pascco-global-header pascco-public-header">

        <!-- PUBLIC BRAND -->
        <a
            class="pascco-global-brand"
            href="home.php"
        >

            <img
                src="LOGO.png"
                alt="PASCCO logo"
            >

            <strong>PASCCO</strong>

        </a>

        <!-- PUBLIC NAVIGATION -->
        <nav
            class="pascco-global-nav pascco-public-nav"
            aria-label="Public navigation"
        >

            <?php foreach ($public_links as [$url, $label]): ?>

                <a
                    class="<?php echo $current_page === $url ? 'is-active' : ''; ?>"
                    href="<?php echo htmlspecialchars($url, ENT_QUOTES, 'UTF-8'); ?>"
                    <?php
                    echo $current_page === $url
                        ? 'aria-current="page"'
                        : '';
                    ?>
                >

                    <?php
                    echo htmlspecialchars(
                        $label,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                    ?>

                </a>

            <?php endforeach; ?>

        </nav>

        <!-- PUBLIC MOBILE TOGGLE -->
        <button
            type="button"
            class="pascco-public-menu-toggle"
            aria-label="Open navigation"
            aria-expanded="false"
        >

            <i
                class="bx bx-menu"
                aria-hidden="true"
            ></i>

        </button>

        <!-- HEADER ACTION -->
        <div class="pascco-global-account">

            <a
                class="pascco-header-action"
                href="<?php echo htmlspecialchars($action_url, ENT_QUOTES, 'UTF-8'); ?>"
            >

                <?php
                echo htmlspecialchars(
                    $action_label,
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>

            </a>

        </div>

    </header>

    <?php
}

/* =========================================================
   GLOBAL STYLES
========================================================= */

function pascco_global_styles(): void
{
    ?>

    <!-- BOXICONS -->
    <link
        id="boxicons-cdn"
        href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
        rel="stylesheet"
    >

    <!-- POPPINS -->
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet"
    >

    <style>

        /* =====================================================
           ROOT
        ====================================================== */

        :root {

            --pascco-blue: #071d49;

            --pascco-blue-light: #1456a0;

            --pascco-gold: #e7b84b;

            --pascco-gold-light: #ffe7a1;

            --pascco-white: #ffffff;

            --pascco-text: #182a45;

            --pascco-line: rgba(255,255,255,.18);

            --pascco-sidebar-width: 290px;

        }

        /* =====================================================
           GLOBAL
        ====================================================== */

        html,
        body {

            overflow-x: hidden;

        }

        body.pascco-sidebar-open,
        body.pascco-admin-sidebar-open {

            overflow: hidden;

        }

        /* =====================================================
           GLOBAL HEADER
        ====================================================== */

        .pascco-global-header {
            position: relative;
            z-index: 9000;
            display: grid;
            grid-template-columns: auto minmax(0, 1fr) auto;
            align-items: center;
            min-height: 72px;
            padding: 10px clamp(16px, 4vw, 54px);
            gap: 18px;
            background: linear-gradient(135deg, #071d49 0%, #0b2f6f 48%, #1456a0 100%);
            color: #ffffff;
            box-sizing: border-box;
            border-bottom: 1px solid rgba(255,255,255,.12);
            box-shadow: 0 8px 24px rgba(7,29,73,.12);
        }

        /* =====================================================
           BRAND
        ====================================================== */

        .pascco-global-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            min-width: 0;
            color: #ffffff;
            text-decoration: none;
        }

        .pascco-global-brand img {
            width: 44px;
            height: 44px;
            object-fit: contain;
            flex: 0 0 42px;
        }

        .pascco-global-brand strong {
            font-family: Impact, 'Arial Black', sans-serif;
            font-size: 1.18rem;
            letter-spacing: .06em;
            white-space: nowrap;
        }

        .pascco-global-brand:hover strong {
            color: var(--pascco-gold-light);
        }

        /* =====================================================
           MEMBER SIDEBAR BUTTON
        ====================================================== */

        .pascco-sidebar-toggle {

            display: inline-flex;

            align-items: center;

            justify-content: center;

            width: 42px;

            height: 42px;

            padding: 0;

            border: none;

            border-radius: 8px;

            background: transparent;

            color: #ffffff;

            font-size: 30px;

            cursor: pointer;

            flex: 0 0 44px;

        }

        .pascco-sidebar-toggle:hover {

            color: var(--pascco-gold);

            background:
                rgba(255,255,255,.08);

        }

        .pascco-sidebar-toggle:focus-visible {

            outline:
                2px solid var(--pascco-gold);

            outline-offset: 2px;

        }

        /* =====================================================
           ADMIN SIDEBAR BUTTON
        ====================================================== */

        .pascco-admin-sidebar-toggle {

            display: inline-flex;

            align-items: center;

            justify-content: center;

            width: 44px;

            height: 44px;

            padding: 0;

            border: none;

            border-radius: 8px;

            background: transparent;

            color: #ffffff;

            font-size: 30px;

            cursor: pointer;

            flex: 0 0 44px;

            transition:
                background .2s ease,
                color .2s ease;

        }

        .pascco-admin-sidebar-toggle:hover {

            color: var(--pascco-gold);

            background:
                rgba(255,255,255,.08);

        }

        .pascco-admin-sidebar-toggle:focus-visible {

            outline:
                2px solid var(--pascco-gold);

            outline-offset: 2px;

        }

        /* =====================================================
           PUBLIC HEADER LAYOUT
        ====================================================== */

        .pascco-public-header {
            position: relative;
            z-index: 1000;
            display: flex;
            flex-wrap: nowrap;
            align-items: center;
            gap: 12px;
            min-height: 68px;
            padding: 8px clamp(14px, 3vw, 42px);
            background: linear-gradient(135deg, #071d49, #1456a0);
            color: #fff;
            box-shadow: 0 8px 24px rgba(7, 29, 73, .12);
            white-space: nowrap;
            border-bottom: 0;
        }

        .pascco-public-header .pascco-global-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            flex: 0 0 auto;
            min-width: 0;
            color: #fff;
            text-decoration: none;
        }

        .pascco-public-header .pascco-global-brand img {
            width: 42px;
            height: 42px;
            object-fit: contain;
            flex: 0 0 42px;
        }

        .pascco-public-header .pascco-global-brand strong {
            color: #fff;
            font-family: 'Poppins', Arial, Helvetica, sans-serif;
            font-size: 1.08rem;
            font-weight: 800;
            letter-spacing: .07em;
            white-space: nowrap;
        }

        .pascco-public-header .pascco-public-nav {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 2px;
            flex: 1 1 auto;
            min-width: 0;
            margin: 0 auto;
            overflow: hidden;
        }

        .pascco-public-header .pascco-public-nav a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex: 0 0 auto;
            min-height: 0;
            padding: 7px 9px;
            border: 1px solid transparent;
            border-radius: 8px;
            color: rgba(255, 255, 255, .94);
            font-family: 'Poppins', Arial, Helvetica, sans-serif;
            font-size: .79rem;
            font-weight: 600;
            text-decoration: none;
            white-space: nowrap;
            transition: color .18s ease, border-color .18s ease, background .18s ease;
        }

        .pascco-public-header .pascco-public-nav a:hover,
        .pascco-public-header .pascco-public-nav a.is-active {
            background: rgba(255, 255, 255, .08);
            border-color: rgba(231, 184, 75, .42);
            color: #ffe7a1;
            transform: none;
        }

        .pascco-public-header .pascco-global-account {
            flex: 0 0 auto;
        }

        .pascco-public-header .pascco-header-action {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex: 0 0 auto;
            min-height: 38px;
            padding: 7px 12px;
            border: 1px solid #e7b84b;
            border-radius: 9px;
            background: rgba(255, 255, 255, .05);
            color: #ffe7a1;
            font-family: 'Poppins', Arial, Helvetica, sans-serif;
            font-size: .78rem;
            font-weight: 700;
            text-decoration: none;
            transition: background .18s ease, color .18s ease, transform .18s ease;
        }

        .pascco-public-header .pascco-header-action:hover {
            background: #e7b84b;
            color: #071d49;
            transform: translateY(-1px);
        }

        /* =====================================================
           GLOBAL NAVIGATION
        ====================================================== */

        .pascco-global-nav {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
            gap: 6px;
            min-width: 0;
            margin: 0 auto;
        }

        .pascco-global-nav a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 38px;
            padding: 8px 13px;
            border: 1px solid transparent;
            border-radius: 10px;
            color: rgba(255,255,255,.9);
            font-family: Poppins, sans-serif;
            font-size: .84rem;
            font-weight: 600;
            text-decoration: none;
            white-space: nowrap;
            transition: background .2s ease, color .2s ease, border-color .2s ease, transform .2s ease;
        }

        .pascco-global-nav a:hover {
            background: rgba(255,255,255,.08);
            border-color: rgba(255,255,255,.12);
            color: #ffffff;
            transform: translateY(-1px);
        }

        .pascco-global-nav a.is-active {
            background: rgba(231,184,75,.16);
            border-color: rgba(231,184,75,.45);
            color: var(--pascco-gold-light);
        }

        /* =====================================================
           ACCOUNT
        ====================================================== */

        .pascco-global-account {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 10px;
            min-width: 0;
            white-space: nowrap;
        }

        .pascco-account-name,
        .pascco-admin-account-name {

            max-width: 150px;

            overflow: hidden;

            text-overflow: ellipsis;

            color: #ffffff;

            font-family:
                Georgia,
                'Times New Roman',
                serif;

            font-weight: 500;

        }

        .pascco-account-name,
        .pascco-admin-account-name {
            padding: 7px 10px;
            border: 1px solid rgba(255,255,255,.12);
            border-radius: 999px;
            background: rgba(255,255,255,.06);
            font-size: .78rem;
        }

        .pascco-header-action {
            box-shadow: 0 6px 16px rgba(0,0,0,.12);
        }

        /* =====================================================
           HEADER ACTION
        ====================================================== */

        .pascco-header-action,
        .pascco-header-action:visited {

            display: inline-block;

            padding:
                9px 14px;

            border:
                1px solid var(--pascco-gold);

            border-radius: 5px;

            color:
                var(--pascco-gold-light);

            text-decoration: none;

            white-space: nowrap;

            font-family:
                Georgia,
                'Times New Roman',
                serif;

        }

        .pascco-header-action:hover {

            background:
                var(--pascco-gold);

            color:
                var(--pascco-blue);

        }

        /* =====================================================
           LOGOUT BUTTON
        ====================================================== */

        .pascco-global-account .Btn {

            display: flex !important;

            align-items: center !important;

            justify-content: flex-start !important;

            width: 42px !important;

            height: 42px !important;

            padding: 0 !important;

            border: none !important;

            border-radius: 50% !important;

            background:
                var(--pascco-gold) !important;

            position: relative !important;

            overflow: hidden !important;

            cursor: pointer !important;

            text-decoration: none !important;

            flex-shrink: 0 !important;

            transition:
                width .3s ease,
                border-radius .3s ease !important;

        }

        .pascco-global-account .Btn .sign {

            width: 100% !important;

            display: flex !important;

            align-items: center !important;

            justify-content: center !important;

            transition:
                width .3s ease !important;

        }

        .pascco-global-account .Btn .sign svg {

            width: 18px !important;

            height: 18px !important;

        }

        .pascco-global-account .Btn .sign svg path {

            fill:
                var(--pascco-blue) !important;

        }

        .pascco-global-account .Btn .text {

            position: absolute !important;

            right: 0 !important;

            width: 0 !important;

            opacity: 0 !important;

            color:
                var(--pascco-blue) !important;

            font-family:
                Georgia,
                'Times New Roman',
                serif !important;

            font-weight: 600 !important;

            white-space: nowrap !important;

            transition:
                opacity .3s ease,
                width .3s ease !important;

        }

        .pascco-global-account .Btn:hover {

            width: 120px !important;

            border-radius: 40px !important;

        }

        .pascco-global-account .Btn:hover .sign {

            width: 30% !important;

        }

        .pascco-global-account .Btn:hover .text {

            width: 70% !important;

            opacity: 1 !important;

        }

        /* =====================================================
           PUBLIC MOBILE MENU
        ====================================================== */

        .pascco-public-menu-toggle {
            display: none !important;

            align-items: center;

            justify-content: center;

            width: 42px;

            height: 42px;

            padding: 0;

            border:
                1px solid rgba(255,255,255,.35);

            border-radius: 8px;

            background: transparent;

            color: #ffffff;

            font-size: 28px;

            cursor: pointer;

        }

        /* =====================================================
           ADMIN SIDEBAR
        ====================================================== */

        .pascco-admin-sidebar {

            position: fixed;

            top: 0;

            left: 0;

            width:
                var(--pascco-sidebar-width);

            height: 100vh;

            padding: 20px 15px;

            box-sizing: border-box;

            background: #ffffff;

            box-shadow:
                5px 0 25px rgba(0,0,0,.25);

            z-index: 100001;

            font-family:
                Poppins,
                sans-serif;

            overflow-y: auto;

            transform:
                translateX(-100%);

            transition:
                transform .35s
                cubic-bezier(.25,1,.5,1);

        }

        .pascco-admin-sidebar.is-open {

            transform:
                translateX(0);

        }

        /* =====================================================
           ADMIN SIDEBAR OVERLAY
        ====================================================== */

        .pascco-admin-sidebar-overlay {

            position: fixed;

            inset: 0;

            width: 100vw;

            height: 100vh;

            background:
                rgba(0,0,0,.5);

            z-index: 100000;

            opacity: 0;

            visibility: hidden;

            pointer-events: none;

            transition:
                opacity .3s ease,
                visibility .3s ease;

        }

        .pascco-admin-sidebar-overlay.is-open {

            opacity: 1;

            visibility: visible;

            pointer-events: auto;

        }

        /* =====================================================
           ADMIN SIDEBAR HEADER
        ====================================================== */

        .pascco-admin-sidebar-header {

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 10px;

            padding:
                5px 5px 16px;

            margin-bottom: 16px;

            border-bottom:
                2px solid #eeeeee;

        }

        .pascco-admin-sidebar-user {

            display: flex;

            flex-direction: column;

            min-width: 0;

        }

        .pascco-admin-sidebar-user strong {

            color:
                var(--pascco-blue);

            font-size: 17px;

            font-weight: 700;

        }

        .pascco-admin-sidebar-user span {

            margin-top: 3px;

            color: #777777;

            font-size: 12px;

        }

        /* =====================================================
           ADMIN CLOSE BUTTON
        ====================================================== */

        .pascco-admin-sidebar-close {

            display: inline-flex;

            align-items: center;

            justify-content: center;

            width: 38px;

            height: 38px;

            padding: 0;

            border: none;

            border-radius: 8px;

            background: transparent;

            color: #444444;

            font-size: 28px;

            cursor: pointer;

            flex-shrink: 0;

        }

        .pascco-admin-sidebar-close:hover {

            background: #f1f3f6;

            color:
                var(--pascco-blue);

        }

        /* =====================================================
           ADMIN SIDEBAR NAV
        ====================================================== */

        .pascco-admin-sidebar-nav {

            display: flex;

            flex-direction: column;

            gap: 6px;

        }

        .pascco-admin-sidebar-link {

            display: flex;

            align-items: center;

            width: 100%;

            min-height: 46px;

            padding:
                10px 14px;

            box-sizing: border-box;

            border-radius: 9px;

            color: #333333;

            text-decoration: none;

            font-size: 14px;

            font-weight: 500;

            transition:
                background .2s ease,
                color .2s ease,
                transform .2s ease;

        }

        .pascco-admin-sidebar-link i {

            width: 25px;

            margin-right: 12px;

            color: #555555;

            font-size: 21px;

            flex-shrink: 0;

        }

        .pascco-admin-sidebar-link:hover {

            background: #f1f4f8;

            color:
                var(--pascco-blue);

            transform:
                translateX(2px);

        }

        .pascco-admin-sidebar-link:hover i {

            color:
                var(--pascco-blue);

        }

        .pascco-admin-sidebar-link.is-active {

            background:
                var(--pascco-blue);

            color:
                var(--pascco-gold-light);

        }

        .pascco-admin-sidebar-link.is-active i {

            color:
                var(--pascco-gold);

        }

        .pascco-admin-sidebar-divider {

            height: 1px;

            margin:
                12px 4px;

            background:
                #eeeeee;

        }

        .pascco-admin-sidebar-logout:hover {

            background: #fff0f0;

            color: #b42318;

        }

        .pascco-admin-sidebar-logout:hover i {

            color: #b42318;

        }

        /* =====================================================
           FORM CONTROLS
        ====================================================== */

        button,
        input[type="submit"],
        input[type="button"],
        .btn-action,
        a.btn,
        .account-card a {

            font-family:
                Georgia,
                'Times New Roman',
                serif !important;

            transition:
                all .2s ease !important;

        }

        input:not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]),
        select,
        textarea {

            width: 100%;

            padding:
                12px 20px;

            background: #ffffff;

            border:
                1px solid #b8c8bd;

            border-radius: 50px;

            color:
                var(--pascco-text);

            font-size: 14px;

            font-family:
                Georgia,
                'Times New Roman',
                serif;

            outline: none;

            box-sizing: border-box;

            transition:
                all .3s ease;

        }

        select {

            appearance: none;

            background-image:
                url("data:image/svg+xml;utf8,<svg fill='%23182a45' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/></svg>");

            background-repeat: no-repeat;

            background-position:
                right 16px center;

            padding-right: 45px;

        }

        input:focus,
        select:focus,
        textarea:focus {

            border-color:
                var(--pascco-blue-light);

            box-shadow:
                0 0 5px
                rgba(20,86,160,.3);

        }

        /* =====================================================
           ADMIN PAGE HEIGHT / FOOTER POSITION
        ====================================================== */

        body.pascco-admin-page {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        body.pascco-admin-page .pascco-global-footer {
            margin-top: auto;
        }

        /* =====================================================
           GLOBAL FOOTER
        ====================================================== */

        .pascco-global-footer {
            margin-top: 18px;
            padding: 18px 22px 10px;
            background: linear-gradient(135deg, #071d49, #1456a0);
            color: #edf3ff;
            border-top: 2px solid var(--pascco-gold);
            box-sizing: border-box;
        }

        .pascco-global-footer .footer-main {
            max-width: 1180px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1.25fr 1fr 1.25fr;
            gap: 20px;
            align-items: center;
        }

        .pascco-global-footer .footer-brand,
        .pascco-global-footer .footer-links,
        .pascco-global-footer .footer-contact {
            min-width: 0;
        }

        .pascco-global-footer .footer-brand {
            display: flex;
            flex-direction: column;
            gap: 3px;
        }

        .pascco-global-footer .footer-heading {
            color: var(--pascco-gold-light);
            font-size: .68rem;
            font-weight: 800;
            letter-spacing: .12em;
            text-transform: uppercase;
        }

        .pascco-global-footer .footer-brand > strong {
            color: #fff;
            font-size: .88rem;
            line-height: 1.3;
        }

        .pascco-global-footer .footer-tagline {
            color: #dbe7fa;
            font-size: .74rem;
        }

        .pascco-global-footer .footer-links {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 5px 13px;
        }

        .pascco-global-footer .footer-link {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            color: #edf3ff;
            text-decoration: none;
            font-size: .74rem;
            line-height: 1.4;
            transition: color .18s ease, transform .18s ease;
        }

        .pascco-global-footer .footer-link:hover {
            color: var(--pascco-gold-light);
            transform: translateY(-1px);
            text-decoration: none;
        }

        .pascco-global-footer .footer-contact {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px 13px;
        }

        .pascco-global-footer .footer-logo {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            max-width: 100%;
        }

        .pascco-global-footer .footer-logo img {
            width: 28px;
            height: 28px;
            object-fit: contain;
            flex: 0 0 auto;
        }

        .pascco-global-footer .footer-logo strong {
            color: #fff;
            font-size: .7rem;
            line-height: 1.35;
        }

        .pascco-global-footer .footer-contact .footer-link {
            white-space: nowrap;
        }

        .pascco-global-copyright {
            max-width: 1180px;
            margin: 10px auto 0;
            padding-top: 8px;
            border-top: 1px solid rgba(255,255,255,.14);
            color: #cbd8eb;
            font-size: .68rem;
            text-align: center;
        }

        @media (max-width: 900px) {
            .pascco-global-footer .footer-main {
                grid-template-columns: 1fr 1fr;
            }

            .pascco-global-footer .footer-brand {
                grid-column: 1 / -1;
                text-align: center;
                align-items: center;
            }

            .pascco-global-footer .footer-contact {
                justify-content: center;
            }
        }

        @media (max-width: 600px) {
            .pascco-global-footer {
                padding: 16px 14px 10px;
            }

            .pascco-global-footer .footer-main {
                grid-template-columns: 1fr;
                gap: 10px;
            }

            .pascco-global-footer .footer-links,
            .pascco-global-footer .footer-contact {
                justify-content: center;
            }
        }

    </style>

    <!-- =====================================================
         PUBLIC MOBILE NAV SCRIPT
    ====================================================== -->

    <script>

        document.addEventListener(
            'DOMContentLoaded',
            function () {

                const toggle =
                    document.querySelector(
                        '.pascco-public-menu-toggle'
                    );

                const nav =
                    document.querySelector(
                        '.pascco-public-nav'
                    );

                if (!toggle || !nav) {
                    return;
                }

                toggle.addEventListener(
                    'click',
                    function () {

                        const isOpen =
                            nav.classList.toggle(
                                'is-open'
                            );

                        toggle.setAttribute(
                            'aria-expanded',
                            String(isOpen)
                        );

                    }
                );

                nav.querySelectorAll('a').forEach(
                    function (link) {

                        link.addEventListener(
                            'click',
                            function () {

                                nav.classList.remove(
                                    'is-open'
                                );

                                toggle.setAttribute(
                                    'aria-expanded',
                                    'false'
                                );

                            }
                        );

                    }
                );

            }
        );

    </script>

    <style>

        @media (max-width: 980px) {
            .pascco-global-header {
                grid-template-columns: auto 1fr auto;
                gap: 12px;
                padding-left: 16px;
                padding-right: 16px;
            }

            .pascco-global-nav a {
                padding-left: 10px;
                padding-right: 10px;
                font-size: .78rem;
            }
        }

        @media (max-width: 850px) {
            .pascco-global-header {
                min-height: 68px;
            }

            .pascco-public-menu-toggle {
                display: inline-flex !important;
                flex: 0 0 42px;
                order: 3;
            }

            .pascco-public-header .pascco-global-account {
                order: 4;
            }

            .pascco-public-nav.is-open {

                display: flex;

                flex-direction: column;

                width: 100%;

                flex-basis: 100%;

                order: 10;

                margin: 5px 0 0;

                padding: 5px 0;

            }

            .pascco-public-nav.is-open a {

                width: 100%;

                box-sizing: border-box;

                text-align: center;

                border:
                    1px solid rgba(255,255,255,.18);

                border-bottom:
                    1px solid rgba(255,255,255,.18);

            }

        }

    </style>

    <?php
}

/* =========================================================
   GLOBAL FOOTER
========================================================= */

function pascco_global_footer(): void
{
    ?>

    <footer class="pascco-global-footer">
        <div class="footer-main">
            <div class="footer-brand">
                <span class="footer-heading">PASCCO</span>
                <strong>Paco Savings &amp; Credit Cooperative</strong>
                <span class="footer-tagline">Helping People Help Themselves.</span>
            </div>

            <nav class="footer-links" aria-label="Footer navigation">
                <a class="footer-link" href="home.php"><i class="bx bx-home-alt" aria-hidden="true"></i><span>Home</span></a>
                <a class="footer-link" href="about.php"><i class="bx bx-buildings" aria-hidden="true"></i><span>About</span></a>
                <a class="footer-link" href="savings.php"><i class="bx bx-wallet" aria-hidden="true"></i><span>Savings</span></a>
                <a class="footer-link" href="credit.php"><i class="bx bx-credit-card" aria-hidden="true"></i><span>Credit</span></a>
                <a class="footer-link" href="requirements.php"><i class="bx bx-check-shield" aria-hidden="true"></i><span>Requirements</span></a>
                <a class="footer-link" href="support.php"><i class="bx bx-help-circle" aria-hidden="true"></i><span>Help</span></a>
                <a class="footer-link" href="privacy.php"><i class="bx bx-shield" aria-hidden="true"></i><span>Privacy</span></a>
            </nav>

            <div class="footer-contact">
                <div class="footer-logo">
                    <img src="LOGO.png" alt="PASCCO logo">
                    <strong>1461 Merced corner Perdigon Sts., Paco, Manila</strong>
                </div>

                <a class="footer-link" href="mailto:pascco30@gmail.com"><i class="bx bx-envelope" aria-hidden="true"></i><span>pascco30@gmail.com</span></a>
                <a class="footer-link" href="tel:+639083688038"><i class="bx bx-mobile" aria-hidden="true"></i><span>0908-3688038</span></a>
                <a class="footer-link" href="https://www.facebook.com/pacopascco" target="_blank" rel="noopener noreferrer"><i class="bx bxl-facebook-square" aria-hidden="true"></i><span>Facebook</span></a>
            </div>
        </div>

        <div class="pascco-global-copyright">
            &copy; <?php echo date('Y'); ?> PASCCO &middot; Paco Savings &amp; Credit Cooperative. All rights reserved.
        </div>
    </footer>

    <?php

    /*
     * Detect current page.
     *
     * sidebar.js is ONLY loaded for members.
     * Admin pages have their own sidebar directly
     * inside pascco_admin_header().
     */

    $current_file =
        basename($_SERVER['PHP_SELF']);

    $admin_pages = [

        'admin_dashboard.php',
        'admin_members.php',
        'admin_membership.php',
        'admin_account_requests.php',
        'admin_loans.php',
        'admin_deposits.php',
        'admin_announcements.php',

    ];

    $public_pages = [

        // Public information pages
        'home.php',
        'about.php',
        'savings.php',
        'credit.php',
        'requirements.php',
        'support.php',
        'privacy.php',

        // Applicant and authentication pages
        'login.php',
        'register.php',
        'membership_documents.php',
        'forgot_password.php',
        'reset_password.php',
        'otp_verify.php',
        'member_otp_verify.php',

    ];

    if (!in_array(
        $current_file,
        $admin_pages,
        true
    ) && !in_array(
        $current_file,
        $public_pages,
        true
    )) {

        ?>

        <!-- MEMBER SIDEBAR -->
        <script src="sidebar.js?v=1004"></script>

        <?php

    }

    ?>

    <!-- ANIMATED BUTTON SCRIPT -->
    <script src="animated-button.js?v=3"></script>

    <!-- =====================================================
         ADMIN SIDEBAR SCRIPT
    ====================================================== -->

    <?php if (in_array($current_file, $admin_pages, true)): ?>

    <script>

        document.addEventListener(
            'DOMContentLoaded',
            function () {

                const sidebar =
                    document.getElementById(
                        'pascco-admin-sidebar'
                    );

                const overlay =
                    document.getElementById(
                        'pascco-admin-sidebar-overlay'
                    );

                const openButton =
                    document.getElementById(
                        'open-pascco-admin-sidebar'
                    );

                const closeButton =
                    document.getElementById(
                        'close-pascco-admin-sidebar'
                    );

                if (
                    !sidebar ||
                    !overlay ||
                    !openButton ||
                    !closeButton
                ) {

                    console.warn(
                        'PASCCO Admin Sidebar: Required elements were not found.'
                    );

                    return;
                }

                /* =============================================
                   OPEN
                ============================================== */

                function openAdminSidebar(event) {

                    if (event) {

                        event.preventDefault();

                        event.stopPropagation();

                    }

                    sidebar.classList.add(
                        'is-open'
                    );

                    overlay.classList.add(
                        'is-open'
                    );

                    sidebar.setAttribute(
                        'aria-hidden',
                        'false'
                    );

                    overlay.setAttribute(
                        'aria-hidden',
                        'false'
                    );

                    openButton.setAttribute(
                        'aria-expanded',
                        'true'
                    );

                    document.body.classList.add(
                        'pascco-admin-sidebar-open'
                    );

                }

                /* =============================================
                   CLOSE
                ============================================== */

                function closeAdminSidebar(event) {

                    if (event) {

                        event.preventDefault();

                        event.stopPropagation();

                    }

                    sidebar.classList.remove(
                        'is-open'
                    );

                    overlay.classList.remove(
                        'is-open'
                    );

                    sidebar.setAttribute(
                        'aria-hidden',
                        'true'
                    );

                    overlay.setAttribute(
                        'aria-hidden',
                        'true'
                    );

                    openButton.setAttribute(
                        'aria-expanded',
                        'false'
                    );

                    document.body.classList.remove(
                        'pascco-admin-sidebar-open'
                    );

                }

                /* =============================================
                   EVENTS
                ============================================== */

                openButton.addEventListener(
                    'click',
                    openAdminSidebar
                );

                closeButton.addEventListener(
                    'click',
                    closeAdminSidebar
                );

                overlay.addEventListener(
                    'click',
                    closeAdminSidebar
                );

                sidebar
                    .querySelectorAll(
                        '.pascco-admin-sidebar-link'
                    )
                    .forEach(
                        function (link) {

                            link.addEventListener(
                                'click',
                                function () {

                                    closeAdminSidebar();

                                }
                            );

                        }
                    );

                /* =============================================
                   ESC KEY
                ============================================== */

                document.addEventListener(
                    'keydown',
                    function (event) {

                        if (
                            event.key === 'Escape' &&
                            sidebar.classList.contains(
                                'is-open'
                            )
                        ) {

                            closeAdminSidebar();

                        }

                    }
                );

            }
        );

    </script>

    <?php endif; ?>

    <?php
}
?>
