<?php
require_once 'pascco_layout.php';
pascco_header('Help and Support');
?>
<style>
    :root { --support-navy:#071d49; --support-blue:#1456a0; --support-gold:#e7b84b; --support-bg:#f4f7fb; --support-line:#dbe5f0; --support-muted:#667890; }
    body { background:linear-gradient(180deg,#edf4fb 0,#f7f9fc 420px,var(--support-bg) 100%); }
    .support-page { max-width:1180px; margin:0 auto; padding:34px 22px 64px; }
    .support-hero { display:flex; justify-content:space-between; align-items:end; gap:24px; margin-bottom:24px; }
    .support-eyebrow { display:inline-flex; align-items:center; gap:8px; color:var(--support-blue); font-size:.76rem; font-weight:800; letter-spacing:.16em; text-transform:uppercase; }
    .support-eyebrow::before { content:''; width:28px; height:3px; border-radius:999px; background:var(--support-gold); }
    .support-hero h1 { margin:8px 0 10px; color:var(--support-navy); font-size:clamp(2rem,4vw,3rem); line-height:1.05; }
    .support-hero p { max-width:760px; margin:0; color:var(--support-muted); font-size:1rem; line-height:1.65; }
    .support-pill { display:inline-flex; align-items:center; gap:8px; padding:10px 14px; border:1px solid rgba(20,86,160,.14); border-radius:999px; background:#fff; color:var(--support-navy); font-size:.82rem; font-weight:800; box-shadow:0 8px 20px rgba(7,29,73,.05); white-space:nowrap; }
    .support-pill i { color:var(--support-blue); font-size:1.05rem; }
    .support-grid { display:grid; grid-template-columns:minmax(0,1.35fr) minmax(300px,.85fr); gap:20px; align-items:start; }
    .support-card { background:#fff; border:1px solid rgba(7,29,73,.07); border-radius:20px; box-shadow:0 14px 34px rgba(7,29,73,.07); overflow:hidden; }
    .support-card-head { display:flex; align-items:center; gap:13px; padding:20px 24px 17px; border-bottom:1px solid var(--support-line); }
    .support-icon { width:42px; height:42px; display:grid; place-items:center; flex:0 0 42px; border-radius:12px; background:#edf4fd; color:var(--support-blue); font-size:22px; }
    .support-card-head h2 { margin:0; color:var(--support-navy); font-size:1.18rem; }
    .support-card-head p { margin:4px 0 0; color:var(--support-muted); font-size:.82rem; line-height:1.45; }
    .support-card-body { padding:22px 24px 24px; }
    .contact-list { display:grid; gap:12px; }
    .contact-item { display:flex; align-items:flex-start; gap:12px; padding:13px 14px; border:1px solid #e8eef5; border-radius:14px; background:#fbfdff; }
    .contact-item i { color:var(--support-blue); font-size:20px; margin-top:1px; }
    .contact-item strong { display:block; color:var(--support-navy); font-size:.84rem; }
    .contact-item a,.contact-item span { display:block; margin-top:3px; color:#5d7088; font-size:.85rem; line-height:1.45; text-decoration:none; }
    .contact-item a:hover { color:var(--support-blue); }
    .request-list { list-style:none; margin:0; padding:0; display:grid; gap:12px; }
    .request-list li { display:flex; gap:11px; align-items:flex-start; color:#5d7088; font-size:.86rem; line-height:1.5; }
    .request-list i { color:var(--support-gold); font-size:18px; margin-top:2px; }
    .security-card { margin-top:20px; background:linear-gradient(135deg,var(--support-navy),var(--support-blue)); border:0; color:#fff; }
    .security-card .support-card-head { border-bottom-color:rgba(255,255,255,.15); }
    .security-card .support-icon { background:rgba(255,255,255,.12); color:var(--support-gold); }
    .security-card .support-card-head h2 { color:#fff; }
    .security-card .support-card-head p,.security-copy { color:#dbe7fa; }
    .security-copy { margin:0; font-size:.86rem; line-height:1.65; }
    .support-actions { margin-top:22px; display:flex; flex-wrap:wrap; gap:10px; }
    .support-button { display:inline-flex; align-items:center; gap:7px; padding:11px 16px; border-radius:11px; background:var(--support-gold); color:var(--support-navy); font-weight:800; text-decoration:none; box-shadow:0 8px 18px rgba(7,29,73,.08); }
    .support-button.secondary { background:#fff; border:1px solid var(--support-line); color:var(--support-navy); }
    .support-button:hover { transform:translateY(-1px); }
    @media (max-width:900px) { .support-hero { align-items:flex-start; flex-direction:column; } .support-grid { grid-template-columns:1fr; } }
    @media (max-width:600px) { .support-page { padding:26px 14px 52px; } .support-card-head,.support-card-body { padding-left:18px; padding-right:18px; } .support-hero h1 { font-size:2rem; } .support-pill { white-space:normal; } }
</style>
<main class="support-page">
    <section class="support-hero">
        <div>
            <div class="support-eyebrow">Member care</div>
            <h1>Help &amp; Support</h1>
            <p>For account concerns, transaction questions, loan applications, or cooperative services, contact PASCCO using the details below.</p>
        </div>
        <div class="support-pill"><i class="bx bx-headphone"></i> PASCCO Member Support</div>
    </section>

    <section class="support-grid">
        <article class="support-card">
            <header class="support-card-head">
                <div class="support-icon"><i class="bx bx-building-house"></i></div>
                <div>
                    <h2>Contact the Office</h2>
                    <p>Use these official contact details for assistance.</p>
                </div>
            </header>
            <div class="support-card-body">
                <div class="contact-list">
                    <div class="contact-item">
                        <i class="bx bx-envelope"></i>
                        <div><strong>Email</strong><a href="mailto:pascco30@gmail.com">pascco30@gmail.com</a></div>
                    </div>
                    <div class="contact-item">
                        <i class="bx bx-mobile"></i>
                        <div><strong>SMART</strong><span>0908-3688038</span></div>
                    </div>
                    <div class="contact-item">
                        <i class="bx bx-map"></i>
                        <div><strong>Office Address</strong><span>1461 Merced corner Perdigon Streets,<br>Paco 1007 Manila</span></div>
                    </div>
                    <div class="contact-item">
                        <i class="bx bxl-facebook-circle"></i>
                        <div><strong>Facebook</strong><a href="https://www.facebook.com/pacopascco" target="_blank" rel="noopener noreferrer">facebook.com/pacopascco</a></div>
                    </div>
                </div>
            </div>
        </article>

        <div>
            <article class="support-card">
                <header class="support-card-head">
                    <div>
                        <h2>Include in Your Request</h2>
                        <p>Providing complete details helps the office assist you faster.</p>
                    </div>
                </header>
                <div class="support-card-body">
                    <ul class="request-list">
                        <li><i class="bx bx-check-circle"></i><span>Your full name and member number</span></li>
                        <li><i class="bx bx-check-circle"></i><span>Account or loan reference number</span></li>
                        <li><i class="bx bx-check-circle"></i><span>Date and amount of the transaction</span></li>
                        <li><i class="bx bx-check-circle"></i><span>A short description of the concern</span></li>
                    </ul>
                </div>
            </article>

            <article class="support-card security-card">
                <header class="support-card-head">
                    <div class="support-icon"><i class="bx bx-shield-quarter"></i></div>
                    <div>
                        <h2>Security Reminder</h2>
                        <p>Protect your member account information.</p>
                    </div>
                </header>
                <div class="support-card-body">
                    <p class="security-copy">PASCCO will never ask for your password or one-time security code. Do not share them through email, chat, or social media.</p>
                </div>
            </article>
        </div>
    </section>
</main>
<?php pascco_footer(); ?>
