<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') {
    header('Location: login.php');
    exit;
}

$user_id = (int) $_SESSION['user_id'];
$message = '';
$error = '';
$submitted_request_id = 0;
$payment_methods = ['GCash', 'Maya', 'ShopeePay', 'GrabPay', 'Other E-Wallet'];
$description_options = ['Counter Deposit', 'Monthly Savings', 'Salary Savings', 'Other'];
$upload_directory = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'deposit_receipts';

if (!is_dir($upload_directory)) {
    mkdir($upload_directory, 0700, true);
}

$account_stmt = $pdo->prepare("SELECT a.id AS account_id, a.account_number, a.account_type, a.balance FROM members m JOIN accounts a ON a.member_id = m.id WHERE m.user_id = ? AND a.status = 'active' ORDER BY a.id");
$account_stmt->execute([$user_id]);
$accounts = $account_stmt->fetchAll();

$request_stmt = $pdo->prepare("SELECT d.id, d.amount, d.payment_method, d.payment_reference, d.status, d.admin_notes, d.created_at, a.account_number FROM deposit_requests d JOIN accounts a ON a.id = d.account_id JOIN members m ON m.id = d.member_id WHERE m.user_id = ? ORDER BY d.id DESC LIMIT 5");
$request_stmt->execute([$user_id]);
$deposit_requests = $request_stmt->fetchAll();

$selected_account_id = (int) ($_POST['account_id'] ?? ($accounts[0]['account_id'] ?? 0));
$amount = trim($_POST['amount'] ?? '');
$description = trim($_POST['description'] ?? '');
$custom_description = trim($_POST['custom_description'] ?? '');
$payment_method = trim($_POST['payment_method'] ?? '');
$payment_reference = trim($_POST['payment_reference'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $selected_account = null;
    foreach ($accounts as $account) {
        if ((int) $account['account_id'] === $selected_account_id) {
            $selected_account = $account;
            break;
        }
    }

    $deposit_description = $description === 'Other' ? $custom_description : $description;
    $receipt_path = null;

    if (!$selected_account) {
        $error = 'Please select one of your active savings accounts.';
    } elseif (!is_numeric($amount) || (float) $amount <= 0) {
        $error = 'Please enter a deposit amount greater than zero.';
    } elseif (!in_array($payment_method, $payment_methods, true)) {
        $error = 'Please select the e-wallet used for the deposit.';
    } elseif ($payment_reference === '') {
        $error = 'Please enter the e-wallet reference number.';
    } elseif (!in_array($description, $description_options, true) || ($description === 'Other' && $custom_description === '')) {
        $error = 'Please select or enter a valid deposit description.';
    } elseif (!isset($_FILES['receipt']) || $_FILES['receipt']['error'] === UPLOAD_ERR_NO_FILE) {
        $error = 'Please upload the e-wallet receipt.';
    } else {
        try {
            $receipt = $_FILES['receipt'];
            $allowed_types = ['image/jpeg' => 'jpg', 'image/png' => 'png'];
            $mime_type = (new finfo(FILEINFO_MIME_TYPE))->file($receipt['tmp_name']);

            if ($receipt['error'] !== UPLOAD_ERR_OK || !isset($allowed_types[$mime_type]) || $receipt['size'] > 5 * 1024 * 1024) {
                throw new RuntimeException('Receipt must be a JPG or PNG image up to 5 MB.');
            }

            $receipt_name = bin2hex(random_bytes(24)) . '.' . $allowed_types[$mime_type];
            if (!move_uploaded_file($receipt['tmp_name'], $upload_directory . DIRECTORY_SEPARATOR . $receipt_name)) {
                throw new RuntimeException('The receipt could not be saved.');
            }

            $receipt_path = 'uploads/deposit_receipts/' . $receipt_name;

            $member_stmt = $pdo->prepare('SELECT m.id FROM members m JOIN accounts a ON a.member_id = m.id WHERE m.user_id = ? AND a.id = ? AND a.status = \'active\'');
            $member_stmt->execute([$user_id, $selected_account_id]);
            $member = $member_stmt->fetch();

            if (!$member) {
                throw new RuntimeException('The selected savings account is not available.');
            }

            $insert = $pdo->prepare("INSERT INTO deposit_requests (account_id, member_id, amount, payment_method, payment_reference, description, receipt_path) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $insert->execute([
                $selected_account_id,
                $member['id'],
                (float) $amount,
                $payment_method,
                $payment_reference,
                $deposit_description,
                $receipt_path
            ]);

            $submitted_request_id = (int) $pdo->lastInsertId();
            record_audit($pdo, $user_id, 'deposit_request', 'Submitted deposit request ' . $submitted_request_id, 'success');
            $message = 'Deposit submitted for admin review. Your balance will update after approval.';

            $amount = '';
            $description = '';
            $custom_description = '';
            $payment_method = '';
            $payment_reference = '';

            $account_stmt->execute([$user_id]);
            $accounts = $account_stmt->fetchAll();

            $request_stmt->execute([$user_id]);
            $deposit_requests = $request_stmt->fetchAll();
        } catch (Throwable $exception) {
            if ($receipt_path) {
                $absolute_path = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $receipt_path);
                if (is_file($absolute_path)) {
                    unlink($absolute_path);
                }
            }

            $error = $exception->getMessage();
        }
    }
}

$selected_account = null;
foreach ($accounts as $account) {
    if ((int) $account['account_id'] === $selected_account_id) {
        $selected_account = $account;
        break;
    }
}

if (!$selected_account && $accounts) {
    $selected_account = $accounts[0];
    $selected_account_id = (int) $selected_account['account_id'];
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php pascco_global_styles(); ?>

    <title>Deposit Money | PASCCO</title>

    <link rel="stylesheet" href="member-panels.css?v=4">

    <style>
        :root{
            --deposit-navy:#071d49;
            --deposit-blue:#1456a0;
            --deposit-gold:#f4c542;
            --deposit-ink:#17243a;
            --deposit-muted:#6d7c91;
            --deposit-line:#dfe7f0;
            --deposit-panel:#fff;
            --deposit-canvas:#f4f7fb;
            --deposit-soft:#eef4fb;
            --deposit-success:#14804a;
            --deposit-danger:#b23b3b;
        }

        html,body{margin:0!important;padding:0!important;min-height:100%;overflow-x:hidden}
        *,*::before,*::after{box-sizing:border-box}
        body{background:var(--deposit-canvas);color:var(--deposit-ink)}
        .pascco-global-header{width:100%;margin:0;box-sizing:border-box}

        .deposit-page{width:min(1180px,calc(100% - 32px));margin:0 auto;padding:34px 0 64px}
        .deposit-welcome{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:24px}
        .deposit-eyebrow{margin:0 0 7px;color:var(--deposit-blue);font-size:.72rem;font-weight:900;letter-spacing:.15em;text-transform:uppercase}
        .deposit-welcome h1{margin:0;color:var(--deposit-navy);font-size:clamp(1.7rem,3vw,2.15rem);line-height:1.15}
        .deposit-welcome p{margin:8px 0 0;color:var(--deposit-muted);font-size:.88rem}

        .deposit-back{display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:42px;padding:0 15px;border:1px solid var(--deposit-line);border-radius:10px;background:#fff;color:var(--deposit-navy);text-decoration:none;font-size:.78rem;font-weight:900;transition:.18s ease}
        .deposit-back:hover{transform:translateY(-1px);border-color:var(--deposit-blue);color:var(--deposit-blue)}

        .deposit-layout{display:grid;grid-template-columns:minmax(0,1.42fr) minmax(290px,.58fr);gap:18px;align-items:start}
        .deposit-card,.deposit-guide,.deposit-history{background:var(--deposit-panel);border:1px solid var(--deposit-line);box-shadow:0 10px 28px rgba(15,39,72,.055)}
        .deposit-card{border-radius:20px;overflow:hidden}
        .deposit-card-header{display:flex;align-items:center;justify-content:space-between;gap:15px;padding:22px 24px;border-bottom:1px solid #edf1f6}
        .deposit-card-heading{display:flex;align-items:center;gap:12px}
        .deposit-card-icon,.deposit-history-icon,.deposit-guide-icon{display:grid;place-items:center;width:42px;height:42px;border-radius:12px;background:var(--deposit-soft);color:var(--deposit-blue);font-size:21px}
        .deposit-card-heading h2,.deposit-history-heading h2{margin:0;color:var(--deposit-navy);font-size:1.08rem}
        .deposit-card-heading p,.deposit-history-heading p{margin:4px 0 0;color:var(--deposit-muted);font-size:.76rem}
        .deposit-secure{display:inline-flex;align-items:center;gap:6px;padding:7px 10px;border-radius:999px;background:#edf9f4;color:var(--deposit-success);font-size:.67rem;font-weight:900;white-space:nowrap}

        .deposit-form{padding:24px}
        .deposit-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
        .deposit-field{display:flex;flex-direction:column;gap:7px}
        .deposit-field.full{grid-column:1/-1}
        .deposit-field label{margin:0;color:var(--deposit-navy);font-size:.75rem;font-weight:900}
        .deposit-field label span{color:#8b98aa;font-weight:700}
        .deposit-field input,.deposit-field select,.deposit-field textarea{width:100%;border:1px solid var(--deposit-line);border-radius:9px;background:#fff;color:var(--deposit-ink);font:inherit;font-size:.82rem;outline:0;transition:.2s ease}
        .deposit-field input,.deposit-field select{height:46px;padding:0 13px}
        .deposit-field textarea{min-height:88px;padding:11px 13px;resize:vertical}
        .deposit-field input:focus,.deposit-field select:focus,.deposit-field textarea:focus{border-color:var(--deposit-blue);box-shadow:0 0 0 3px rgba(20,86,160,.09)}
        .deposit-field small{margin-top:-2px;color:var(--deposit-muted);font-size:.69rem;line-height:1.5}

        .account-preview{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:13px 15px;border:1px solid #dbe5f0;border-radius:10px;background:#f8fafd;margin-top:2px}
        .account-preview-info{min-width:0;display:flex;flex-direction:column;gap:3px}.account-preview-info strong{color:var(--deposit-navy);font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.account-preview-info span{color:var(--deposit-muted);font-size:.7rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.account-preview-balance{color:var(--deposit-blue);font-size:.95rem;font-weight:900;white-space:nowrap}

        .receipt-upload{position:relative;border:1.5px dashed #b9c9dc;border-radius:12px;background:#f8fafd;padding:20px;text-align:center;transition:.18s ease}
        .receipt-upload:hover{border-color:var(--deposit-blue);background:#f5f9fe}
        .receipt-upload input[type=file]{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;padding:0}
        .receipt-upload-content{display:flex;flex-direction:column;align-items:center;gap:6px;pointer-events:none}
        .receipt-upload-content i{display:grid;place-items:center;width:46px;height:46px;border-radius:13px;background:#eaf1fa;color:var(--deposit-blue);font-size:23px}
        .receipt-upload-content strong{color:var(--deposit-navy);font-size:.78rem}.receipt-upload-content span{color:var(--deposit-muted);font-size:.69rem}

        .conditional-details{display:none}.conditional-details.visible{display:flex}
        .deposit-actions{display:flex;align-items:center;justify-content:space-between;gap:15px;margin-top:20px;padding-top:18px;border-top:1px solid #edf1f6}
        .deposit-actions-note{display:flex;align-items:center;gap:7px;color:var(--deposit-muted);font-size:.7rem;line-height:1.45}.deposit-actions-note i{color:var(--deposit-blue);font-size:1rem}
        .deposit-submit{min-height:45px;padding:0 20px;border:0;border-radius:9px;background:var(--deposit-blue);color:#fff;font:inherit;font-size:.79rem;font-weight:900;cursor:pointer;transition:.18s ease;white-space:nowrap}.deposit-submit:hover{background:var(--deposit-navy);color:var(--deposit-gold);transform:translateY(-1px)}.deposit-submit i{margin-right:5px;vertical-align:-2px}

        .deposit-guide{border:0;border-radius:20px;overflow:hidden;background:linear-gradient(145deg,var(--deposit-navy),#104f91);color:#fff;box-shadow:0 18px 40px rgba(7,29,73,.16)}
        .deposit-guide-inner{position:relative;overflow:hidden;padding:24px}.deposit-guide-inner::before,.deposit-guide-inner::after{content:"";position:absolute;border-radius:50%;background:rgba(255,255,255,.07);pointer-events:none}.deposit-guide-inner::before{width:200px;height:200px;right:-80px;top:-80px}.deposit-guide-inner::after{width:130px;height:130px;right:40px;bottom:-85px}
        .deposit-guide-content{position:relative;z-index:1}.deposit-guide-top{display:flex;align-items:center;gap:11px;margin-bottom:14px}.deposit-guide-icon{background:rgba(255,255,255,.1);color:var(--deposit-gold)}.deposit-guide h2{margin:0;color:#fff;font-size:1.05rem}.deposit-guide p{margin:6px 0 0;color:#dbe7f8;font-size:.73rem;line-height:1.55}
        .deposit-steps{display:flex;flex-direction:column;gap:12px;margin:19px 0 0;padding:0;list-style:none}.deposit-step{display:flex;gap:11px;align-items:flex-start}.deposit-step-number{display:grid;place-items:center;width:26px;height:26px;flex:0 0 26px;border:1px solid rgba(244,197,66,.55);border-radius:50%;background:rgba(244,197,66,.1);color:var(--deposit-gold);font-size:.67rem;font-weight:900}.deposit-step div{padding-top:2px}.deposit-step strong{display:block;color:#fff;font-size:.75rem}.deposit-step span{display:block;margin-top:3px;color:#c9d8ec;font-size:.68rem;line-height:1.45}

        .deposit-note{display:flex;gap:9px;margin-top:20px;padding:12px 13px;border:1px solid rgba(255,255,255,.13);border-radius:10px;background:rgba(255,255,255,.05);color:#cfe0f3;font-size:.68rem;line-height:1.5}.deposit-note i{color:var(--deposit-gold);font-size:1rem}

        .deposit-history{margin-top:18px;border-radius:20px;overflow:hidden}
        .deposit-history-header{display:flex;align-items:center;justify-content:space-between;gap:15px;padding:22px 24px;border-bottom:1px solid #edf1f6}
        .deposit-history-heading{display:flex;align-items:center;gap:12px}.deposit-history-icon{background:var(--deposit-soft)}
        .deposit-history-count{padding:6px 9px;border-radius:999px;background:#f1f5fa;color:var(--deposit-muted);font-size:.67rem;font-weight:900}
        .deposit-table-wrap{width:100%;overflow:auto}.deposit-table{width:100%;min-width:790px;border-collapse:collapse}.deposit-table th{padding:12px 18px;background:#f5f8fc;color:#65758d;text-align:left;font-size:.67rem;font-weight:900;letter-spacing:.06em;text-transform:uppercase;border-bottom:1px solid #e6ecf3}.deposit-table td{padding:14px 18px;color:#334155;font-size:.74rem;border-bottom:1px solid #edf1f6;vertical-align:middle}.deposit-table tbody tr:hover{background:#fbfcfe}
        .request-reference{color:var(--deposit-navy);font-weight:900}.request-reference small{display:block;margin-top:3px;color:#8b98aa;font-size:.64rem;font-weight:600}.request-amount{color:var(--deposit-blue);font-weight:900;white-space:nowrap}.request-status{display:inline-flex;padding:5px 8px;border-radius:999px;font-size:.61rem;font-weight:900;text-transform:uppercase}.request-status.pending{background:#fff7df;color:#9a7410}.request-status.approved{background:#eaf7ef;color:var(--deposit-success)}.request-status.rejected{background:#fff0f0;color:var(--deposit-danger)}.request-status.processing{background:#edf4fc;color:var(--deposit-blue)}.request-note{display:block;margin-top:4px;max-width:200px;color:var(--deposit-muted);font-size:.62rem;line-height:1.4}

        .deposit-empty{padding:48px 20px;text-align:center;color:var(--deposit-muted)}.deposit-empty i{display:grid;place-items:center;width:58px;height:58px;margin:0 auto 14px;border-radius:16px;background:var(--deposit-soft);color:var(--deposit-blue);font-size:27px}.deposit-empty h3{margin:0 0 6px;color:var(--deposit-navy);font-size:1rem}.deposit-empty p{margin:0;font-size:.78rem}

        .deposit-alert{display:flex;align-items:flex-start;gap:10px;margin:0 24px 18px;padding:12px 14px;border:1px solid;border-radius:10px;font-size:.76rem;line-height:1.5}.deposit-alert i{font-size:1.05rem;margin-top:1px}.deposit-alert.success{background:#edf9f4;border-color:#b9e5d2;color:var(--deposit-success)}.deposit-alert.error{background:#fff1f1;border-color:#efc5c5;color:var(--deposit-danger)}

        .no-accounts{padding:24px}.no-accounts-box{padding:30px;border:1px dashed #c9d6e5;border-radius:14px;background:#f8fafd;text-align:center}.no-accounts-box i{display:grid;place-items:center;width:56px;height:56px;margin:0 auto 12px;border-radius:15px;background:var(--deposit-soft);color:var(--deposit-blue);font-size:25px}.no-accounts-box h2{margin:0 0 6px;color:var(--deposit-navy);font-size:1rem}.no-accounts-box p{margin:0;color:var(--deposit-muted);font-size:.76rem;line-height:1.5}.no-accounts-box a{display:inline-flex;margin-top:15px;min-height:40px;padding:0 14px;align-items:center;justify-content:center;border-radius:9px;background:var(--deposit-blue);color:#fff;text-decoration:none;font-size:.74rem;font-weight:900}.no-accounts-box a:hover{background:var(--deposit-navy);color:var(--deposit-gold)}

        @media(max-width:900px){.deposit-layout{grid-template-columns:1fr}.deposit-guide{order:2}.deposit-history{margin-top:18px}}
        @media(max-width:700px){.deposit-page{width:min(100% - 24px,1180px);padding:28px 0 52px}.deposit-welcome{align-items:stretch;flex-direction:column}.deposit-back{width:100%}.deposit-form-grid{grid-template-columns:1fr}.deposit-field.full{grid-column:auto}.deposit-card-header,.deposit-history-header{padding:18px}.deposit-form{padding:18px}.deposit-alert{margin-left:18px;margin-right:18px}.deposit-actions{align-items:stretch;flex-direction:column}.deposit-submit{width:100%}.deposit-actions-note{align-items:flex-start}.deposit-guide-inner{padding:20px}}
        @media(max-width:520px){.deposit-secure{display:none}.account-preview{align-items:flex-start;flex-direction:column}.account-preview-balance{white-space:normal}.deposit-table th,.deposit-table td{padding:12px}.deposit-history-heading p{display:none}}
    </style>
</head>
<body>

<?php pascco_member_header('Deposit Money'); ?>

<main class="deposit-page member-content">

    <section class="deposit-welcome">
        <div>
            <div class="deposit-eyebrow">Member Services</div>
            <h1>Deposit Money</h1>
            <p>Submit an e-wallet deposit request securely for admin verification.</p>
        </div>

        <a href="dashboard.php" class="deposit-back">
            <i class="bx bx-arrow-back"></i>
            Back to Dashboard
        </a>
    </section>

    <?php if ($message): ?>
        <div class="deposit-alert success" role="status">
            <i class="bx bx-check-circle"></i>
            <div>
                <strong><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></strong>
                <?php if ($submitted_request_id): ?>
                    <div>Request #<?php echo $submitted_request_id; ?> has been recorded.</div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="deposit-alert error" role="alert">
            <i class="bx bx-error-circle"></i>
            <div><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        </div>
    <?php endif; ?>

    <div class="deposit-layout">

        <section class="deposit-card">
            <div class="deposit-card-header">
                <div class="deposit-card-heading">
                    <div class="deposit-card-icon"><i class="bx bx-wallet"></i></div>
                    <div>
                        <h2>New Deposit Request</h2>
                        <p>Complete the details below and upload your payment receipt.</p>
                    </div>
                </div>

                <div class="deposit-secure">
                    <i class="bx bx-lock-alt"></i>
                    Secure Submission
                </div>
            </div>

            <?php if ($accounts): ?>
                <form class="deposit-form" method="POST" action="deposit.php" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

                    <div class="deposit-form-grid">

                        <div class="deposit-field full">
                            <label for="account-id">Deposit To</label>
                            <select id="account-id" name="account_id" required>
                                <?php foreach ($accounts as $account): ?>
                                    <option
                                        value="<?php echo (int) $account['account_id']; ?>"
                                        data-balance="<?php echo htmlspecialchars((string) (float) $account['balance'], ENT_QUOTES, 'UTF-8'); ?>"
                                        data-number="<?php echo htmlspecialchars($account['account_number'], ENT_QUOTES, 'UTF-8'); ?>"
                                        data-type="<?php echo htmlspecialchars($account['account_type'], ENT_QUOTES, 'UTF-8'); ?>"
                                        <?php echo (int) $account['account_id'] === $selected_account_id ? 'selected' : ''; ?>
                                    >
                                        <?php echo htmlspecialchars($account['account_type'] . ' — ' . $account['account_number'], ENT_QUOTES, 'UTF-8'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <div class="account-preview" id="account-preview">
                                <div class="account-preview-info">
                                    <strong id="preview-type"><?php echo $selected_account ? htmlspecialchars($selected_account['account_type'], ENT_QUOTES, 'UTF-8') : ''; ?></strong>
                                    <span id="preview-number"><?php echo $selected_account ? htmlspecialchars($selected_account['account_number'], ENT_QUOTES, 'UTF-8') : ''; ?></span>
                                </div>
                                <div class="account-preview-balance" id="preview-balance">
                                    ₱<?php echo $selected_account ? number_format((float) $selected_account['balance'], 2) : '0.00'; ?> current balance
                                </div>
                            </div>
                        </div>

                        <div class="deposit-field">
                            <label for="amount">Deposit Amount <span>(PHP)</span></label>
                            <input id="amount" type="number" name="amount" min="0.01" step="0.01" inputmode="decimal" value="<?php echo htmlspecialchars($amount, ENT_QUOTES, 'UTF-8'); ?>" placeholder="0.00" required>
                            <small>Enter the exact amount shown on your e-wallet transfer.</small>
                        </div>

                        <div class="deposit-field">
                            <label for="payment-method">E-Wallet Used</label>
                            <select id="payment-method" name="payment_method" required>
                                <option value="">Select e-wallet</option>
                                <?php foreach ($payment_methods as $method): ?>
                                    <option value="<?php echo htmlspecialchars($method, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $payment_method === $method ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($method, ENT_QUOTES, 'UTF-8'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="deposit-field full">
                            <label for="payment-reference">E-Wallet Reference Number</label>
                            <input id="payment-reference" type="text" name="payment_reference" value="<?php echo htmlspecialchars($payment_reference, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Enter the reference number from your transfer or receipt" autocomplete="off" required>
                            <small>This is the transaction/reference number generated by your e-wallet.</small>
                        </div>

                        <div class="deposit-field">
                            <label for="description">Deposit Purpose</label>
                            <select id="description" name="description" required>
                                <option value="">Select purpose</option>
                                <?php foreach ($description_options as $option): ?>
                                    <option value="<?php echo htmlspecialchars($option, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $description === $option ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($option, ENT_QUOTES, 'UTF-8'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="deposit-field conditional-details <?php echo $description === 'Other' ? 'visible' : ''; ?>" id="custom-description-field">
                            <label for="custom-description">Additional Details</label>
                            <input id="custom-description" name="custom_description" value="<?php echo htmlspecialchars($custom_description, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Describe the deposit purpose">
                            <small>Required when you select “Other”.</small>
                        </div>

                        <div class="deposit-field full">
                            <label for="receipt">Upload E-Wallet Receipt</label>
                            <div class="receipt-upload" id="receipt-upload">
                                <input id="receipt" type="file" name="receipt" accept="image/jpeg,image/png" required>
                                <div class="receipt-upload-content">
                                    <i class="bx bx-cloud-upload"></i>
                                    <strong id="receipt-label">Choose JPG or PNG receipt</strong>
                                    <span id="receipt-name">Maximum file size: 5 MB</span>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="deposit-actions">
                        <div class="deposit-actions-note">
                            <i class="bx bx-info-circle"></i>
                            <span>Your request stays pending until an admin verifies the payment receipt.</span>
                        </div>
                        <button type="submit" class="deposit-submit">
                            <i class="bx bx-send"></i>
                            Submit Deposit Request
                        </button>
                    </div>
                </form>
            <?php else: ?>
                <div class="no-accounts">
                    <div class="no-accounts-box">
                        <i class="bx bx-wallet-alt"></i>
                        <h2>No Active Savings Account</h2>
                        <p>You need an active savings account before you can submit a deposit request.</p>
                        <a href="open_account.php">Open a Savings Account</a>
                    </div>
                </div>
            <?php endif; ?>
        </section>

        <aside class="deposit-guide">
            <div class="deposit-guide-inner">
                <div class="deposit-guide-content">
                    <div class="deposit-guide-top">
                        <div class="deposit-guide-icon"><i class="bx bx-list-check"></i></div>
                        <div>
                            <h2>How to Deposit</h2>
                            <p>Follow these steps to make sure your request is easy to verify.</p>
                        </div>
                    </div>

                    <ol class="deposit-steps">
                        <li class="deposit-step">
                            <span class="deposit-step-number">1</span>
                            <div><strong>Select your account</strong><span>Choose the active PASCCO savings account you want to credit.</span></div>
                        </li>
                        <li class="deposit-step">
                            <span class="deposit-step-number">2</span>
                            <div><strong>Send the money</strong><span>Transfer the deposit using your preferred supported e-wallet.</span></div>
                        </li>
                        <li class="deposit-step">
                            <span class="deposit-step-number">3</span>
                            <div><strong>Enter the details</strong><span>Provide the exact amount and e-wallet reference number.</span></div>
                        </li>
                        <li class="deposit-step">
                            <span class="deposit-step-number">4</span>
                            <div><strong>Upload the receipt</strong><span>Attach a clear JPG or PNG image of the completed transfer.</span></div>
                        </li>
                        <li class="deposit-step">
                            <span class="deposit-step-number">5</span>
                            <div><strong>Wait for verification</strong><span>Your balance updates only after admin approval.</span></div>
                        </li>
                    </ol>

                    <div class="deposit-note">
                        <i class="bx bx-shield-quarter"></i>
                        <span>Never upload passwords, PINs, OTPs, or other confidential credentials. Only the payment receipt is required.</span>
                    </div>
                </div>
            </div>
        </aside>

    </div>

    <?php if ($deposit_requests): ?>
        <section class="deposit-history">
            <div class="deposit-history-header">
                <div class="deposit-history-heading">
                    <div class="deposit-history-icon"><i class="bx bx-history"></i></div>
                    <div>
                        <h2>Recent Deposit Requests</h2>
                        <p>Your latest submitted deposits and their review status.</p>
                    </div>
                </div>
                <div class="deposit-history-count"><?php echo count($deposit_requests); ?> recent</div>
            </div>

            <div class="deposit-table-wrap">
                <table class="deposit-table">
                    <thead>
                        <tr>
                            <th>Request</th>
                            <th>Account</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Status</th>
                            <th>Submitted</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($deposit_requests as $request): ?>
                            <?php
                                $request_status = strtolower(trim((string) $request['status']));
                                $request_status_class = in_array($request_status, ['pending', 'approved', 'rejected', 'processing'], true) ? $request_status : 'processing';
                            ?>
                            <tr>
                                <td class="request-reference">
                                    #<?php echo (int) $request['id']; ?>
                                    <small><?php echo htmlspecialchars($request['payment_reference'], ENT_QUOTES, 'UTF-8'); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($request['account_number'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td class="request-amount">₱<?php echo number_format((float) $request['amount'], 2); ?></td>
                                <td><?php echo htmlspecialchars($request['payment_method'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td>
                                    <span class="request-status <?php echo $request_status_class; ?>">
                                        <?php echo strtoupper(htmlspecialchars($request['status'], ENT_QUOTES, 'UTF-8')); ?>
                                    </span>
                                    <?php if ($request['admin_notes']): ?>
                                        <span class="request-note"><?php echo htmlspecialchars($request['admin_notes'], ENT_QUOTES, 'UTF-8'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($request['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php else: ?>
        <section class="deposit-history">
            <div class="deposit-empty">
                <i class="bx bx-receipt"></i>
                <h3>No deposit requests yet</h3>
                <p>Your submitted deposit requests will appear here after you send your first request.</p>
            </div>
        </section>
    <?php endif; ?>

</main>

<?php pascco_global_footer(); ?>

<script>
(function () {
    const accountSelect = document.getElementById('account-id');
    const previewType = document.getElementById('preview-type');
    const previewNumber = document.getElementById('preview-number');
    const previewBalance = document.getElementById('preview-balance');
    const descriptionSelect = document.getElementById('description');
    const customDescriptionField = document.getElementById('custom-description-field');
    const customDescriptionInput = document.getElementById('custom-description');
    const receiptInput = document.getElementById('receipt');
    const receiptLabel = document.getElementById('receipt-label');
    const receiptName = document.getElementById('receipt-name');

    function updateAccountPreview() {
        if (!accountSelect) return;
        const option = accountSelect.options[accountSelect.selectedIndex];
        if (!option) return;

        const balance = Number(option.dataset.balance || 0).toLocaleString('en-PH', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        if (previewType) previewType.textContent = option.dataset.type || '';
        if (previewNumber) previewNumber.textContent = option.dataset.number || '';
        if (previewBalance) previewBalance.textContent = '₱' + balance + ' current balance';
    }

    function updateDescription() {
        if (!descriptionSelect || !customDescriptionField) return;
        const isOther = descriptionSelect.value === 'Other';
        customDescriptionField.classList.toggle('visible', isOther);
        if (customDescriptionInput) {
            customDescriptionInput.required = isOther;
            if (!isOther) customDescriptionInput.value = '';
        }
    }

    function updateReceiptLabel() {
        if (!receiptInput || !receiptLabel || !receiptName) return;
        const file = receiptInput.files && receiptInput.files[0];
        if (!file) {
            receiptLabel.textContent = 'Choose JPG or PNG receipt';
            receiptName.textContent = 'Maximum file size: 5 MB';
            return;
        }
        const sizeMb = file.size / (1024 * 1024);
        receiptLabel.textContent = file.name;
        receiptName.textContent = sizeMb.toFixed(2) + ' MB';
    }

    if (accountSelect) accountSelect.addEventListener('change', updateAccountPreview);
    if (descriptionSelect) descriptionSelect.addEventListener('change', updateDescription);
    if (receiptInput) receiptInput.addEventListener('change', updateReceiptLabel);

    updateAccountPreview();
    updateDescription();
    updateReceiptLabel();
})();
</script>

</body>
</html>
