<?php
require_once 'db.php';
require_once 'pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';
$error   = '';
$description_options = [
    'Payment for shared expenses',
    'Family Support',
    'Bills Payment',
    'Loan Payment',
    'Savings Transfer',
    'Other',
];

$account_stmt = $pdo->prepare("
    SELECT a.id AS account_id, a.account_number, a.account_type, a.balance 
    FROM members m 
    JOIN accounts a ON m.id = a.member_id 
    WHERE m.user_id = ? AND a.status = 'active'
    ORDER BY a.id
");
$account_stmt->execute([$user_id]);
$accounts = $account_stmt->fetchAll();
// Load a small list of the member's most recent successful transfer recipients.
// The transfer form itself still accepts a manually entered PASCCO account number.
$recent_stmt = $pdo->prepare("
    SELECT
        t.recipient_account_id,
        t.amount,
        t.transaction_date,
        ra.account_number,
        ra.account_type,
        rm.first_name,
        rm.last_name
    FROM transactions t
    JOIN accounts sa ON sa.id = t.account_id
    JOIN members sm ON sm.id = sa.member_id
    JOIN accounts ra ON ra.id = t.recipient_account_id
    JOIN members rm ON rm.id = ra.member_id
    WHERE sm.user_id = ?
      AND t.transaction_type = 'transfer'
      AND t.status = 'completed'
      AND t.recipient_account_id IS NOT NULL
      AND ra.status = 'active'
    ORDER BY t.id DESC
    LIMIT 20
");
$recent_stmt->execute([$user_id]);
$recent_rows = $recent_stmt->fetchAll();

$recent_recipients = [];
$seen_recipient_accounts = [];
foreach ($recent_rows as $recent_row) {
    $account_number = (string) $recent_row['account_number'];
    if (isset($seen_recipient_accounts[$account_number])) {
        continue;
    }
    $seen_recipient_accounts[$account_number] = true;
    $recent_recipients[] = $recent_row;
    if (count($recent_recipients) >= 5) {
        break;
    }
}
$selected_account_id = (int) ($_POST['account_id'] ?? $_GET['account_id'] ?? ($accounts[0]['account_id'] ?? 0));
$selected_recipient_account = trim($_POST['recipient_account'] ?? '');
$sender = null;
foreach ($accounts as $available_account) {
    if ((int) $available_account['account_id'] === $selected_account_id) {
        $sender = $available_account;
        break;
    }
}

if (!$sender && $accounts) {
    $sender = $accounts[0];
    $selected_account_id = (int) $sender['account_id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $sender) {
    verify_csrf(); // Verify CSRF Token

    $recipient_acc_num = trim($_POST['recipient_account']);
    $amount            = floatval($_POST['amount']);
    $description       = trim($_POST['description'] ?? '');
    $custom_description = trim($_POST['custom_description'] ?? '');
    $description_text = $description === 'Other' ? $custom_description : $description;
    $posted_account_id = (int) ($_POST['account_id'] ?? 0);

    if ($posted_account_id !== (int) $sender['account_id']) {
        $error = "Please select a valid savings account.";
    } elseif (!in_array($description, $description_options, true)) {
        $error = "Please select a transfer description.";
    } elseif ($description === 'Other' && $custom_description === '') {
        $error = "Please enter a description for the other transfer.";
    }

    $rec_stmt = $pdo->prepare("SELECT a.id AS account_id, m.first_name, m.last_name FROM accounts a JOIN members m ON a.member_id = m.id WHERE a.account_number = ? AND m.user_id <> ? AND a.status = 'active'");
    $rec_stmt->execute([$recipient_acc_num, $user_id]);
    $recipient = $rec_stmt->fetch();

    if ($error !== '') {
        // Validation error already assigned above.
    } elseif ($amount <= 0) {
        $error = "Please enter a valid transfer amount.";
    } elseif ($amount > $sender['balance']) {
        $error = "Insufficient balance to complete this transfer!";
    } elseif (!$recipient) {
        $error = "Recipient account number not found.";
    } elseif ((int) $recipient['account_id'] === (int) $sender['account_id']) {
        $error = "You cannot transfer money to your own account.";
    } else {
        try {
            $pdo->beginTransaction();
            $lock = $pdo->prepare('SELECT balance FROM accounts WHERE id = ? AND status = \'active\' FOR UPDATE');
            $lock->execute([(int) $sender['account_id']]);
            $locked_sender = $lock->fetch();
            if (!$locked_sender || $amount > (float) $locked_sender['balance']) {
                throw new RuntimeException('The available balance changed. Please review it and try again.');
            }

            $recipient_lock = $pdo->prepare("SELECT id FROM accounts WHERE id = ? AND status = 'active' FOR UPDATE");
            $recipient_lock->execute([(int) $recipient['account_id']]);
            if (!$recipient_lock->fetch()) {
                throw new RuntimeException('The recipient account is no longer available.');
            }

            $ref_number = 'OR-' . date('YmdHis') . '-' . random_int(100000, 999999);
            $full_desc  = "Transfer to " . $recipient['first_name'] . " " . $recipient['last_name'] . " (" . $description_text . ")";
            $insert = $pdo->prepare("INSERT INTO transactions (account_id, transaction_type, amount, recipient_account_id, description, status, reference_number, transaction_date, created_at) VALUES (?, 'transfer', ?, ?, ?, 'completed', ?, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())");
            $insert->execute([$sender['account_id'], $amount, $recipient['account_id'], $full_desc, $ref_number]);
            $incoming = $pdo->prepare("INSERT INTO transactions (account_id, transaction_type, amount, recipient_account_id, description, status, reference_number, transaction_date, created_at) VALUES (?, 'deposit', ?, ?, ?, 'completed', ?, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())");
            $incoming->execute([$recipient['account_id'], $amount, $sender['account_id'], 'Transfer from ' . $sender['account_number'], $ref_number . '-IN']);
            $debit = $pdo->prepare("UPDATE accounts SET balance = balance - ? WHERE id = ? AND status = 'active'");
            $debit->execute([$amount, (int) $sender['account_id']]);
            $credit = $pdo->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ? AND status = 'active'");
            $credit->execute([$amount, (int) $recipient['account_id']]);
            $pdo->commit();
            record_audit($pdo, $user_id, 'fund_transfer', 'Completed transfer ' . $ref_number, 'success');
            $message = "Transfer of ₱" . number_format($amount, 2) . " to " . $recipient['first_name'] . " " . $recipient['last_name'] . " successful!";

            $account_stmt->execute([$user_id]);
            $accounts = $account_stmt->fetchAll();
            foreach ($accounts as $available_account) {
                if ((int) $available_account['account_id'] === $selected_account_id) {
                    $sender = $available_account;
                    break;
                }
            }
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $exception->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <title>Transfer Funds | PASCCO</title>
    <style>
        html, body { margin: 0 !important; padding: 0 !important; overflow-x: hidden; }
        :root {
            --navy: #071d49;
            --blue: #1456a0;
            --blue-2: #2b74c8;
            --gold: #e7b84b;
            --ink: #17304f;
            --muted: #718096;
            --line: #dbe5f0;
            --surface: #ffffff;
            --bg: #f4f7fb;
            --soft: #eef4fb;
            --success-bg: #eaf8f0;
            --success: #176b3a;
            --danger-bg: #fff0f0;
            --danger: #a73535;
        }
        body {
            background: linear-gradient(180deg, #edf4fb 0, #f7f9fc 420px, var(--bg) 100%);
            color: var(--ink);
            font-family: Arial, Helvetica, sans-serif;
        }
        .transfer-page {
            max-width: 1180px;
            margin: 0 auto;
            padding: 34px 22px 72px;
        }
        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--blue);
            font-size: .76rem;
            font-weight: 800;
            letter-spacing: .16em;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .eyebrow::before {
            content: '';
            width: 28px;
            height: 3px;
            border-radius: 999px;
            background: var(--gold);
        }
        .hero {
            display: flex;
            justify-content: space-between;
            align-items: end;
            gap: 24px;
            margin-bottom: 24px;
        }
        .hero h1 {
            margin: 0;
            color: var(--navy);
            font-size: clamp(2rem, 4vw, 3rem);
            line-height: 1.05;
        }
        .hero p {
            max-width: 720px;
            margin: 12px 0 0;
            color: #5e7088;
            line-height: 1.65;
            font-size: 1rem;
        }
        .layout {
            display: grid;
            grid-template-columns: minmax(0, 1.45fr) minmax(300px, .8fr);
            gap: 22px;
            align-items: start;
        }
        .card {
            background: var(--surface);
            border: 1px solid rgba(7,29,73,.07);
            border-radius: 22px;
            box-shadow: 0 16px 38px rgba(7,29,73,.08);
        }
        .form-card { overflow: hidden; }
        .card-head {
            padding: 24px 26px 18px;
            border-bottom: 1px solid var(--line);
        }
        .card-head h2 { margin: 0; color: var(--navy); font-size: 1.35rem; }
        .card-head p { margin: 7px 0 0; color: var(--muted); font-size: .92rem; line-height: 1.5; }
        .form-body { padding: 24px 26px 28px; }
        .balance-card {
            position: relative;
            overflow: hidden;
            padding: 24px;
            color: white;
            background: linear-gradient(135deg, var(--navy), var(--blue));
        }
        .balance-card::after {
            content: '';
            position: absolute;
            width: 170px;
            height: 170px;
            right: -60px;
            top: -65px;
            border: 1px solid rgba(255,255,255,.15);
            border-radius: 50%;
            box-shadow: 0 0 0 28px rgba(255,255,255,.035), 0 0 0 58px rgba(255,255,255,.025);
        }
        .balance-label { font-size: .77rem; opacity: .78; text-transform: uppercase; letter-spacing: .12em; font-weight: 800; }
        .balance-amount { margin-top: 8px; font-size: 2rem; font-weight: 800; letter-spacing: -.02em; }
        .balance-meta { margin-top: 11px; font-size: .84rem; opacity: .86; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .field { margin-bottom: 18px; }
        .field label {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 8px;
            color: var(--navy);
            font-size: .9rem;
            font-weight: 800;
        }
        .field-note { color: #8392a6; font-size: .76rem; font-weight: 500; }
        .field select, .field input {
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #cdd9e7;
            border-radius: 12px;
            background: #fff;
            color: var(--ink);
            font: inherit;
            font-size: 16px;
            min-height: 48px;
            padding: 12px 14px;
            outline: none;
            transition: border-color .18s ease, box-shadow .18s ease, transform .18s ease;
        }
        .field select:focus, .field input:focus {
            border-color: var(--blue-2);
            box-shadow: 0 0 0 4px rgba(20,86,160,.10);
        }
        .field input::placeholder { color: #9aa9ba; }
        .amount-wrap { position: relative; }
        .peso {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--navy);
            font-weight: 800;
            pointer-events: none;
        }
        .amount-input { padding-left: 34px !important; font-size: 1.08rem !important; font-weight: 700; }
        .description-help {
            margin-top: 9px;
            padding: 10px 12px;
            border-radius: 10px;
            background: var(--soft);
            color: #687a91;
            font-size: .81rem;
            line-height: 1.45;
        }
        .msg { margin-bottom: 18px; padding: 13px 15px; border-radius: 12px; font-size: .9rem; line-height: 1.5; font-weight: 700; }
        .msg.success { background: var(--success-bg); color: var(--success); border: 1px solid #ccebd9; }
        .msg.danger { background: var(--danger-bg); color: var(--danger); border: 1px solid #f3d1d1; }
        .submit-btn {
            width: 100%;
            border: 0;
            border-radius: 12px;
            min-height: 52px;
            padding: 14px 18px;
            background: linear-gradient(135deg, var(--blue), var(--blue-2));
            color: #fff;
            font: inherit;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 10px 22px rgba(20,86,160,.18);
            transition: transform .18s ease, box-shadow .18s ease;
        }
        .submit-btn:hover { transform: translateY(-1px); box-shadow: 0 14px 25px rgba(20,86,160,.22); }
        .aside-stack { display: grid; gap: 18px; }
        .aside-card { padding: 22px; }
        .aside-card h3 { margin: 0; color: var(--navy); font-size: 1.08rem; }
        .steps { margin: 16px 0 0; padding: 0; list-style: none; display: grid; gap: 13px; }
        .step { display: grid; grid-template-columns: 30px 1fr; gap: 10px; align-items: start; }
        .step-no { width: 30px; height: 30px; border-radius: 10px; display: grid; place-items: center; background: #edf4fd; color: var(--blue); font-weight: 800; font-size: .8rem; }
        .step strong { display: block; color: var(--navy); font-size: .88rem; }
        .step span { display: block; margin-top: 3px; color: var(--muted); font-size: .8rem; line-height: 1.45; }
        .mini-list { margin: 14px 0 0; display: grid; gap: 10px; }
        .mini-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 11px 0; border-top: 1px solid var(--line); }
        .mini-row:first-child { border-top: 0; padding-top: 0; }
        .mini-name { color: #52667f; font-size: .8rem; }
        .mini-value { color: var(--navy); font-size: .84rem; font-weight: 800; text-align: right; }
        .recent-transfers {
            margin-top: 14px;
            padding: 14px;
            border: 1px solid var(--line);
            border-radius: 14px;
            background: #f8fbff;
        }
        .recent-transfers-head {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            align-items: baseline;
            margin-bottom: 10px;
        }
        .recent-transfers-head strong { color: var(--navy); font-size: .86rem; }
        .recent-transfers-head span { color: var(--muted); font-size: .74rem; }
        .recent-transfer-list { display: grid; gap: 8px; }
        .recent-transfer-item {
            width: 100%;
            border: 1px solid #dbe5f0;
            border-radius: 11px;
            background: #fff;
            padding: 11px 12px;
            display: flex;
            justify-content: space-between;
            gap: 14px;
            align-items: center;
            text-align: left;
            cursor: pointer;
            font: inherit;
            transition: border-color .18s ease, background .18s ease, transform .18s ease;
        }
        .recent-transfer-item:hover {
            border-color: #9dbce0;
            background: #f3f8fe;
            transform: translateY(-1px);
        }
        .recent-transfer-person, .recent-transfer-meta { display: grid; gap: 3px; }
        .recent-transfer-person strong, .recent-transfer-meta strong { color: var(--navy); font-size: .82rem; }
        .recent-transfer-person small, .recent-transfer-meta small { color: var(--muted); font-size: .73rem; }
        .recent-transfer-meta { text-align: right; flex: 0 0 auto; }
        .empty-state { padding: 36px 24px; text-align: center; }
        .empty-state h2 { margin: 0; color: var(--navy); font-size: 1.35rem; }
        .empty-state p { margin: 10px auto 0; color: var(--muted); line-height: 1.55; max-width: 560px; }
        .small-note { margin-top: 12px; color: #8290a2; font-size: .77rem; line-height: 1.45; }
        @media (max-width: 900px) {
            .hero { align-items: start; flex-direction: column; }
            .layout { grid-template-columns: 1fr; }
        }
        @media (max-width: 640px) {
            .transfer-page { padding: 24px 14px 52px; }
            .grid-2 { grid-template-columns: 1fr; gap: 0; }
            .card-head, .form-body, .aside-card, .balance-card { padding-left: 18px; padding-right: 18px; }
            .hero h1 { font-size: 2rem; }
        }
    </style>
    <link rel="stylesheet" href="member-panels.css?v=2">
</head>
<body>
<?php pascco_member_header('Transfer Funds'); ?>

<main class="transfer-page member-content">
    <div class="hero">
        <div>
            <div class="eyebrow">Member service</div>
            <h1>Transfer Funds</h1>
            <p>Move money securely from one of your active savings accounts to another PASCCO member account.</p>
        </div>
    </div>

    <?php if (!$accounts): ?>
        <section class="card empty-state">
            <h2>No active savings account available</h2>
            <p>You need at least one active savings account before you can send funds. Open a savings account first, then return here to make a transfer.</p>
        </section>
    <?php else: ?>
        <div class="layout">
            <section class="card form-card">
                <div class="card-head">
                    <h2>Send money</h2>
                    <p>Choose the account to debit, enter the recipient's PASCCO account number, then enter the amount and transfer purpose.</p>
                </div>
                <div class="form-body">
                    <?php if ($message): ?><div class="msg success"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
                    <?php if ($error): ?><div class="msg danger"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>

                    <form method="POST" action="transfer.php">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

                        <div class="field">
                            <label for="account-id">Send from <span class="field-note">Your active account</span></label>
                            <select id="account-id" name="account_id" required>
                                <?php foreach ($accounts as $available_account): ?>
                                    <option value="<?php echo (int) $available_account['account_id']; ?>" <?php echo (int) $available_account['account_id'] === $selected_account_id ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($available_account['account_type'] . ' · ' . $available_account['account_number'] . ' · ₱' . number_format($available_account['balance'], 2), ENT_QUOTES, 'UTF-8'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="field">
                            <label for="recipient-account">Send to <span class="field-note">PASCCO account number</span></label>
                            <input
                                id="recipient-account"
                                type="text"
                                name="recipient_account"
                                value="<?php echo htmlspecialchars($selected_recipient_account, ENT_QUOTES, 'UTF-8'); ?>"
                                placeholder="Enter recipient account number"
                                autocomplete="off"
                                required
                            >
                            <div class="small-note">Enter the recipient's PASCCO account number exactly as provided by the member.</div>

                            <?php if ($recent_recipients): ?>
                                <div class="recent-transfers">
                                    <div class="recent-transfers-head">
                                        <strong>Recent transfers</strong>
                                        <span>Click a recipient to use the account again</span>
                                    </div>
                                    <div class="recent-transfer-list">
                                        <?php foreach ($recent_recipients as $recent): ?>
                                            <button
                                                class="recent-transfer-item"
                                                type="button"
                                                data-account="<?php echo htmlspecialchars($recent['account_number'], ENT_QUOTES, 'UTF-8'); ?>"
                                            >
                                                <span class="recent-transfer-person">
                                                    <strong><?php echo htmlspecialchars($recent['first_name'] . ' ' . $recent['last_name'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                                    <small><?php echo htmlspecialchars($recent['account_type'] . ' · ' . $recent['account_number'], ENT_QUOTES, 'UTF-8'); ?></small>
                                                </span>
                                                <span class="recent-transfer-meta">
                                                    <strong>₱<?php echo number_format((float) $recent['amount'], 2); ?></strong>
                                                    <small><?php echo !empty($recent['transaction_date']) ? date('M j, Y', (int) $recent['transaction_date']) : 'Recent'; ?></small>
                                                </span>
                                            </button>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="grid-2">
                            <div class="field">
                                <label for="amount">Amount <span class="field-note">PHP</span></label>
                                <div class="amount-wrap">
                                    <span class="peso">₱</span>
                                    <input id="amount" class="amount-input" type="number" min="0.01" step="0.01" name="amount" placeholder="0.00" required>
                                </div>
                            </div>

                            <div class="field">
                                <label for="description">Transfer purpose</label>
                                <select id="description" name="description" required>
                                    <option value="">Select a purpose</option>
                                    <?php foreach ($description_options as $option): ?>
                                        <option value="<?php echo htmlspecialchars($option, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($option, ENT_QUOTES, 'UTF-8'); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="field" id="custom-description-wrap" style="display:none;">
                            <label for="custom-description">Other description</label>
                            <input id="custom-description" type="text" name="custom_description" placeholder="Enter the purpose of this transfer">
                        </div>

                        <div class="description-help">Transfers are posted immediately after validation. Make sure the recipient account and amount are correct before sending.</div>
                        <button class="submit-btn" type="submit">Send Money</button>
                    </form>
                </div>
            </section>

            <aside class="aside-stack">
                <?php if ($sender): ?>
                    <section class="card balance-card">
                        <div class="balance-label">Available balance</div>
                        <div class="balance-amount">₱<?php echo number_format($sender['balance'], 2); ?></div>
                        <div class="balance-meta"><?php echo htmlspecialchars($sender['account_type'] . ' · ' . $sender['account_number'], ENT_QUOTES, 'UTF-8'); ?></div>
                    </section>
                <?php endif; ?>

                <section class="card aside-card">
                    <h3>How it works</h3>
                    <div class="steps">
                        <div class="step"><div class="step-no">1</div><div><strong>Choose your account</strong><span>Select the active savings account that will send the money.</span></div></div>
                        <div class="step"><div class="step-no">2</div><div><strong>Enter the recipient</strong><span>Type the recipient's PASCCO account number or choose one from your recent transfers.</span></div></div>
                        <div class="step"><div class="step-no">3</div><div><strong>Enter the amount</strong><span>Transfers are checked against your available balance before posting.</span></div></div>
                        <div class="step"><div class="step-no">4</div><div><strong>Send securely</strong><span>The transfer is recorded on both accounts with a unique reference number.</span></div></div>
                    </div>
                </section>

                <section class="card aside-card">
                    <h3>Transfer reminders</h3>
                    <div class="mini-list">
                        <div class="mini-row"><span class="mini-name">Minimum transfer</span><span class="mini-value">₱0.01</span></div>
                        <div class="mini-row"><span class="mini-name">Recipient</span><span class="mini-value">Active member account</span></div>
                        <div class="mini-row"><span class="mini-name">Posting</span><span class="mini-value">Immediate</span></div>
                    </div>
                </section>
            </aside>
        </div>
    <?php endif; ?>
</main>

<script>
(function () {
    const description = document.getElementById('description');
    const customWrap = document.getElementById('custom-description-wrap');
    const customInput = document.getElementById('custom-description');
    if (!description || !customWrap || !customInput) return;

    function syncCustomDescription() {
        const isOther = description.value === 'Other';
        customWrap.style.display = isOther ? 'block' : 'none';
        customInput.required = isOther;
        if (!isOther) customInput.value = '';
    }

    description.addEventListener('change', syncCustomDescription);
    syncCustomDescription();

    const recipientInput = document.getElementById('recipient-account');
    document.querySelectorAll('.recent-transfer-item[data-account]').forEach(function (button) {
        button.addEventListener('click', function () {
            if (!recipientInput) return;
            recipientInput.value = button.getAttribute('data-account') || '';
            recipientInput.focus();
        });
    });
})();
</script>

<?php pascco_global_footer(); ?>
</body>
</html>
