<?php
require_once 'db.php';
require_once 'pascco_shell.php';
require_once 'mail_config.php';

if (
    empty($_SESSION['member_otp_user_id']) ||
    time() - (int) ($_SESSION['member_otp_started_at'] ?? 0) > 600
) {
    unset(
        $_SESSION['member_otp_user_id'],
        $_SESSION['member_otp_started_at'],
        $_SESSION['member_otp_last_sent'],
        $_SESSION['member_otp_password_version']
    );
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['member_otp_user_id'];
$stmt = $pdo->prepare(
    "SELECT id, username, email, password, role, status, otp_code, otp_expires_at, otp_attempts
     FROM users
     WHERE id = ? AND role = 'member'
     LIMIT 1"
);
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (
    !$user ||
    $user['status'] !== 'active' ||
    !hash_equals(
        $_SESSION['member_otp_password_version'] ?? '',
        hash('sha256', $user['password'])
    )
) {
    $_SESSION = [];
    session_regenerate_id(true);
    header('Location: login.php');
    exit;
}

$error = '';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? 'verify');

    if ($action === 'resend') {
        $lastSent = (int) ($_SESSION['member_otp_last_sent'] ?? 0);

        if (time() - $lastSent < 60) {
            $remaining = 60 - (time() - $lastSent);
            $error = 'Please wait ' . $remaining . ' seconds before requesting another code.';
        } else {
            $userAllowed = pascco_take_attempt($pdo, 'member-otp-resend-user', (string) $userId, 5);
            $ipAllowed = pascco_take_attempt(
                $pdo,
                'member-otp-resend-ip',
                $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                20
            );

            if (!$userAllowed || !$ipAllowed) {
                http_response_code(429);
                header('Retry-After: 900');
                $error = 'Too many code requests. Please wait 15 minutes and sign in again.';
            } else {
                $email = trim((string) ($user['email'] ?? ''));

                if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error = 'No valid email address is registered for this member account.';
                } else {
                    $otp = (string) random_int(100000, 999999);
                    $otpHash = password_hash($otp, PASSWORD_DEFAULT);

                    try {
                        $update = $pdo->prepare(
                            "UPDATE users
                             SET otp_code = ?,
                                 otp_expires_at = DATE_ADD(NOW(), INTERVAL 5 MINUTE),
                                 otp_attempts = 0
                             WHERE id = ? AND role = 'member' AND status = 'active'"
                        );
                        $update->execute([$otpHash, $userId]);

                        if (!sendMemberLoginOtpEmail($email, (string) $user['username'], $otp)) {
                            $clear = $pdo->prepare(
                                'UPDATE users SET otp_code = NULL, otp_expires_at = NULL, otp_attempts = 0 WHERE id = ?'
                            );
                            $clear->execute([$userId]);
                            throw new RuntimeException('Email could not be sent.');
                        }

                        $_SESSION['member_otp_last_sent'] = time();
                        $_SESSION['member_otp_started_at'] = time();
                        $message = 'A new verification code was sent to your registered email address.';

                        record_audit(
                            $pdo,
                            $userId,
                            'member_otp_resent',
                            'Member requested a new email OTP.',
                            'success'
                        );

                        $stmt->execute([$userId]);
                        $user = $stmt->fetch();
                    } catch (Throwable $exception) {
                        error_log('PASCCO member OTP resend failed: ' . $exception->getMessage());
                        $error = 'A new code could not be sent. Please try again.';
                    }
                }
            }
        }
    } else {
        $otp = trim((string) ($_POST['otp'] ?? ''));
        $userAllowed = pascco_take_attempt($pdo, 'member-otp-user', (string) $userId, 8);
        $ipAllowed = pascco_take_attempt(
            $pdo,
            'member-otp-ip',
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            30
        );

        if (!$userAllowed || !$ipAllowed) {
            http_response_code(429);
            header('Retry-After: 900');
            $error = 'Too many verification attempts. Please wait 15 minutes and sign in again.';
        } elseif (!preg_match('/^[0-9]{6}$/', $otp)) {
            $error = 'Enter the 6-digit verification code from your email.';
        } elseif ((int) $user['otp_attempts'] >= 5) {
            $error = 'Too many incorrect codes. Please request a new code.';
        } elseif (empty($user['otp_code']) || empty($user['otp_expires_at'])) {
            $error = 'No active verification code was found. Please request a new code.';
        } elseif (strtotime((string) $user['otp_expires_at']) < time()) {
            $error = 'This verification code has expired. Please request a new code.';
        } elseif (!password_verify($otp, (string) $user['otp_code'])) {
            $increment = $pdo->prepare(
                'UPDATE users SET otp_attempts = otp_attempts + 1 WHERE id = ?'
            );
            $increment->execute([$userId]);
            $user['otp_attempts'] = (int) $user['otp_attempts'] + 1;

            record_audit(
                $pdo,
                $userId,
                'member_otp_failed',
                'Incorrect member email OTP entered.',
                'failed'
            );

            if ((int) $user['otp_attempts'] >= 5) {
                $error = 'Too many incorrect codes. Please request a new code.';
            } else {
                $error = 'Invalid verification code. Please try again.';
            }
        } else {
            try {
                $pdo->beginTransaction();

                $lock = $pdo->prepare(
                    "SELECT username, password, role, status, otp_code, otp_expires_at
                     FROM users
                     WHERE id = ? FOR UPDATE"
                );
                $lock->execute([$userId]);
                $lockedUser = $lock->fetch();

                if (
                    !$lockedUser ||
                    $lockedUser['status'] !== 'active' ||
                    $lockedUser['role'] !== 'member' ||
                    !hash_equals(
                        $_SESSION['member_otp_password_version'] ?? '',
                        hash('sha256', $lockedUser['password'])
                    ) ||
                    empty($lockedUser['otp_code']) ||
                    strtotime((string) $lockedUser['otp_expires_at']) < time() ||
                    !password_verify($otp, (string) $lockedUser['otp_code'])
                ) {
                    throw new RuntimeException('Verification state changed.');
                }

                $clear = $pdo->prepare(
                    'UPDATE users SET otp_code = NULL, otp_expires_at = NULL, otp_attempts = 0 WHERE id = ?'
                );
                $clear->execute([$userId]);
                $pdo->commit();

                $_SESSION = [];
                session_regenerate_id(true);
                $_SESSION['user_id'] = $userId;
                $_SESSION['username'] = $lockedUser['username'];
                $_SESSION['role'] = 'member';
                $_SESSION['email_otp_verified'] = true;
                $_SESSION['credential_version'] = hash('sha256', $lockedUser['password']);
                $_SESSION['authenticated_at'] = $_SESSION['last_activity'] = time();
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                record_audit(
                    $pdo,
                    $userId,
                    'login',
                    'Successful member login with email OTP verification.',
                    'success'
                );

                header('Location: dashboard.php');
                exit;
            } catch (Throwable $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log('PASCCO member OTP verification failed internally: ' . $exception->getMessage());
                $error = 'Verification could not be completed. Please sign in again.';
            }
        }
    }
}

$email = (string) ($user['email'] ?? '');
$maskedEmail = $email;
if (strpos($email, '@') !== false) {
    [$local, $domain] = explode('@', $email, 2);
    $shown = mb_substr($local, 0, min(2, mb_strlen($local)));
    $maskedEmail = $shown . str_repeat('*', max(2, mb_strlen($local) - mb_strlen($shown))) . '@' . $domain;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <title>Email Verification | PASCCO</title>
    <style>
        :root{
            --navy:#0b2c6a;
            --blue:#1f5fae;
            --bg:#f4f7fb;
            --surface:#ffffff;
            --line:#d7e0ec;
            --text:#1f2a44;
            --muted:#627289;
            --danger:#9b2c2c;
            --success:#25613c;
        }
        *{box-sizing:border-box}
        html,body{margin:0!important;padding:0!important}
        body{background:linear-gradient(180deg,#eef3f9 0,#f7f9fc 100%);color:var(--text);font-family:Poppins,Arial,sans-serif}
        .verify-wrap{width:min(100% - 36px,640px);margin:54px auto 74px}
        .verify-card{background:var(--surface);border:1px solid var(--line);border-radius:12px;box-shadow:0 12px 30px rgba(18,42,84,.08);overflow:hidden}
        .verify-head{background:var(--navy);color:#fff;padding:26px 30px}
        .eyebrow{margin:0 0 8px;color:#dbe8fb;font-size:.75rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase}
        h1{margin:0;color:#fff;font-size:2rem;line-height:1.15}
        .verify-body{padding:30px}
        .intro{margin:0;color:var(--muted);line-height:1.65}
        .email-box{margin:20px 0 24px;padding:14px 16px;background:#f5f8fc;border:1px solid var(--line);border-radius:8px;font-weight:700;color:var(--navy)}
        .notice{padding:12px 14px;margin:0 0 18px;border-radius:8px;font-weight:700;font-size:.88rem}
        .notice.error{background:#fff1f1;color:var(--danger);border:1px solid #efcccc}
        .notice.success{background:#edf7f0;color:var(--success);border:1px solid #cfe4d5}
        label{display:block;margin:0 0 8px;color:var(--text);font-weight:800}
        .otp-input{width:100%;height:58px;padding:12px 16px;border:1px solid #c5d1df;border-radius:8px;background:#fff;color:var(--navy);font:inherit;font-size:1.45rem;font-weight:700;letter-spacing:.32em;text-align:center;outline:none;transition:.18s ease}
        .otp-input:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(31,95,174,.11)}
        .primary{width:100%;margin-top:16px;border:0;border-radius:8px;padding:14px 18px;background:var(--blue);color:#fff;font:inherit;font-weight:800;cursor:pointer}
        .primary:hover{background:#194f91}
        .secondary-form{margin-top:14px;text-align:center}
        .secondary{border:0;background:none;color:var(--blue);font:inherit;font-weight:800;cursor:pointer;text-decoration:none}
        .secondary:hover{text-decoration:underline}
        .security-note{margin-top:22px;padding-top:18px;border-top:1px solid var(--line);color:var(--muted);font-size:.82rem;line-height:1.55}
        @media(max-width:640px){.verify-wrap{width:min(100% - 24px,640px);margin:32px auto 54px}.verify-head{padding:22px}.verify-body{padding:22px}h1{font-size:1.7rem}}
    </style>
</head>
<body>
<?php pascco_public_header('Back to login', 'login.php'); ?>
<main class="verify-wrap">
    <section class="verify-card">
        <div class="verify-head">
            <div class="eyebrow">Member verification</div>
            <h1>Check your email</h1>
        </div>

        <div class="verify-body">
            <p class="intro">We sent a 6-digit verification code to the email registered with your PASCCO member account.</p>
            <div class="email-box"><?php echo htmlspecialchars($maskedEmail, ENT_QUOTES, 'UTF-8'); ?></div>

            <?php if ($error): ?>
                <div class="notice error" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
            <?php if ($message): ?>
                <div class="notice success"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="action" value="verify">
                <label for="otp">Verification Code</label>
                <input class="otp-input" id="otp" name="otp" type="text" maxlength="6" pattern="[0-9]{6}" inputmode="numeric" autocomplete="one-time-code" placeholder="000000" required autofocus>
                <button class="primary" type="submit">Verify &amp; Continue</button>
            </form>

            <form method="POST" class="secondary-form">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="action" value="resend">
                <button class="secondary" type="submit">Resend verification code</button>
            </form>

            <div class="security-note">The code expires after 5 minutes. After 5 incorrect attempts, request a new code before trying again.</div>
        </div>
    </section>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
