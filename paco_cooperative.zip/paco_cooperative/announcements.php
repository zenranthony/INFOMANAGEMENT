<?php
require_once 'db.php';
require_once 'pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') {
    header('Location: login.php');
    exit;
}

$stmt = $pdo->query("SELECT title, body, image_path, published_at FROM announcements WHERE status = 'published' ORDER BY published_at DESC, id DESC");
$announcements = $stmt->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <title>Announcements | PASCCO</title>
    <style>
        :root {
            --navy: #071d49;
            --blue: #1456a0;
            --blue-deep: #0d3f79;
            --gold: #f4c542;
            --gold-soft: #fff7d8;
            --ink: #182a45;
            --muted: #65748a;
            --line: #dfe6f1;
            --surface: #ffffff;
            --page: #f4f7fb;
            --shadow: 0 16px 42px rgba(7, 29, 73, .09);
        }

        html,
        body {
            margin: 0 !important;
            padding: 0 !important;
            min-height: 100%;
            overflow-x: hidden;
        }

        body {
            background:
                radial-gradient(circle at 12% 0%, rgba(20, 86, 160, .08), transparent 28%),
                radial-gradient(circle at 88% 8%, rgba(244, 197, 66, .10), transparent 22%),
                var(--page);
            color: var(--ink);
            font-family: Georgia, 'Times New Roman', serif;
        }

        .announcements-page {
            width: min(1180px, calc(100% - 36px));
            margin: 0 auto;
            padding: 38px 0 72px;
        }

        .hero {
            position: relative;
            overflow: hidden;
            border-radius: 24px;
            background: linear-gradient(135deg, var(--navy) 0%, var(--blue-deep) 58%, var(--blue) 100%);
            box-shadow: var(--shadow);
            color: white;
            padding: clamp(28px, 5vw, 52px);
            margin-bottom: 28px;
        }

        .hero::before,
        .hero::after {
            content: '';
            position: absolute;
            border-radius: 999px;
            pointer-events: none;
        }

        .hero::before {
            width: 260px;
            height: 260px;
            right: -100px;
            top: -115px;
            background: rgba(244, 197, 66, .14);
        }

        .hero::after {
            width: 180px;
            height: 180px;
            right: 110px;
            bottom: -115px;
            background: rgba(255, 255, 255, .06);
        }

        .hero-inner {
            position: relative;
            z-index: 1;
            max-width: 760px;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #f8d974;
            font-size: .78rem;
            font-weight: 700;
            letter-spacing: .16em;
            text-transform: uppercase;
        }

        .eyebrow::before {
            content: '';
            width: 28px;
            height: 2px;
            background: var(--gold);
        }

        .hero h1 {
            margin: 12px 0 12px;
            color: white;
            font-size: clamp(2.2rem, 5vw, 4rem);
            line-height: 1.02;
            letter-spacing: -.035em;
        }

        .hero p {
            margin: 0;
            max-width: 680px;
            color: rgba(255, 255, 255, .84);
            font-size: 1.04rem;
            line-height: 1.75;
        }

        .section-head {
            display: flex;
            align-items: end;
            justify-content: space-between;
            gap: 18px;
            margin: 0 4px 18px;
        }

        .section-head h2 {
            margin: 0;
            color: var(--navy);
            font-size: clamp(1.35rem, 2.4vw, 1.8rem);
        }

        .section-head p {
            margin: 0;
            color: var(--muted);
            font-size: .92rem;
            text-align: right;
        }

        .announcement-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 22px;
        }

        .announcement-card {
            display: flex;
            flex-direction: column;
            min-width: 0;
            overflow: hidden;
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 20px;
            box-shadow: 0 12px 30px rgba(7, 29, 73, .07);
            transition: transform .2s ease, box-shadow .2s ease, border-color .2s ease;
        }

        .announcement-card:hover {
            transform: translateY(-3px);
            border-color: #cad7e7;
            box-shadow: 0 18px 38px rgba(7, 29, 73, .11);
        }

        .announcement-media {
            position: relative;
            background: linear-gradient(135deg, #eaf0f8, #dce7f4);
            aspect-ratio: 16 / 8.5;
            overflow: hidden;
        }

        .announcement-media img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .announcement-media.placeholder {
            display: grid;
            place-items: center;
            color: var(--blue);
            font-size: .82rem;
            font-weight: 700;
            letter-spacing: .1em;
            text-transform: uppercase;
        }

        .announcement-media.placeholder span {
            width: 58px;
            height: 58px;
            display: grid;
            place-items: center;
            margin-bottom: 8px;
            border-radius: 16px;
            background: rgba(255, 255, 255, .84);
            box-shadow: 0 8px 20px rgba(7, 29, 73, .08);
            font-size: 1.35rem;
        }

        .announcement-content {
            display: flex;
            flex: 1;
            flex-direction: column;
            padding: 24px;
        }

        .announcement-date {
            display: inline-flex;
            align-self: flex-start;
            margin-bottom: 10px;
            padding: 6px 10px;
            border-radius: 999px;
            background: var(--gold-soft);
            color: var(--navy);
            font-size: .76rem;
            font-weight: 700;
            letter-spacing: .03em;
        }

        .announcement-content h3 {
            margin: 0 0 10px;
            color: var(--navy);
            font-size: clamp(1.35rem, 2.2vw, 1.65rem);
            line-height: 1.22;
        }

        .announcement-body {
            margin: 0;
            color: #43536a;
            line-height: 1.78;
            white-space: pre-line;
        }

        .announcement-footer {
            margin-top: 20px;
            padding-top: 14px;
            border-top: 1px solid #edf1f7;
            color: #8592a3;
            font-size: .78rem;
        }

        .empty-state {
            display: grid;
            place-items: center;
            min-height: 280px;
            padding: 32px;
            border: 1px dashed #c8d4e5;
            border-radius: 20px;
            background: rgba(255, 255, 255, .72);
            text-align: center;
        }

        .empty-icon {
            width: 68px;
            height: 68px;
            display: grid;
            place-items: center;
            margin: 0 auto 16px;
            border-radius: 20px;
            background: #e8eef7;
            color: var(--blue);
            font-size: 1.5rem;
        }

        .empty-state h2 {
            margin: 0 0 8px;
            color: var(--navy);
        }

        .empty-state p {
            margin: 0;
            max-width: 520px;
            color: var(--muted);
            line-height: 1.7;
        }

        @media (max-width: 820px) {
            .announcement-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 640px) {
            .announcements-page {
                width: min(100% - 24px, 1180px);
                padding: 24px 0 52px;
            }

            .hero {
                border-radius: 20px;
                padding: 26px 22px;
                margin-bottom: 24px;
            }

            .section-head {
                align-items: flex-start;
                flex-direction: column;
            }

            .section-head p {
                text-align: left;
            }

            .announcement-content {
                padding: 20px;
            }
        }
    </style>
    <link rel="stylesheet" href="member-panels.css?v=2">
</head>
<body>
<?php pascco_member_header('Announcements'); ?>

<main class="announcements-page member-content">
    <section class="hero" aria-labelledby="announcements-title">
        <div class="hero-inner">
            <div class="eyebrow">PASCCO community</div>
            <h1 id="announcements-title">Announcements</h1>
            <p>Stay connected with the latest cooperative news, service updates, activities, and important member information.</p>
        </div>
    </section>

    <div class="section-head">
        <div>
            <h2>Latest updates</h2>
        </div>
        <p><?php echo count($announcements); ?> published announcement<?php echo count($announcements) === 1 ? '' : 's'; ?></p>
    </div>

    <?php if ($announcements): ?>
        <section class="announcement-grid" aria-label="Community announcements">
            <?php foreach ($announcements as $announcement): ?>
                <article class="announcement-card">
                    <?php if (!empty($announcement['image_path'])): ?>
                        <div class="announcement-media">
                            <img
                                src="<?php echo htmlspecialchars($announcement['image_path'], ENT_QUOTES, 'UTF-8'); ?>"
                                alt="<?php echo htmlspecialchars($announcement['title'], ENT_QUOTES, 'UTF-8'); ?>"
                                loading="lazy"
                            >
                        </div>
                    <?php else: ?>
                        <div class="announcement-media placeholder" aria-hidden="true">
                            <div>
                                <span>✦</span>
                                PASCCO update
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="announcement-content">
                        <div class="announcement-date">
                            <?php echo htmlspecialchars(date('F j, Y', strtotime($announcement['published_at'])), ENT_QUOTES, 'UTF-8'); ?>
                        </div>
                        <h3><?php echo htmlspecialchars($announcement['title'], ENT_QUOTES, 'UTF-8'); ?></h3>
                        <p class="announcement-body"><?php echo htmlspecialchars($announcement['body'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <div class="announcement-footer">Published by PASCCO Cooperative</div>
                    </div>
                </article>
            <?php endforeach; ?>
        </section>
    <?php else: ?>
        <section class="empty-state" aria-live="polite">
            <div>
                <div class="empty-icon" aria-hidden="true">✦</div>
                <h2>No announcements yet</h2>
                <p>New PASCCO community updates will appear here as soon as they are published.</p>
            </div>
        </section>
    <?php endif; ?>
</main>

<?php pascco_global_footer(); ?>
</body>
</html>
