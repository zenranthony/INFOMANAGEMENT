<?php
require_once 'db.php';
require_once 'pascco_shell.php';

$error = '';
$success = '';
$token = trim($_GET['token'] ?? $_POST['token'] ?? '');
$tokenRecord = null;

function loadResetToken(PDO $pdo, string $token): ?array
{
    if ($token === '' || !preg_match('/^[a-f0-9]{64}$/i', $token)) {
        return null;
    }

    $tokenHash = hash('sha256', $token);
    $stmt = $pdo->prepare(
        "SELECT prt.id, prt.user_id, prt.expires_at, prt.used_at,
                u.username, u.email, u.status, u.role
         FROM password_reset_tokens prt
         INNER JOIN users u ON u.id = prt.user_id
         WHERE prt.token_hash = ?
         LIMIT 1"
    );
    $stmt->execute([$tokenHash]);
    $row = $stmt->fetch();

    if (!$row) {
        return null;
    }

    if (!empty($row['used_at'])) {
        return null;
    }

    if (strtotime((string) $row['expires_at']) < time()) {
        return null;
    }

    if (($row['role'] ?? '') !== 'member' || ($row['status'] ?? '') !== 'active') {
        return null;
    }

    return $row;
}

if ($token === '') {
    $error = 'This password reset link is invalid.';
} else {
    try {
        $tokenRecord = loadResetToken($pdo, $token);
        if (!$tokenRecord) {
            $error = 'This password reset link is invalid, expired, or has already been used.';
        }
    } catch (Throwable $exception) {
        error_log('Password reset token lookup error: ' . $exception->getMessage());
        $error = 'Unable to verify this password reset link.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    verify_csrf();

    $password = (string) ($_POST['password'] ?? '');
    $confirmPassword = (string) ($_POST['confirm_password'] ?? '');

    if (strlen($password) < 8) {
        $error = 'Your new password must contain at least 8 characters.';
    } elseif ($password !== $confirmPassword) {
        $error = 'The passwords do not match.';
    } else {
        try {
            $pdo->beginTransaction();

            $tokenHash = hash('sha256', $token);
            $lock = $pdo->prepare(
                "SELECT prt.id, prt.user_id, prt.expires_at, prt.used_at,
                        u.status, u.role
                 FROM password_reset_tokens prt
                 INNER JOIN users u ON u.id = prt.user_id
                 WHERE prt.token_hash = ?
                 LIMIT 1
                 FOR UPDATE"
            );
            $lock->execute([$tokenHash]);
            $current = $lock->fetch();

            if (
                !$current ||
                !empty($current['used_at']) ||
                strtotime((string) $current['expires_at']) < time() ||
                ($current['role'] ?? '') !== 'member' ||
                ($current['status'] ?? '') !== 'active'
            ) {
                throw new RuntimeException('The password reset link is no longer valid.');
            }

            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            $updateUser = $pdo->prepare(
                "UPDATE users
                 SET password = ?,
                     otp_code = NULL,
                     otp_expires_at = NULL,
                     otp_attempts = 0
                 WHERE id = ? AND role = 'member' AND status = 'active'"
            );
            $updateUser->execute([$passwordHash, (int) $current['user_id']]);

            if ($updateUser->rowCount() !== 1) {
                throw new RuntimeException('Unable to update the member password.');
            }

            // Mark every outstanding reset token for this user as used.
            $markUsed = $pdo->prepare(
                'UPDATE password_reset_tokens SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL'
            );
            $markUsed->execute([(int) $current['user_id']]);

            $pdo->commit();

            // Password-version session checks in db.php will invalidate any older authenticated session.
            $success = 'Your password has been changed successfully. You can now sign in using your new password.';
            $tokenRecord = null;

        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Password reset update error: ' . $exception->getMessage());
            $error = $exception instanceof RuntimeException
                ? $exception->getMessage()
                : 'Unable to reset your password. Please request a new reset link.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <title>Reset Password | PASCCO</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: #f4f7fb;
            color: #182a45;
            font-family: 'Poppins', Arial, Helvetica, sans-serif;
        }
        .reset-page {
            width: min(100% - 32px, 520px);
            margin: 56px auto 76px;
        }
        .reset-card {
            padding: 30px;
            border: 1px solid #dbe5f0;
            border-radius: 18px;
            background: #fff;
            box-shadow: 0 16px 38px rgba(7,29,73,.08);
        }
        .reset-icon {
            display: grid;
            place-items: center;
            width: 46px;
            height: 46px;
            margin-bottom: 16px;
            border-radius: 13px;
            background: #eef4fb;
            color: #1456a0;
            font-size: 24px;
        }
        h1 { margin: 0 0 8px; color: #071d49; font-size: 1.8rem; }
        .intro { margin: 0 0 24px; color: #64748b; line-height: 1.65; }
        .field { margin-top: 15px; }
        label { display: block; margin-bottom: 7px; color: #071d49; font-weight: 700; }
        input {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #b8c8d9;
            border-radius: 10px;
            font: inherit;
        }
        input:focus {
            outline: none;
            border-color: #1456a0;
            box-shadow: 0 0 0 3px rgba(20,86,160,.12);
        }
        button, .login-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            min-height: 48px;
            margin-top: 20px;
            padding: 12px 18px;
            border: 0;
            border-radius: 10px;
            background: #1456a0;
            color: #fff;
            font: inherit;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
        }
        button:hover, .login-link:hover { background: #0f4788; }
        .notice, .error {
            margin-bottom: 18px;
            padding: 13px 15px;
            border-radius: 10px;
            font-size: .88rem;
            line-height: 1.55;
        }
        .notice { border: 1px solid #b9e4ca; background: #eaf8f0; color: #176b3a; }
        .error { border: 1px solid #efc3c3; background: #fff0f0; color: #a73535; }
        .password-note { margin: 8px 0 0; color: #7a899c; font-size: .78rem; }
    </style>
</head>
<body>
<?php pascco_public_header('Login', 'login.php'); ?>

<main class="reset-page">
    <section class="reset-card">
        <div class="reset-icon"><i class="bx bx-key" aria-hidden="true"></i></div>
        <h1>Reset your password</h1>

        <?php if ($success): ?>
            <div class="notice" role="status"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></div>
            <a class="login-link" href="login.php">Go to Sign In</a>

        <?php elseif ($error && !$tokenRecord): ?>
            <div class="error" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
            <a class="login-link" href="forgot_password.php">Request a New Reset Link</a>

        <?php else: ?>
            <p class="intro">Create a new password for your PASCCO member account.</p>

            <?php if ($error): ?>
                <div class="error" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <form method="POST" action="reset_password.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">

                <div class="field">
                    <label for="password">New Password</label>
                    <input id="password" type="password" name="password" autocomplete="new-password" minlength="8" required>
                    <p class="password-note">Use at least 8 characters.</p>
                </div>

                <div class="field">
                    <label for="confirm-password">Confirm New Password</label>
                    <input id="confirm-password" type="password" name="confirm_password" autocomplete="new-password" minlength="8" required>
                </div>

                <button type="submit" data-no-animate="true">Save New Password</button>
            </form>
        <?php endif; ?>
    </section>
</main>

<?php pascco_global_footer(); ?>
</body>
</html>
