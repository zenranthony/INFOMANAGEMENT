<?php
require_once 'db.php';
require_once 'pascco_shell.php';
require_once 'mail_config.php';

$notice = '';
$error = '';
$email = trim($_POST['email'] ?? '');

// The password_reset_tokens table is part of the database schema.
// Do not create or alter database tables from this public page.


if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    verify_csrf();

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Always show a generic message so the page does not reveal which emails are registered.
        $notice = 'If that email is registered, password reset instructions will be sent shortly.';

        try {
            $stmt = $pdo->prepare(
                "SELECT id, username, email, status
                 FROM users
                 WHERE email = ? AND role = 'member'
                 LIMIT 1"
            );
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && ($user['status'] ?? '') === 'active') {
                // Remove previous unused reset links for this account.
                $deleteOld = $pdo->prepare(
                    'DELETE FROM password_reset_tokens WHERE user_id = ? AND used_at IS NULL'
                );
                $deleteOld->execute([(int) $user['id']]);

                $token = bin2hex(random_bytes(32));
                $tokenHash = hash('sha256', $token);

                $insert = $pdo->prepare(
                    "INSERT INTO password_reset_tokens (user_id, token_hash, expires_at)
                     VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 MINUTE))"
                );
                $insert->execute([(int) $user['id'], $tokenHash]);

                $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
                $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
                $folder = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\');
                $resetUrl = $scheme . '://' . $host . $folder . '/reset_password.php?token=' . urlencode($token);

                if (!sendPasswordResetEmail((string) $user['email'], (string) $user['username'], $resetUrl)) {
                    $deleteToken = $pdo->prepare('DELETE FROM password_reset_tokens WHERE token_hash = ?');
                    $deleteToken->execute([$tokenHash]);
                    $notice = '';
                    $error = 'Unable to send the password reset email. Please try again later.';
                }
            }
        } catch (Throwable $exception) {
            error_log('Password reset request error: ' . $exception->getMessage());
            $notice = '';
            $error = 'Unable to process the password reset request. Please try again later.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <title>Forgot Password | PASCCO</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: #f4f7fb;
            color: #182a45;
            font-family: 'Poppins', Arial, Helvetica, sans-serif;
        }
        .reset-page {
            width: min(100% - 32px, 520px);
            margin: 56px auto 76px;
        }
        .reset-card {
            padding: 30px;
            border: 1px solid #dbe5f0;
            border-radius: 18px;
            background: #fff;
            box-shadow: 0 16px 38px rgba(7,29,73,.08);
        }
        .reset-icon {
            display: grid;
            place-items: center;
            width: 46px;
            height: 46px;
            margin-bottom: 16px;
            border-radius: 13px;
            background: #eef4fb;
            color: #1456a0;
            font-size: 24px;
        }
        h1 { margin: 0 0 8px; color: #071d49; font-size: 1.8rem; }
        .intro { margin: 0 0 24px; color: #64748b; line-height: 1.65; }
        label { display: block; margin-bottom: 7px; color: #071d49; font-weight: 700; }
        input {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #b8c8d9;
            border-radius: 10px;
            font: inherit;
        }
        input:focus {
            outline: none;
            border-color: #1456a0;
            box-shadow: 0 0 0 3px rgba(20,86,160,.12);
        }
        button {
            width: 100%;
            margin-top: 18px;
            padding: 13px 18px;
            border: 0;
            border-radius: 10px;
            background: #1456a0;
            color: #fff;
            font: inherit;
            font-weight: 700;
            cursor: pointer;
        }
        button:hover { background: #0f4788; }
        .notice, .error {
            margin-bottom: 18px;
            padding: 13px 15px;
            border-radius: 10px;
            font-size: .88rem;
            line-height: 1.55;
        }
        .notice { border: 1px solid #b9e4ca; background: #eaf8f0; color: #176b3a; }
        .error { border: 1px solid #efc3c3; background: #fff0f0; color: #a73535; }
        .back-login { margin-top: 18px; text-align: center; font-size: .86rem; }
        .back-login a { color: #1456a0; font-weight: 700; text-decoration: none; }
    </style>
</head>
<body>
<?php pascco_public_header('Login', 'login.php'); ?>

<main class="reset-page">
    <section class="reset-card">
        <div class="reset-icon"><i class="bx bx-lock-open-alt" aria-hidden="true"></i></div>
        <h1>Forgot your password?</h1>
        <p class="intro">Enter the email address connected to your PASCCO member account. We will send a reset link that expires after 30 minutes.</p>

        <?php if ($notice): ?>
            <div class="notice" role="status"><?php echo htmlspecialchars($notice, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="error" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <form method="POST" action="forgot_password.php">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

            <label for="email">Email Address</label>
            <input
                id="email"
                type="email"
                name="email"
                value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
                autocomplete="email"
                placeholder="Enter your registered email"
                required
            >

            <button type="submit" data-no-animate="true">Send Reset Instructions</button>
        </form>

        <div class="back-login"><a href="login.php">Back to Sign In</a></div>
    </section>
</main>

<?php pascco_global_footer(); ?>
</body>
</html>
