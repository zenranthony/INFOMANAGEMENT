<?php
require_once 'pascco_layout.php';
pascco_header('About PASCCO', 'about');
?>
<style>
    .about-hero { background:linear-gradient(135deg,#071d49,#1456a0); color:#fff; border-radius:22px; padding:34px clamp(24px,5vw,48px); margin-bottom:28px; box-shadow:0 14px 34px rgba(7,29,73,.13); }
    .about-hero .eyebrow { color:#ffe7a1; }
    .about-hero h1 { color:#fff; margin-bottom:10px; }
    .about-hero .intro { color:rgba(255,255,255,.9); margin-bottom:0; }
    .about-grid { display:grid; gap:22px; grid-template-columns:repeat(3,minmax(0,1fr)); }
    .about-card { background:#fff; border:1px solid #d8e0ee; border-radius:20px; padding:26px; box-shadow:0 10px 28px rgba(7,29,73,.07); }
    .about-card h2 { color:#071d49; font-size:1.32rem; margin-bottom:14px; }
    .about-card p, .about-card li { line-height:1.72; }
    .about-card ol { padding-left:22px; margin-bottom:0; }
    .about-card p:last-child { margin-bottom:0; }
    .value-list p { padding:8px 0; margin:0; border-top:1px solid #edf1f7; }
    .value-list p:first-child { border-top:0; }
    .value-list strong { color:#1456a0; }
    .wide-card { grid-column:span 2; }
    .history-card { grid-column:span 1; }
    .section-label { margin:36px 0 16px; color:#1456a0; font-weight:bold; text-transform:uppercase; letter-spacing:.16em; font-size:.78rem; }
    @media(max-width:900px){ .about-grid{grid-template-columns:1fr;} .wide-card,.history-card{grid-column:span 1;} }
</style>
<main class="page-shell">
    <section class="about-hero">
        <div class="eyebrow">Our cooperative</div>
        <h1>Paco Savings &amp; Credit Cooperative</h1>
        <p class="intro">“Helping People Help Themselves”</p>
    </section>

    <div class="section-label">Purpose &amp; identity</div>
    <section class="about-grid">
        <article class="about-card">
            <h2>Mission</h2>
            <p>Iangat ang antas ng pamumuhay ng mga kasapi sa larangan ng pananalapi.</p>
            <p>Makapagturo ng kahalagahan ng pag-iimpok, pagiging masinop sa pananalapi, at pagiging matapat sa tungkulin bilang kasapi.</p>
            <p>Maagap na pagtugon sa piling pangangailangan ng pamayanan.</p>
        </article>
        <article class="about-card">
            <h2>Vision</h2>
            <p>Kooperatibang mapagmalasakit, Pag-unlad ng kasapi at pamayanan ang mithi.</p>
        </article>
        <article class="about-card">
            <h2>Core Values</h2>
            <div class="value-list">
                <p><strong>P</strong> - Participation</p><p><strong>A</strong> - Accountability</p><p><strong>S</strong> - Social Concern &amp; Responsibility</p><p><strong>C</strong> - Commitment</p><p><strong>C</strong> - Concern for the Environment</p><p><strong>O</strong> - Openness</p>
            </div>
        </article>
    </section>

    <div class="section-label">Our story &amp; principles</div>
    <section class="about-grid">
        <article class="about-card wide-card">
            <h2>Ano ang Kooperatiba?</h2>
            <p>Ang Kooperatiba ay isang malaya at rehistradong asosasyon ng mga taong may iisang mithiin. Kusang loob na magsamasama upang makamit ang kanilang pang-sosyal, pang-ekonomiya at pangkulturang pangangailangan at lunggati sa pamamagitan ng pantay na paglalagay sa kanilang napagkasunduang puhunan, pagtangkilik sa sariling produkto at serbisyo at pagtanggap ng patas na pananagutan at benepisyo sa kanilang pagsasagawa ng negosyo alinsunod sa pangkalahatang prinsipyo ng kooperatiba.</p>
        </article>
        <article class="about-card">
            <h2>7 Prinsipyo ng Kooperatiba</h2>
            <ol><li>Malaya at bukas na kaisipan</li><li>Demokratikong pamamahala</li><li>Pangkabuhayang paglahok ng mga kasapi</li><li>Pagsasarili at kalayaan</li><li>Pag-aaral, pagsasanay at impormasyon</li><li>Pagtutulungan ng mga kooperatiba</li><li>Pagpapahalaga sa komunidad</li></ol>
        </article>
        <article class="about-card history-card">
            <h2>Paano nagsimula ang PASCCO?</h2>
            <p>Ang PASCCO ay nagsimula sa pangalan na Paco Credit Cooperative sa pangunguna ni Fr. Karel Carlos Van Ooteghem na noo'y kura paroko ng San Fernando de Dilao sa Paco. Nakita ni Fr. Carlos ang pangangailangan ng mga vendors o manininda sa Trece de Agosto. Ibig niyang maliwas ang mga ito sa mga usurero.</p>
            <p>Ang kooperatiba ay itinatag at naitala sa Bureau of Cooperative noong Peb. 7, 1983, at nabigyan ng kompirmasyon ng Cooperative Development Authority o CDA noong Marso 21, 1992. Ito ay nagsimula sa 26 na kasapi o incorporators na may 11,000 piso na pinagsamasamang saping puhunan.</p>
            <p>Sa kasalukuyan, ito ay nasa bagong pangalan na PASCCO, Paco Savings &amp; Credit Cooperative.</p>
        </article>
    </section>

    <div class="section-label">Membership &amp; responsibilities</div>
    <section class="about-grid">
        <article class="about-card">
            <h2>Layunin ng PASCCO</h2>
            <ol><li>Upang maimulat ang mga kasapi sa ugaling pagtitipid at pag-iimpok.</li><li>Makalikom ng puhunan na maipapahiram sa mga kasapi sa pangangailangang pangkabuhayan sa mababang interest at magaang na paraan ng pagbabayad.</li><li>Magturo ng mga pangkooperatibang pamamaraan tungo sa pag-unlad ng buhay.</li><li>Maghubog ng mga magiging pinuno.</li><li>Maging daan sa pag-unlad ng pamayanan.</li></ol>
        </article>
        <article class="about-card">
            <h2>Sino ang maaaring maging Kasapi ng PASCCO?</h2>
            <ol><li>Lehitimong Pilipino na naninirahan, empleyado o may pinagkakakitaan sa pamayanang Paco at karatig pook District V and VI.</li><li>Labing walo (18) taong gulang na may mabuting pagkatao.</li><li>Marunong mag-impok at manghiram sa kooperatiba ayon sa pangangailangan at higit sa lahat, marunong magbayad ng perang hiniram.</li><li>Naglalayong matamasa ang mga serbisyo ng kooperatiba lalong lalo na ang pag-iimpok at panghihiram.</li></ol>
        </article>
        <article class="about-card">
            <h2>Paano maging ganap na kasapi?</h2>
            <ol><li>Dumalo ng Pre-Membership Seminar (PMES). Ang bisa ng PMES ay hanggang 6 na buwan lamang.</li><li>Napagtibay ng Board of Directors ang kanyang pagsapi.</li><li>Nakapagbayad ng mga kinakailangang share capital at membership-related fees ayon sa kasalukuyang patakaran ng kooperatiba.</li></ol>
        </article>
        <article class="about-card">
            <h2>Mga kinakailangang ambag at bayarin</h2>
            <p><strong>Associate Membership Preferred Share Capital:</strong> Php2,000 (maaaring bayaran ng buo o Php200 na inisyal at bayaran ang balanseng Php1,800 sa loob ng isang taon).</p>
            <p><strong>Saving Deposit:</strong> Php1,000.00 for regular and Php200.00 for associate.</p>
            <p><strong>Damayan:</strong> Php500.00 for regular and Php400.00 for associate.</p>
            <p><strong>Membership fee:</strong> Php100.00</p><p><strong>Seminar fee:</strong> Php50.00</p><p><strong>ID:</strong> Php100.00</p>
        </article>
        <article class="about-card">
            <h2>Tungkulin ng kasapi</h2>
            <ol><li>Pagdalo sa General Assembly, Membership Seminar, Enrichment Seminar, atbp.</li><li>Patuloy na paglalagak ng kaukulang halaga bilang share capital at savings deposit.</li><li>Pagbabayad ng utang sa takdang panahon.</li><li>Maghalal ng mga opisyal na mabubuti, tapat, may kakayahan at may panahong maglingkod sa samahan.</li><li>Patuloy na mag-anyaya sa iba na maging kasapi.</li><li>Makiisa sa mga pag-aaral tungkol sa ikauunlad ng kooperatiba.</li><li>Pagtangkilik sa produkto/serbisyo ng kooperatiba.</li><li>Ipaalam sa BOD ang anumang puna o suhestiyon upang magkaroon ng kalutasan ang bawat problema.</li></ol>
        </article>
        <article class="about-card">
            <h2>Prebilehiyo ng Kasapi</h2>
            <ol><li>Makapanghiram ng salapi sa tamang patubo.</li><li>Makilahok sa lahat ng usaping pangkooperatiba.</li><li>Makapag-indorso ng sariling produkto/serbisyo.</li><li>Dumalo ng mga pagsasanay ukol sa pagsisimula at pagpapaunlad ng negosyo.</li><li>Matamasa ang mga proyektong binuo ng PASCCO.</li></ol>
        </article>
    </section>
</main>
<?php pascco_footer(); ?>
