<?php
require_once 'pascco_layout.php';
pascco_header('Credit Products', 'credit');
?>
<style>
    .credit-grid { display:grid; gap:22px; grid-template-columns:repeat(3,minmax(0,1fr)); margin-top:30px; }
    .credit-card { background:#fff; border:1px solid #d8e0ee; border-radius:20px; padding:28px; box-shadow:0 10px 28px rgba(7,29,73,.07); }
    .credit-icon { width:50px; height:50px; display:grid; place-items:center; border-radius:15px; background:#e6edf8; color:#1456a0; font-size:1.5rem; margin-bottom:17px; }
    .credit-card h2 { color:#071d49; font-size:1.38rem; }
    .credit-card ul { list-style:none; margin:16px 0 0; padding:0; }
    .credit-card li { position:relative; padding:10px 0 10px 28px; border-top:1px solid #edf1f7; line-height:1.5; }
    .credit-card li::before { content:'✓'; position:absolute; left:0; top:10px; color:#1456a0; font-weight:bold; }
    .credit-callout { margin-top:24px; padding:25px 28px; border-radius:20px; background:linear-gradient(135deg,#071d49,#1456a0); color:#fff; display:flex; align-items:center; justify-content:space-between; gap:20px; }
    .credit-callout h2 { color:#fff; margin:0 0 6px; }
    .credit-callout p { color:rgba(255,255,255,.85); margin:0; line-height:1.6; }
    @media(max-width:900px){ .credit-grid{grid-template-columns:1fr;} .credit-callout{display:block;} .credit-callout .button{margin-top:18px;} }
</style>
<main class="page-shell">
    <div class="eyebrow">Grow with support</div>
    <h1>Loan Products</h1>
    <p class="intro">PASCCO credit products support livelihood, family needs, education, health, and responsible growth. Review the available categories below before applying.</p>

    <section class="credit-grid">
        <article class="credit-card">
            <div class="credit-icon"><i class='bx bx-briefcase-alt-2'></i></div>
            <h2>Productive Loans</h2>
            <ul>
                <li>Business Loan</li><li>Special Promo Loan</li><li>Check Rediscounting</li><li>Livelihood Loan</li><li>Quick Loan - Productive</li><li>Collateralized Loan</li>
            </ul>
        </article>
        <article class="credit-card">
            <div class="credit-icon"><i class='bx bx-home-heart'></i></div>
            <h2>Providential Loans</h2>
            <ul>
                <li>Calamity Loan</li><li>Educational / Tuition Fee Loan</li><li>Medical / Dental Loan</li><li>Quick Loan - Providential</li><li>Minor Home Improvement Loan</li><li>Multipurpose Loan</li><li>Auto Care and Optical Care Loan</li>
            </ul>
        </article>
        <article class="credit-card">
            <div class="credit-icon"><i class='bx bx-shield-plus'></i></div>
            <h2>Special Loans</h2>
            <ul>
                <li>Health &amp; Wellness Loan</li><li>Memorial Plan</li><li>Personal Accident Insurance</li><li>Manila North Green Park</li>
            </ul>
        </article>
    </section>

    <section class="credit-callout">
        <div>
            <h2>Ready to apply?</h2>
            <p>Submit your loan application securely through your member account.</p>
        </div>
        <a class="button" href="apply_loan.php">Apply for a Loan</a>
    </section>
</main>
<?php pascco_footer(); ?>
