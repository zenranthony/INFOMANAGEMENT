<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/pascco_shell.php';
require_once __DIR__ . '/mail_config.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: login.php');
    exit;
}

$message = '';
$error = '';
$selected_application_id = (int) ($_GET['application_id'] ?? 0);
$status_filter = $_GET['status'] ?? 'all';
$allowed_statuses = ['all','pending_schedule','scheduled','pmes_completed','documents_submitted','under_review','approved', 'rejected'];
if (!in_array($status_filter, $allowed_statuses, true)) {
    $status_filter = 'all';
}

$where = $status_filter === 'all' ? '' : 'WHERE status = :status';
$stmt = $pdo->prepare('SELECT * FROM membership_applications ' . $where . ' ORDER BY created_at DESC');
if ($status_filter !== 'all') {
    $stmt->execute([':status' => $status_filter]);
} else {
    $stmt->execute();
}
$applications = $stmt->fetchAll();

$selected_application = null;
if ($selected_application_id > 0) {
    $detail = $pdo->prepare('SELECT * FROM membership_applications WHERE id = ? LIMIT 1');
    $detail->execute([$selected_application_id]);
    $selected_application = $detail->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $application_id = (int) ($_POST['application_id'] ?? 0);
    $new_status = trim($_POST['status'] ?? '');
    $admin_notes = trim($_POST['admin_notes'] ?? '');
    $action = $_POST['action'] ?? '';

    if ($action === 'schedule_pmes') {

    $pmes_date = trim($_POST['pmes_date'] ?? '');
    $pmes_time = trim($_POST['pmes_time'] ?? '');
    $pmes_mode = trim($_POST['pmes_mode'] ?? '');
    $pmes_location = trim($_POST['pmes_location'] ?? '');
    $pmes_link = trim($_POST['pmes_link'] ?? '');

    try {

        $stmt = $pdo->prepare("
            SELECT *
            FROM membership_applications
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$application_id]);
        $application = $stmt->fetch();

        if (!$application) {
            throw new RuntimeException('Application not found.');
        }

        if (
            $pmes_date === '' ||
            $pmes_time === '' ||
            !in_array($pmes_mode, ['Online', 'Onsite'], true)
        ) {
            throw new RuntimeException(
                'Please complete the PMES schedule details.'
            );
        }

        if (
            $pmes_mode === 'Online' &&
            $pmes_link === ''
        ) {
            throw new RuntimeException(
                'Please provide the online meeting link.'
            );
        }

        if (
            $pmes_mode === 'Onsite' &&
            $pmes_location === ''
        ) {
            throw new RuntimeException(
                'Please provide the seminar venue.'
            );
        }

        $schedule_text =
            $pmes_date . ' ' . $pmes_time;

        $database_mode =
            $pmes_mode === 'Online'
            ? 'online'
            : 'face_to_face';

        $update = $pdo->prepare("
            UPDATE membership_applications
            SET
                pmes_schedule = ?,
                pmes_mode = ?,
                pmes_location = ?,
                pmes_link = ?,
                status = 'scheduled',
                updated_at = NOW()
            WHERE id = ?
        ");

        $update->execute([
            $schedule_text,
            $database_mode,
            $pmes_location !== ''
                ? $pmes_location
                : null,
            $pmes_link !== ''
                ? $pmes_link
                : null,
            $application_id
        ]);

        $email_sent = sendPmesScheduleEmail(
            $application['email'],
            $application['member_name'],
            $pmes_date,
            $pmes_time,
            $pmes_mode,
            $pmes_location,
            $pmes_link
        );

        if ($email_sent) {
            $message =
                'PMES scheduled and email sent successfully.';
        } else {
            $message =
                'PMES schedule saved, but the email could not be sent.';
        }

    } catch (Throwable $exception) {

        $error = $exception->getMessage();
    }

}
elseif ($action === 'complete_pmes') {

    try {

        $stmt = $pdo->prepare("
            SELECT *
            FROM membership_applications
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$application_id]);
        $application = $stmt->fetch();

        if (!$application) {
            throw new RuntimeException('Application not found.');
        }

        if ($application['status'] !== 'scheduled') {
            throw new RuntimeException(
                'Only scheduled PMES applications can be marked as completed.'
            );
        }

        $update = $pdo->prepare("
            UPDATE membership_applications
            SET
                status = 'pmes_completed',
                updated_at = NOW()
            WHERE id = ?
        ");

        $update->execute([$application_id]);

        record_audit(
            $pdo,
            (int) $_SESSION['user_id'],
            'pmes_completed',
            'Marked PMES as completed for application ' .
            $application['application_reference'],
            'success'
        );

        $message =
            'PMES marked as completed. The applicant may now upload the required membership documents.';

    } catch (Throwable $exception) {

        $error = $exception->getMessage();
    }
}

elseif ($action === 'resend_credentials') {

    try {
        $app_stmt = $pdo->prepare("
            SELECT *
            FROM membership_applications
            WHERE id = ?
            LIMIT 1
        ");
        $app_stmt->execute([$application_id]);
        $application = $app_stmt->fetch();

        if (!$application) {
            throw new RuntimeException('Application not found.');
        }

        if ($application['status'] !== 'approved' || empty($application['user_id'])) {
            throw new RuntimeException('Login credentials can only be resent for an approved member account.');
        }

        $account_stmt = $pdo->prepare("
            SELECT
                u.id AS user_id,
                u.username,
                m.id AS member_id,
                m.member_number,
                a.account_number
            FROM users u
            INNER JOIN members m ON m.user_id = u.id
            INNER JOIN accounts a ON a.member_id = m.id
            WHERE u.id = ?
            ORDER BY a.id ASC
            LIMIT 1
        ");
        $account_stmt->execute([(int) $application['user_id']]);
        $member_account = $account_stmt->fetch();

        if (!$member_account) {
            throw new RuntimeException('The approved member account could not be found.');
        }

        $temporary_password = 'PASCCO' . random_int(1000, 9999);
        $password_hash = password_hash($temporary_password, PASSWORD_DEFAULT);

        $password_update = $pdo->prepare("
            UPDATE users
            SET password = ?
            WHERE id = ?
        ");
        $password_update->execute([
            $password_hash,
            (int) $member_account['user_id']
        ]);

        $email_sent = sendMembershipApprovedEmail(
            $application['email'],
            $application['member_name'],
            $member_account['username'],
            $temporary_password,
            $member_account['member_number'],
            $member_account['account_number']
        );

        record_audit(
            $pdo,
            (int) $_SESSION['user_id'],
            'resend_member_credentials',
            'Generated a new temporary password and resent login credentials for application ' .
            $application['application_reference'],
            $email_sent ? 'success' : 'failed'
        );

        if ($email_sent) {
            $message = 'A new temporary password was generated and the login credentials were sent by email.';
        } else {
            $message =
                'A new temporary password was generated, but the email could not be sent. ' .
                'Username: ' . $member_account['username'] .
                ' | Temporary Password: ' . $temporary_password;
        }

    } catch (Throwable $exception) {
        $error = $exception->getMessage();
    }
}

elseif (
    $application_id <= 0 ||
    !in_array(
        $new_status,
        [
            'pending_schedule',
            'scheduled',
            'pmes_completed',
            'documents_submitted',
            'under_review',
            'approved',
            'rejected'
        ],
        true
    )
) {
        $error = 'Invalid membership request.';
    } else {
        try {
            if ($new_status === 'approved') {

    $pdo->beginTransaction();

    try {

        $app_stmt = $pdo->prepare("
            SELECT *
            FROM membership_applications
            WHERE id = ?
            FOR UPDATE
        ");

        $app_stmt->execute([$application_id]);
        $application = $app_stmt->fetch();

        if (!$application) {
            throw new RuntimeException('Application not found.');
        }

        if ($application['status'] === 'approved') {
            throw new RuntimeException('This application is already approved.');
        }

        // Create username
        $base_username =
            strtolower(preg_replace('/[^a-z0-9]/i', '', $application['first_name']))
            . '_'
            . strtolower(preg_replace('/[^a-z0-9]/i', '', $application['last_name']));

        $username = $base_username;
        $counter = 1;

        while (true) {

            $check = $pdo->prepare("
                SELECT id
                FROM users
                WHERE username = ?
                LIMIT 1
            ");

            $check->execute([$username]);

            if (!$check->fetch()) {
                break;
            }

            $username = $base_username . $counter;
            $counter++;
        }

        // Temporary password
        $temporary_password = 'PASCCO' . random_int(1000, 9999);

        $password_hash = password_hash(
            $temporary_password,
            PASSWORD_DEFAULT
        );

        // Create user
        $user_insert = $pdo->prepare("
            INSERT INTO users
            (
                username,
                email,
                password,
                role,
                status
            )
            VALUES (?, ?, ?, 'member', 'active')
        ");

        $user_insert->execute([
            $username,
            $application['email'],
            $password_hash
        ]);

        $user_id = (int) $pdo->lastInsertId();

        // Member number
        $member_number =
            'PAS-' .
            date('Y') .
            '-' .
            str_pad((string)$user_id, 5, '0', STR_PAD_LEFT);

        // Create member
        $member_insert = $pdo->prepare("
            INSERT INTO members
            (
                user_id,
                member_number,
                first_name,
                last_name,
                email,
                phone
            )
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $member_insert->execute([
            $user_id,
            $member_number,
            $application['first_name'],
            $application['last_name'],
            $application['email'],
            $application['phone']
        ]);

        $member_id = (int) $pdo->lastInsertId();

        // Savings account number
        $account_number =
            'SAV-' .
            date('Y') .
            '-' .
            str_pad((string)$member_id, 6, '0', STR_PAD_LEFT);

        // Create savings account
        $account_insert = $pdo->prepare("
            INSERT INTO accounts
            (
                member_id,
                account_number,
                account_type,
                balance,
                status
            )
            VALUES (?, ?, 'Savings', 0.00, 'active')
        ");

        $account_insert->execute([
            $member_id,
            $account_number
        ]);

        // Mark application approved
        $update = $pdo->prepare("
            UPDATE membership_applications
            SET
                status = 'approved',
                user_id = ?,
                admin_notes = ?,
                updated_at = NOW()
            WHERE id = ?
        ");

        $update->execute([
            $user_id,
            $admin_notes,
            $application_id
        ]);

        // Finalize the database changes before sending the email.
        $pdo->commit();

        $email_sent = sendMembershipApprovedEmail(
    $application['email'],
    $application['member_name'],
    $username,
    $temporary_password,
    $member_number,
    $account_number
);

if ($email_sent) {

    $message =
        'Membership approved successfully. ' .
        'The member account was created and the login credentials were sent by email.';

} else {

    $message =
        'Membership approved and the member account was created, ' .
        'but the credential email could not be sent. ' .
        'Username: ' .
        $username .
        ' | Temporary Password: ' .
        $temporary_password;
}

    } catch (Throwable $exception) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        // Pass the real error to the outer handler so we do not continue
        // and show a false success message after a failed approval.
        throw $exception;
    }

} else {

    $update = $pdo->prepare("
        UPDATE membership_applications
        SET
            status = ?,
            admin_notes = ?,
            updated_at = NOW()
        WHERE id = ?
    ");

    $update->execute([
        $new_status,
        $admin_notes,
        $application_id
    ]);

    $message = 'Membership application updated successfully.';
}
            record_audit($pdo, (int) $_SESSION['user_id'], 'membership_review', 'Updated registration application status to ' . $new_status, 'success');
            $selected_application_id = $application_id;
            $detail = $pdo->prepare('SELECT * FROM membership_applications WHERE id = ? LIMIT 1');
            $detail->execute([$application_id]);
            $selected_application = $detail->fetch();
            $stmt = $pdo->prepare('SELECT * FROM membership_applications ' . ($status_filter === 'all' ? '' : 'WHERE status = :status') . ' ORDER BY created_at DESC');
            if ($status_filter !== 'all') {
                $stmt->execute([':status' => $status_filter]);
            } else {
                $stmt->execute();
            }
            $applications = $stmt->fetchAll();
        } catch (Throwable $exception) {
            $error = $exception->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php pascco_global_styles(); ?>
<title>Membership Review | PASCCO Admin</title>

<style>
:root{--navy:#071d49;--blue:#1456a0;--blue2:#2b74c8;--gold:#e7b84b;--gold-light:#ffe7a1;--ink:#18324f;--muted:#6e7e93;--line:#dce5ef;--bg:#f4f7fb;--surface:#fff;--soft:#eef4fb;--success:#1c7442;--danger:#b52f38;--shadow:0 16px 40px rgba(7,29,73,.08)}
html,body{margin:0!important;padding:0!important;overflow-x:hidden}body{background:linear-gradient(180deg,#edf4fb 0,#f7f9fc 360px,var(--bg) 100%);color:var(--ink);font-family:Poppins,Arial,sans-serif}.admin-wrap{width:min(100% - 40px,1200px);margin:0 auto;padding:34px 0 58px}.page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:22px}.eyebrow{display:inline-flex;align-items:center;gap:8px;color:var(--blue);font-size:.74rem;font-weight:800;letter-spacing:.15em;text-transform:uppercase}.eyebrow:before{content:"";width:28px;height:3px;background:var(--gold);border-radius:999px}.page-head h1{margin:8px 0 0;color:var(--navy);font-size:clamp(2rem,4vw,3rem);line-height:1.05}.page-head p{margin:10px 0 0;color:var(--muted);line-height:1.6}.head-actions,.quick-actions{display:flex;gap:9px;flex-wrap:wrap}.button{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:11px 15px;border-radius:11px;background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;text-decoration:none;font-weight:800;font-size:.86rem;box-shadow:0 8px 18px rgba(20,86,160,.15)}.button.secondary{background:#fff;border:1px solid #cdd8e5;color:var(--navy);box-shadow:none}.button.gold{background:var(--gold);color:var(--navy)}.surface{background:var(--surface);border:1px solid rgba(7,29,73,.07);border-radius:20px;box-shadow:var(--shadow);overflow:hidden}.surface-head{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:21px 23px;border-bottom:1px solid var(--line)}.surface-head h2,.surface-head h3{margin:0;color:var(--navy);font-size:1.15rem}.surface-head p{margin:5px 0 0;color:var(--muted);font-size:.86rem}.surface-body{padding:22px}.stat-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin-bottom:20px}.stat{position:relative;padding:20px;border-radius:18px;background:#fff;border:1px solid rgba(7,29,73,.07);box-shadow:var(--shadow);overflow:hidden}.stat:after{content:"";position:absolute;right:-35px;top:-35px;width:120px;height:120px;border:1px solid rgba(20,86,160,.10);border-radius:50%;box-shadow:0 0 0 22px rgba(20,86,160,.025)}.stat .label{color:#78889b;font-size:.72rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase}.stat .value{margin-top:8px;color:var(--navy);font-size:1.65rem;font-weight:800;line-height:1.15}.stat.gold{border-top:4px solid var(--gold)}.stat.blue{border-top:4px solid var(--blue)}.grid-2{display:grid;grid-template-columns:1.35fr .65fr;gap:20px}.grid-2.equal{grid-template-columns:1fr 1fr}.stack{display:grid;gap:20px}.status-grid{display:grid;grid-template-columns:1fr 1fr;gap:11px}.status-tile{padding:14px;border-radius:13px;background:var(--soft);border:1px solid var(--line)}.status-tile span{display:block;color:var(--muted);font-size:.75rem}.status-tile strong{display:block;margin-top:4px;color:var(--navy);font-size:1.3rem}.status-tile.gold{background:#fff8df;border-color:#f0dda2}.status-tile.green{background:#eef9f2;border-color:#cde8d6}.status-tile.red{background:#fff1f1;border-color:#f0cccc}.table-wrap{overflow:auto}.admin-table{width:100%;min-width:640px;border-collapse:collapse}.admin-table th,.admin-table td{padding:13px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.82rem}.admin-table th{background:#f3f7fc;color:var(--navy);font-weight:800;position:sticky;top:0}.admin-table tr:hover td{background:#fbfdff}.sub{display:block;color:#8694a5;font-size:.72rem;margin-top:3px}.badge,.status-pill{display:inline-flex;align-items:center;gap:5px;padding:5px 9px;border-radius:999px;background:#e8f0fa;color:var(--navy);font-size:.7rem;font-weight:800;text-transform:uppercase}.badge.pending,.status-pill.pending{background:#fff0bf;color:#8a6500}.badge.approved,.status-pill.approved,.badge.paid{background:#e4f6ea;color:#17673b}.badge.rejected,.status-pill.rejected{background:#fde7e7;color:#a52f37}.badge.under_review,.status-pill.under_review{background:#efe8ff;color:#6945a6}.badge.scheduled,.status-pill.scheduled{background:#e9f3ff;color:#2966a8}.badge.certificate_uploaded,.status-pill.certificate_uploaded{background:#e5f8ed;color:#25714a}.notice{padding:13px 15px;border-radius:12px;margin-bottom:18px;font-weight:700;font-size:.86rem}.notice.success{background:#eaf8f0;border:1px solid #cfe9d9;color:var(--success)}.notice.error{background:#fff0f0;border:1px solid #f0cfd0;color:var(--danger)}.toolbar{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}.search-form{display:flex;gap:8px;width:min(100%,480px)}.field{margin-bottom:15px}.field label{display:block;margin-bottom:7px;color:var(--navy);font-size:.78rem;font-weight:800}.field input,.field select,.field textarea,.search-form input{width:100%;box-sizing:border-box;min-height:46px;padding:11px 13px;border:1px solid #cad6e3;border-radius:11px;background:#fff;color:var(--ink);font:inherit;outline:none}.field textarea{min-height:110px;resize:vertical}.field input:focus,.field select:focus,.field textarea:focus,.search-form input:focus{border-color:var(--blue2);box-shadow:0 0 0 4px rgba(20,86,160,.09)}.search-form input{flex:1}.search-form button,.action-btn{border:0;border-radius:11px;padding:11px 15px;background:var(--navy);color:#fff;font:inherit;font-weight:800;cursor:pointer}.filter-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.filter-row select{min-height:44px;border:1px solid #cad6e3;border-radius:11px;padding:9px 12px;background:#fff;font:inherit}.detail-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.detail-box{padding:13px;border:1px solid var(--line);border-radius:13px;background:#f8fbff}.detail-box small{display:block;color:#8291a2;font-size:.7rem}.detail-box strong{display:block;margin-top:4px;color:var(--navy);font-size:.84rem;line-height:1.45}.record-list{display:grid;gap:12px}.record{padding:17px;border:1px solid var(--line);border-radius:15px;background:#fbfdff}.record-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.record h3{margin:0;color:var(--navy);font-size:1rem}.record p{margin:5px 0;color:var(--muted);font-size:.82rem;line-height:1.5}.record-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:13px}.mini-link{color:var(--blue);font-weight:800;text-decoration:none;font-size:.82rem}.empty{padding:26px;text-align:center;color:var(--muted);background:#f8fbff;border:1px dashed #cdd9e5;border-radius:14px}.amount{color:var(--blue);font-weight:800;white-space:nowrap}.approval-card{padding:19px;border:1px solid var(--line);border-radius:17px;background:#fff}.approval-card+.approval-card{margin-top:12px}.approval-meta{color:var(--muted);font-size:.78rem}.approval-top{display:flex;justify-content:space-between;gap:15px;align-items:flex-start}.approval-top h3{margin:0;color:var(--navy);font-size:1rem}.approval-details{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:16px 0}.approval-details div{padding-top:9px;border-top:1px solid var(--line)}.approval-details small,.identity-grid small{display:block;color:#8291a2;font-size:.7rem}.approval-details strong,.identity-grid strong{display:block;margin-top:3px;color:var(--navy);font-size:.82rem;line-height:1.45}.identity-panel{padding:16px;border-radius:15px;background:#fffaf0;border:1px solid #ecdca8}.identity-panel h4{margin:0 0 12px;color:var(--navy)}.identity-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 14px}.document-links{display:flex;flex-wrap:wrap;gap:9px;margin-top:13px}.document-links a,.receipt-link{color:var(--blue);font-weight:800;text-decoration:none;font-size:.8rem}.review-form{display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;margin-top:13px}.review-form textarea{flex:1;min-width:220px;min-height:45px;padding:10px;border:1px solid #cad6e3;border-radius:10px;font:inherit}.btn-success,.btn-danger,.btn-primary{border:0;border-radius:10px;padding:10px 13px;font:inherit;font-weight:800;cursor:pointer}.btn-success{background:#267748;color:#fff}.btn-danger{background:#b8323b;color:#fff}.btn-primary{background:var(--blue);color:#fff}.announcement-grid{display:grid;grid-template-columns:.7fr 1.3fr;gap:20px}.announcement-card{padding:18px;border:1px solid var(--line);border-radius:16px;background:#fff}.announcement-card img{width:100%;max-height:190px;object-fit:cover;border-radius:12px;margin-bottom:12px}.announcement-card h3{margin:0;color:var(--navy);font-size:1rem}.announcement-card p{color:var(--muted);line-height:1.55;font-size:.82rem;white-space:pre-line}.announcement-card+.announcement-card{margin-top:12px}.profile-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.quick-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.quick-card{padding:16px;border-radius:15px;background:#f8fbff;border:1px solid var(--line)}.quick-card i{font-size:1.35rem;color:var(--blue)}.quick-card strong{display:block;margin-top:8px;color:var(--navy)}.quick-card span{display:block;margin-top:4px;color:var(--muted);font-size:.76rem;line-height:1.45}.mt{margin-top:20px}@media(max-width:1000px){.stat-grid{grid-template-columns:repeat(2,1fr)}.grid-2,.grid-2.equal,.announcement-grid{grid-template-columns:1fr}.detail-grid,.profile-grid,.approval-details,.identity-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.quick-grid{grid-template-columns:1fr 1fr}}@media(max-width:700px){.admin-wrap{width:min(100% - 28px,1200px);padding-top:24px}.page-head{align-items:flex-start;flex-direction:column}.head-actions,.quick-actions{width:100%}.button{flex:1}.stat-grid{grid-template-columns:1fr}.surface-head,.surface-body{padding:17px}.detail-grid,.profile-grid,.approval-details,.identity-grid,.quick-grid{grid-template-columns:1fr}.search-form{width:100%}.search-form button{white-space:nowrap}.approval-top,.record-head{flex-direction:column}.review-form{align-items:stretch;flex-direction:column}.review-form textarea{min-width:0}.review-form button{width:100%}}
</style>

</head>
<body>
<?php pascco_admin_header(); ?>

<main class="admin-wrap">
<section class="page-head"><div><div class="eyebrow">Membership operations</div><h1>Membership Review</h1><p>Review applications, schedules, certificates, and final membership status.</p></div><a class="button secondary" href="admin_dashboard.php"><i class="bx bx-arrow-back"></i> Dashboard</a></section>
<?php if($message): ?><div class="notice success"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?><?php if($error): ?><div class="notice error"><?php echo htmlspecialchars($error,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
<section class="surface">

    <div class="surface-head">
        <div>
            <h2>Application Filter</h2>
            <p>Choose a status to focus your review queue.</p>
        </div>
    </div>

    <div class="surface-body">

        <div class="filter-row">

            <label for="status-filter">
                <strong>Status</strong>
            </label>

            <select
                id="status-filter"
                onchange="window.location='admin_membership.php?status='+encodeURIComponent(this.value)"
            >

                <option
                    value="all"
                    <?php echo $status_filter === 'all' ? 'selected' : ''; ?>
                >
                    All
                </option>

                <?php foreach ([
                    'pending_schedule',
                    'scheduled',
                    'pmes_completed',
                    'documents_submitted',
                    'under_review',
                    'approved',
                    'rejected'
                ] as $status): ?>

                    <option
                        value="<?php echo $status; ?>"
                        <?php echo $status_filter === $status ? 'selected' : ''; ?>
                    >
                        <?php echo ucfirst(str_replace('_', ' ', $status)); ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>

    </div>

</section>
<section class="surface mt"><div class="surface-head"><div><h2>Membership Applications</h2><p><?php echo count($applications); ?> application<?php echo count($applications)===1?'':'s'; ?> in this view.</p></div></div><div class="surface-body"><div class="record-list"><?php if($applications): foreach($applications as $application): ?><article class="record"><div class="record-head"><div><h3><?php echo htmlspecialchars($application['member_name']); ?></h3><p><?php echo htmlspecialchars($application['email']); ?> · <?php echo htmlspecialchars($application['phone']); ?></p></div><span class="status-pill <?php echo htmlspecialchars($application['status']); ?>"><?php echo strtoupper(str_replace('_',' ',$application['status'])); ?></span></div><div class="record-actions"><a class="mini-link" href="admin_membership.php?status=<?php echo urlencode($status_filter); ?>&application_id=<?php echo (int)$application['id']; ?>">Review application <i class="bx bx-right-arrow-alt"></i></a></div></article><?php endforeach; else: ?><div class="empty">No membership applications found.</div><?php endif; ?></div></div></section>
<?php if ($selected_application): ?>
    <?php if ($selected_application['status'] === 'pending_schedule'): ?>

    <div class="mt">

        <h3>Schedule PMES</h3>

        <p style="color:var(--muted);">
            Choose the seminar date, time, and mode.
            The applicant will receive the schedule by email.
        </p>

        <form method="POST">

            <input
                type="hidden"
                name="csrf_token"
                value="<?php echo htmlspecialchars(
                    $_SESSION['csrf_token'],
                    ENT_QUOTES,
                    'UTF-8'
                ); ?>"
            >

            <input
                type="hidden"
                name="application_id"
                value="<?php echo (int) $selected_application['id']; ?>"
            >

            <input
                type="hidden"
                name="action"
                value="schedule_pmes"
            >

            <div class="grid-2 equal">

                <div class="field">
                    <label for="pmes-date">
                        PMES Date
                    </label>

                    <input
                        id="pmes-date"
                        type="date"
                        name="pmes_date"
                        required
                    >
                </div>

                <div class="field">
                    <label for="pmes-time">
                        PMES Time
                    </label>

                    <input
                        id="pmes-time"
                        type="time"
                        name="pmes_time"
                        required
                    >
                </div>

                <div class="field">
                    <label for="pmes-mode">
                        PMES Mode
                    </label>

                    <select
                        id="pmes-mode"
                        name="pmes_mode"
                        required
                    >
                        <option value="">
                            Select mode
                        </option>

                        <option value="Online">
                            Online
                        </option>

                        <option value="Onsite">
                            Onsite / Face-to-Face
                        </option>
                    </select>
                </div>

                <div class="field" id="venue-field">
                    <label for="pmes-location">
                        Venue
                    </label>

                    <input
                        id="pmes-location"
                        type="text"
                        name="pmes_location"
                        placeholder="Example: PASCCO Office, Paco, Manila"
                    >
                </div>

                <div class="field" id="link-field">
                    <label for="pmes-link">
                        Meeting Link
                    </label>

                    <input
                        id="pmes-link"
                        type="url"
                        name="pmes_link"
                        placeholder="https://meet.google.com/..."
                    >
                </div>

            </div>

            <button
                class="action-btn"
                type="submit"
            >
                Schedule PMES & Send Email
            </button>

        </form>

    </div>

<?php endif; ?>

<?php if ($selected_application['status'] === 'scheduled'): ?>

    <div class="mt">

        <h3>PMES Attendance</h3>

        <p style="color:var(--muted);">
            Use this action after PASCCO confirms that the applicant
            attended and completed the scheduled PMES.
        </p>

        <form method="POST">

            <input
                type="hidden"
                name="csrf_token"
                value="<?php echo htmlspecialchars(
                    $_SESSION['csrf_token'],
                    ENT_QUOTES,
                    'UTF-8'
                ); ?>"
            >

            <input
                type="hidden"
                name="application_id"
                value="<?php echo (int) $selected_application['id']; ?>"
            >

            <input
                type="hidden"
                name="action"
                value="complete_pmes"
            >

            <button
                class="btn-success"
                type="submit"
            >
                Mark PMES Completed
            </button>

        </form>

    </div>

<?php endif; ?>

<?php if ($selected_application['status'] === 'approved' && !empty($selected_application['user_id'])): ?>

    <div class="mt">
        <h3>Member Login Credentials</h3>
        <p style="color:var(--muted);">
            Generate a new temporary password and resend the member's login credentials by email.
            The previous password will stop working.
        </p>

        <form method="POST" onsubmit="return confirm('Generate a new temporary password and resend the login credentials?');">
            <input
                type="hidden"
                name="csrf_token"
                value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"
            >

            <input
                type="hidden"
                name="application_id"
                value="<?php echo (int) $selected_application['id']; ?>"
            >

            <input type="hidden" name="action" value="resend_credentials">

            <button class="btn-primary" type="submit">
                Resend Login Credentials
            </button>
        </form>
    </div>

<?php endif; ?>

<form method="POST" action="admin_membership.php?status=<?php echo urlencode($status_filter); ?>&application_id=<?php echo (int)$selected_application['id']; ?>" class="mt"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>"><input type="hidden" name="application_id" value="<?php echo (int)$selected_application['id']; ?>"><div class="grid-2 equal"><div class="field"><label for="status">Update Status</label><select id="status" name="status">
<?php foreach(['pending_schedule','scheduled','pmes_completed','documents_submitted','under_review','approved','rejected'] as $status): ?><option value="<?php echo $status; ?>" <?php echo $selected_application['status']===$status?'selected':''; ?>><?php echo ucfirst(str_replace('_',' ',$status)); ?></option><?php endforeach; ?></select></div><div class="field"><label for="admin-notes">Admin Notes</label><textarea id="admin-notes" name="admin_notes" placeholder="Add review comments"><?php echo htmlspecialchars($selected_application['admin_notes']??'',ENT_QUOTES,'UTF-8'); ?></textarea></div></div><button class="action-btn" type="submit"><i class="bx bx-save"></i> Save Review</button></form></div></section><?php endif; ?>
</main>
<?php pascco_global_footer(); ?>
<script>
const modeSelect = document.getElementById('pmes-mode');
const venueField = document.getElementById('venue-field');
const linkField = document.getElementById('link-field');

function updatePmesFields() {
    if (!modeSelect) {
        return;
    }

    const mode = modeSelect.value;

    if (mode === 'Online') {
        venueField.style.display = 'none';
        linkField.style.display = 'block';
    } else if (mode === 'Onsite') {
        venueField.style.display = 'block';
        linkField.style.display = 'none';
    } else {
        venueField.style.display = 'block';
        linkField.style.display = 'block';
    }
}

if (modeSelect) {
    modeSelect.addEventListener('change', updatePmesFields);
    updatePmesFields();
}
</script>
</body>
</html>
