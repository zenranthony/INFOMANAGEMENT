<?php
require_once 'db.php';
require_once 'pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') { header("Location: login.php"); exit; }

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

$account_stmt = $pdo->prepare("SELECT m.id AS member_id,m.first_name,m.last_name,m.member_number,a.id AS account_id,a.account_number,a.account_type,a.balance FROM members m JOIN accounts a ON m.id=a.member_id WHERE m.user_id=? AND a.status='active' ORDER BY a.id");
$account_stmt->execute([$user_id]);
$accounts = $account_stmt->fetchAll();

$selected_account_id = (int)($_POST['account_id'] ?? $_GET['account_id'] ?? ($accounts[0]['account_id'] ?? 0));
$account = null;

foreach ($accounts as $available_account) {
    if ((int)$available_account['account_id'] === $selected_account_id) {
        $account = $available_account;
        break;
    }
}

if (!$account && $accounts) {
    $account = $accounts[0];
    $selected_account_id = (int)$account['account_id'];
}

$active_loans = [];

if ($account) {
    $loan_stmt = $pdo->prepare("SELECT * FROM loans WHERE member_id=? AND status='approved' AND remaining_balance>0");
    $loan_stmt->execute([$account['member_id']]);
    $active_loans = $loan_stmt->fetchAll();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'transact') {
    verify_csrf();

    $type = $_POST['transaction_type'];
    $amount = floatval($_POST['amount']);

    $description_options = ['Counter Deposit','Counter Withdrawal','Monthly Savings','Salary Savings','Bills Payment','Loan Payment','Other'];
    $description = trim($_POST['description'] ?? '');
    $custom_description = trim($_POST['custom_description'] ?? '');
    $desc = $description === 'Other' ? $custom_description : $description;
    $posted_account_id = (int)($_POST['account_id'] ?? 0);

    if (!in_array($type,['deposit','withdrawal'],true)) {
        $error = "Invalid transaction type.";
    } elseif (!in_array($description,$description_options,true)) {
        $error = "Please select a transaction description.";
    } elseif ($description === 'Other' && $custom_description === '') {
        $error = "Please enter a description for the other transaction.";
    } elseif (!$account || $posted_account_id !== (int)$account['account_id']) {
        $error = "Please select a valid savings account.";
    } elseif ($amount <= 0) {
        $error = "Please enter a valid amount greater than zero.";
    } elseif ($type === 'withdrawal' && $amount > $account['balance']) {
        $error = "Insufficient balance for this withdrawal!";
    } else {
        try {
            $pdo->beginTransaction();

            $lock = $pdo->prepare("SELECT balance FROM accounts WHERE id=? AND status='active' FOR UPDATE");
            $lock->execute([(int)$account['account_id']]);
            $locked_account = $lock->fetch();

            if (!$locked_account || ($type === 'withdrawal' && $amount > (float)$locked_account['balance'])) {
                throw new RuntimeException('The available balance changed. Please review it and try again.');
            }

            $ref_number = 'OR-' . date('YmdHis') . '-' . random_int(100000,999999);

            $insert = $pdo->prepare("INSERT INTO transactions (account_id,transaction_type,amount,recipient_account_id,description,status,reference_number,transaction_date,created_at) VALUES (?,?,?,NULL,?,'completed',?,UNIX_TIMESTAMP(),UNIX_TIMESTAMP())");
            $insert->execute([$account['account_id'],$type,$amount,$desc,$ref_number]);

            $balance_delta = $type === 'deposit' ? $amount : -$amount;
            $balance_update = $pdo->prepare("UPDATE accounts SET balance=balance+? WHERE id=? AND status='active'");
            $balance_update->execute([$balance_delta,(int)$account['account_id']]);

            $pdo->commit();

            $message = "Transaction successful! " . ucfirst($type) . " of ₱" . number_format($amount,2) . " processed.";

            $account_stmt->execute([$user_id]);
            $accounts = $account_stmt->fetchAll();

            foreach ($accounts as $available_account) {
                if ((int)$available_account['account_id'] === $selected_account_id) {
                    $account = $available_account;
                    break;
                }
            }
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $exception->getMessage();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'repay_loan') {
    verify_csrf();

    $loan_id = intval($_POST['loan_id']);
    $amount = floatval($_POST['repay_amount']);

    $l_check = $pdo->prepare("SELECT * FROM loans WHERE id=? AND member_id=?");
    $l_check->execute([$loan_id,$account['member_id']]);
    $selected_loan = $l_check->fetch();

    if (!$selected_loan) {
        $error = "Invalid loan selected.";
    } elseif ($amount <= 0) {
        $error = "Please enter a valid repayment amount.";
    } elseif ($amount > $account['balance']) {
        $error = "Insufficient savings balance to cover this repayment!";
    } elseif ($amount > $selected_loan['remaining_balance']) {
        $error = "Payment amount exceeds the remaining loan balance of ₱" . number_format($selected_loan['remaining_balance'],2);
    } else {
        try {
            $pdo->beginTransaction();

            $lock_account = $pdo->prepare("SELECT balance FROM accounts WHERE id=? AND status='active' FOR UPDATE");
            $lock_account->execute([(int)$account['account_id']]);
            $locked_account = $lock_account->fetch();

            $lock_loan = $pdo->prepare("SELECT remaining_balance FROM loans WHERE id=? AND member_id=? AND status='approved' FOR UPDATE");
            $lock_loan->execute([$loan_id,$account['member_id']]);
            $locked_loan = $lock_loan->fetch();

            if (!$locked_account || !$locked_loan || $amount > (float)$locked_account['balance'] || $amount > (float)$locked_loan['remaining_balance']) {
                throw new RuntimeException('The balance or loan amount changed. Please review the payment and try again.');
            }

            $ref_number = 'OR-' . date('YmdHis') . '-' . random_int(100000,999999);

            $tx = $pdo->prepare("INSERT INTO transactions (account_id,transaction_type,amount,recipient_account_id,description,status,reference_number,transaction_date,created_at) VALUES (?,'withdrawal',?,NULL,'Loan Payment','completed',?,UNIX_TIMESTAMP(),UNIX_TIMESTAMP())");
            $tx->execute([$account['account_id'],$amount,$ref_number]);

            $balance_update = $pdo->prepare("UPDATE accounts SET balance=balance-? WHERE id=? AND status='active'");
            $balance_update->execute([$amount,(int)$account['account_id']]);

            $new_rem = (float)$locked_loan['remaining_balance'] - $amount;
            $new_status = $new_rem == 0.0 ? 'paid' : 'approved';

            $up_loan = $pdo->prepare("UPDATE loans SET remaining_balance=?,status=? WHERE id=?");
            $up_loan->execute([$new_rem,$new_status,$loan_id]);

            $pdo->commit();

            $message = "Loan payment of ₱" . number_format($amount,2) . " successful!";

            $account_stmt->execute([$user_id]);
            $accounts = $account_stmt->fetchAll();

            foreach ($accounts as $available_account) {
                if ((int)$available_account['account_id'] === $selected_account_id) {
                    $account = $available_account;
                    break;
                }
            }

            $loan_stmt->execute([$account['member_id']]);
            $active_loans = $loan_stmt->fetchAll();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $exception->getMessage();
        }
    }
}

$transactions = [];

if ($account) {
    $tx_stmt = $pdo->prepare("SELECT transaction_type,amount,description,reference_number,created_at FROM transactions WHERE account_id=? ORDER BY id DESC LIMIT 5");
    $tx_stmt->execute([$account['account_id']]);
    $transactions = $tx_stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Member Dashboard | PASCCO</title>
    <?php pascco_global_styles(); ?>
    <link rel="stylesheet" href="member-panels.css?v=2">
</head>

<body>

<?php pascco_member_header('Member Dashboard'); ?>

<main class="member-content">

<?php if ($account): ?>

    <section class="dashboard-welcome">
        <div class="dashboard-welcome-text">
            <span class="dashboard-eyebrow">MEMBER DASHBOARD</span>
            <h1>Welcome, <?php echo htmlspecialchars($account['first_name'],ENT_QUOTES,'UTF-8'); ?>!</h1>
            <p>Member No. <?php echo htmlspecialchars($account['member_number'],ENT_QUOTES,'UTF-8'); ?></p>
        </div>

        <div class="dashboard-actions">
            <a href="apply_loan.php" class="dashboard-action primary"><i class="bx bx-money"></i>Apply for Loan</a>
            <a href="deposit.php" class="dashboard-action"><i class="bx bx-wallet"></i>Deposit Money</a>
            <a href="transfer.php" class="dashboard-action"><i class="bx bx-transfer"></i>Send Money</a>
        </div>
    </section>

    <?php if ($message): ?>
        <div class="dashboard-alert success"><i class="bx bx-check-circle"></i><span><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></span></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="dashboard-alert danger"><i class="bx bx-error-circle"></i><span><?php echo htmlspecialchars($error,ENT_QUOTES,'UTF-8'); ?></span></div>
    <?php endif; ?>

    <section class="dashboard-top-grid">

        <article class="dashboard-balance-panel">
            <div class="panel-label"><i class="bx bx-wallet"></i>Available Balance</div>
            <div class="dashboard-balance">₱<?php echo number_format($account['balance'],2); ?></div>
            <div class="balance-account"><?php echo htmlspecialchars($account['account_type'],ENT_QUOTES,'UTF-8'); ?> · <?php echo htmlspecialchars($account['account_number'],ENT_QUOTES,'UTF-8'); ?></div>
            <a href="member_savings.php?account_id=<?php echo (int)$account['account_id']; ?>" class="panel-link">View account history <i class="bx bx-right-arrow-alt"></i></a>
        </article>

        <article class="dashboard-info-panel">
            <div class="panel-heading">
                <div><span class="panel-eyebrow">YOUR ACCOUNT</span><h2>Account Overview</h2></div>
                <i class="bx bx-credit-card"></i>
            </div>
            <div class="account-mini-grid">
                <?php foreach ($accounts as $available_account): ?>
                    <div class="account-mini-card">
                        <div class="account-mini-icon"><i class="bx bx-wallet"></i></div>
                        <div class="account-mini-details">
                            <span><?php echo htmlspecialchars($available_account['account_type'],ENT_QUOTES,'UTF-8'); ?></span>
                            <small><?php echo htmlspecialchars($available_account['account_number'],ENT_QUOTES,'UTF-8'); ?></small>
                            <strong>₱<?php echo number_format($available_account['balance'],2); ?></strong>
                        </div>
                        <a href="member_savings.php?account_id=<?php echo (int)$available_account['account_id']; ?>" aria-label="View account history"><i class="bx bx-chevron-right"></i></a>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>

    </section>

    <section class="dashboard-panel quick-transaction-panel">
        <div class="panel-heading">
            <div><span class="panel-eyebrow">MONEY MANAGEMENT</span><h2>Quick Transaction</h2><p>Deposit or withdraw money from your active savings account.</p></div>
            <div class="panel-heading-icon"><i class="bx bx-transfer-alt"></i></div>
        </div>

        <form method="POST" action="dashboard.php" class="dashboard-form">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>">
            <input type="hidden" name="action" value="transact">

            <div class="form-field">
                <label for="account_id">Savings Account</label>
                <select id="account_id" name="account_id" required>
                    <?php foreach ($accounts as $available_account): ?>
                        <option value="<?php echo (int)$available_account['account_id']; ?>" <?php echo (int)$available_account['account_id'] === $selected_account_id ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($available_account['account_type'].' - '.$available_account['account_number'].' (Balance: PHP '.number_format($available_account['balance'],2).')',ENT_QUOTES,'UTF-8'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-field">
                <label for="transaction_type">Transaction Type</label>
                <select id="transaction_type" name="transaction_type" required>
                    <option value="deposit">Deposit</option>
                    <option value="withdrawal">Withdrawal</option>
                </select>
            </div>

            <div class="form-field">
                <label for="amount">Amount</label>
                <input id="amount" type="number" step="0.01" min="0.01" name="amount" placeholder="₱0.00" required>
            </div>

            <div class="form-field">
                <label for="description">Description</label>
                <select id="description" name="description" required>
                    <option value="">Select description</option>
                    <option value="Counter Deposit">Counter Deposit</option>
                    <option value="Counter Withdrawal">Counter Withdrawal</option>
                    <option value="Monthly Savings">Monthly Savings</option>
                    <option value="Salary Savings">Salary Savings</option>
                    <option value="Bills Payment">Bills Payment</option>
                    <option value="Loan Payment">Loan Payment</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="form-field form-field-wide">
                <label for="custom_description">Additional Description</label>
                <input id="custom_description" type="text" name="custom_description" placeholder="If Other, enter description">
            </div>

            <div class="form-submit">
                <button type="submit"><i class="bx bx-check"></i>Submit Transaction</button>
            </div>
        </form>
    </section>

    <section class="dashboard-content-grid">

        <?php if (count($active_loans) > 0): ?>
            <article class="dashboard-panel loan-panel">
                <div class="panel-heading">
                    <div><span class="panel-eyebrow">LOAN MANAGEMENT</span><h2>Active Loans</h2></div>
                    <div class="panel-heading-icon loan"><i class="bx bx-money"></i></div>
                </div>

                <div class="loan-list">
                    <?php foreach ($active_loans as $ln): ?>
                        <div class="loan-item">
                            <div class="loan-item-header">
                                <div>
                                    <span class="loan-label">LOAN NUMBER</span>
                                    <strong><?php echo htmlspecialchars($ln['loan_number'],ENT_QUOTES,'UTF-8'); ?></strong>
                                </div>
                                <span class="loan-status">ACTIVE</span>
                            </div>

                            <div class="loan-details">
                                <div><span>Original Amount</span><strong>₱<?php echo number_format($ln['loan_amount'],2); ?></strong></div>
                                <div><span>Remaining Balance</span><strong>₱<?php echo number_format($ln['remaining_balance'],2); ?></strong></div>
                            </div>

                            <form method="POST" action="dashboard.php" class="loan-repayment-form">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'],ENT_QUOTES,'UTF-8'); ?>">
                                <input type="hidden" name="action" value="repay_loan">
                                <input type="hidden" name="loan_id" value="<?php echo (int)$ln['id']; ?>">
                                <input type="number" step="0.01" min="0.01" name="repay_amount" placeholder="Repayment Amount (₱)" required>
                                <button type="submit"><i class="bx bx-credit-card"></i>Make Repayment</button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            </article>
        <?php endif; ?>

        <article class="dashboard-panel transactions-panel <?php echo count($active_loans) === 0 ? 'full-width' : ''; ?>">
            <div class="panel-heading">
                <div><span class="panel-eyebrow">ACCOUNT ACTIVITY</span><h2>Recent Transactions</h2></div>
                <div class="panel-heading-icon"><i class="bx bx-history"></i></div>
            </div>

            <?php if (count($transactions) > 0): ?>
                <div class="transaction-table-wrap">
                    <table class="transaction-table">
                        <thead>
                            <tr><th>Reference</th><th>Type</th><th>Amount</th><th>Description</th><th>Date</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($transactions as $tx): ?>
                                <tr>
                                    <td><span class="transaction-reference"><?php echo htmlspecialchars($tx['reference_number'],ENT_QUOTES,'UTF-8'); ?></span></td>
                                    <td><span class="transaction-type <?php echo htmlspecialchars($tx['transaction_type'],ENT_QUOTES,'UTF-8'); ?>"><?php echo strtoupper(htmlspecialchars($tx['transaction_type'],ENT_QUOTES,'UTF-8')); ?></span></td>
                                    <td class="transaction-amount">₱<?php echo number_format($tx['amount'],2); ?></td>
                                    <td><?php echo htmlspecialchars($tx['description'],ENT_QUOTES,'UTF-8'); ?></td>
                                    <td><?php echo date('M d, Y H:i',$tx['created_at']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state"><i class="bx bx-receipt"></i><strong>No transactions yet</strong><span>Your recent account activity will appear here.</span></div>
            <?php endif; ?>
        </article>

    </section>

<?php else: ?>

    <section class="dashboard-panel empty-dashboard">
        <div class="empty-state">
            <i class="bx bx-user-x"></i>
            <h2>Member Account Not Found</h2>
            <p>We could not find an active savings account associated with your account.</p>
        </div>
    </section>

<?php endif; ?>

</main>

<?php pascco_global_footer(); ?>

</body>
</html>