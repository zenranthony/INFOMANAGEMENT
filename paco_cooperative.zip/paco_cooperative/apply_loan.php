<?php
require_once 'db.php';
require_once 'pascco_shell.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'member') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';
$error   = '';
$loan_product = trim($_POST['loan_product'] ?? '');
$loan_term = trim($_POST['loan_term'] ?? '6 months');
$loan_purpose = trim($_POST['loan_purpose'] ?? '');
$contact_number = trim($_POST['contact_number'] ?? '');
$birth_date = trim($_POST['birth_date'] ?? '');
$civil_status = trim($_POST['civil_status'] ?? '');
$address = trim($_POST['address'] ?? '');
$occupation = trim($_POST['occupation'] ?? '');
$employer = trim($_POST['employer'] ?? '');
$monthly_income = trim($_POST['monthly_income'] ?? '');
$id_type = trim($_POST['id_type'] ?? '');
$id_number = trim($_POST['id_number'] ?? '');
$submitted_loan_id = 0;
$allowed_loan_products = [
    'Business Loan', 'Special Promo Loan', 'Livelihood Loan', 'Quick Loan - Productive',
    'Collateralized Loan', 'Calamity Loan', 'Educational / Tuition Loan', 'Medical / Dental Loan',
    'Quick Loan - Providential', 'Minor Home Improvement Loan', 'Petty Cash Loan', 'Multipurpose Loan',
    'Easyoperability Gadgets Loan', 'Easyoperability BHK Loan', 'Easyoperability Optical Loan',
    'Health & Wellness Loan', 'Memorial Plan', 'Personal Accident Insurance', 'Manila North Green Park',
    'Special Loan',
];

$stmt = $pdo->prepare("SELECT id FROM members WHERE user_id = ?");
$stmt->execute([$user_id]);
$member = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $member) {
    verify_csrf(); // Verify CSRF token

    $amount = floatval($_POST['loan_amount'] ?? 0);
    $loan_product = trim($_POST['loan_product'] ?? '');
    $loan_term = trim($_POST['loan_term'] ?? '');
    $loan_purpose = trim($_POST['loan_purpose'] ?? '');
    $contact_number = trim($_POST['contact_number'] ?? '');
    $birth_date = trim($_POST['birth_date'] ?? '');
    $civil_status = trim($_POST['civil_status'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $occupation = trim($_POST['occupation'] ?? '');
    $employer = trim($_POST['employer'] ?? '');
    $monthly_income = trim($_POST['monthly_income'] ?? '');
    $id_type = trim($_POST['id_type'] ?? '');
    $id_number = trim($_POST['id_number'] ?? '');

    $allowed_id_types = ['Philippine Passport', 'Driver License', 'UMID', 'National ID', 'PRC ID', 'Voter ID', 'Other Government ID'];
    $allowed_civil_statuses = ['Single', 'Married', 'Widowed', 'Separated'];
    $upload_directory = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'loan_documents';
    if (!is_dir($upload_directory)) {
        mkdir($upload_directory, 0700, true);
    }

    $save_upload = static function (string $field, string $label) use ($upload_directory): ?string {
        if (!isset($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
            throw new RuntimeException($label . ' is required.');
        }
        $file = $_FILES[$field];
        $allowed_types = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'application/pdf' => 'pdf'];
        $mime_type = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        if ($file['error'] !== UPLOAD_ERR_OK || !isset($allowed_types[$mime_type]) || $file['size'] > 5 * 1024 * 1024) {
            throw new RuntimeException($label . ' must be a JPG, PNG, or PDF file up to 5 MB.');
        }
        $file_name = bin2hex(random_bytes(24)) . '.' . $allowed_types[$mime_type];
        if (!move_uploaded_file($file['tmp_name'], $upload_directory . DIRECTORY_SEPARATOR . $file_name)) {
            throw new RuntimeException('The ' . strtolower($label) . ' could not be saved.');
        }
        return 'uploads/loan_documents/' . $file_name;
    };

    if (!in_array($loan_product, $allowed_loan_products, true)) {
        $error = "Please select a loan product.";
    } elseif ($amount <= 0) {
        $error = "Please enter a valid loan amount.";
    } elseif (!in_array($loan_term, ['6 months', '12 months', '24 months', '36 months'], true)) {
        $error = "Please select a valid loan term.";
    } elseif ($loan_purpose === '' || $contact_number === '' || $birth_date === '' || $civil_status === '' || $address === '' || $occupation === '' || $monthly_income === '' || $id_type === '' || $id_number === '') {
        $error = "Please complete all personal, employment, and identity fields.";
    } elseif (!in_array($civil_status, $allowed_civil_statuses, true) || !in_array($id_type, $allowed_id_types, true)) {
        $error = "Please select valid identity details.";
    } elseif (!is_numeric($monthly_income) || (float) $monthly_income < 0) {
        $error = "Please enter a valid monthly income.";
    } else {
        try {
            $id_document_path = $save_upload('id_document', 'Government ID');
            $proof_income_path = $save_upload('proof_income', 'Proof of income');
            $loan_number = 'LN-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(4)));
            $insert = $pdo->prepare("INSERT INTO loans (member_id, loan_number, loan_product, loan_amount, remaining_balance, status, application_date, loan_term, loan_purpose, contact_number, birth_date, civil_status, address, occupation, employer, monthly_income, id_type, id_number, id_document_path, proof_income_path, identity_status) VALUES (?, ?, ?, ?, ?, 'pending', CURDATE(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
            $insert->execute([$member['id'], $loan_number, $loan_product, $amount, $amount, $loan_term, $loan_purpose, $contact_number, $birth_date, $civil_status, $address, $occupation, $employer, (float) $monthly_income, $id_type, $id_number, $id_document_path, $proof_income_path]);
            $submitted_loan_id = (int) $pdo->lastInsertId();
            record_audit($pdo, $user_id, 'loan_application', 'Submitted loan application ' . $loan_number, 'success');
            $message = "Loan application submitted successfully! Your identity documents are now pending verification.";
        } catch (Throwable $exception) {
            foreach ([$id_document_path ?? null, $proof_income_path ?? null] as $uploaded_path) {
                if ($uploaded_path) {
                    $absolute_path = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $uploaded_path);
                    if (is_file($absolute_path)) {
                        unlink($absolute_path);
                    }
                }
            }
            $error = $exception->getMessage();
        }
    }
}

$history_stmt = $pdo->prepare("SELECT id, loan_number, loan_product, loan_amount, remaining_balance, status, application_date, loan_term, loan_purpose, identity_status FROM loans WHERE member_id = ? ORDER BY id DESC");
$history_stmt->execute([$member['id'] ?? 0]);
$loan_history = $history_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pascco_global_styles(); ?>
    <title>Loan Application | PASCCO</title>
    <style>
        :root {
            --deep-blue:#071d49;
            --blue:#1456a0;
            --blue-2:#2376cc;
            --gold:#e7b84b;
            --gold-soft:#fff6dc;
            --ink:#182a45;
            --muted:#627089;
            --line:#dce4ef;
            --surface:#fff;
            --page:#f4f7fb;
            --success:#0f6b46;
            --danger:#8a2430;
        }
        html, body { margin:0!important; padding:0!important; overflow-x:hidden; }
        * { box-sizing:border-box; }
        body { background:var(--page); color:var(--ink); font-family:Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
        a { color:var(--blue); }
        .member-shell { min-height:100vh; }
        .loan-page { width:min(1220px, calc(100% - 32px)); margin:0 auto; padding:30px 0 70px; }
        .page-hero {
            background:linear-gradient(135deg,var(--deep-blue) 0%,var(--blue) 72%,var(--blue-2) 100%);
            border-radius:24px; color:#fff; padding:30px clamp(22px,4vw,42px); margin-bottom:22px;
            box-shadow:0 18px 40px rgba(7,29,73,.16); position:relative; overflow:hidden;
        }
        .page-hero:after { content:""; position:absolute; width:220px; height:220px; right:-70px; top:-90px; border:42px solid rgba(231,184,75,.18); border-radius:50%; }
        .eyebrow { color:#ffe7a1; text-transform:uppercase; letter-spacing:.14em; font-size:.76rem; font-weight:800; margin-bottom:8px; }
        .page-hero h1 { margin:0; font-size:clamp(1.9rem,4vw,2.7rem); line-height:1.08; }
        .page-hero p { margin:12px 0 0; max-width:720px; color:#e8f0ff; line-height:1.65; }
        .alert { border-radius:14px; padding:14px 16px; margin-bottom:18px; border:1px solid transparent; font-weight:650; }
        .alert.success { background:#e7f6ee; color:var(--success); border-color:#bde4ce; }
        .alert.error { background:#fdecec; color:var(--danger); border-color:#f3c5ca; }
        .layout { display:grid; grid-template-columns:minmax(0,1.55fr) minmax(280px,.45fr); gap:22px; align-items:start; }
        .card { background:var(--surface); border:1px solid #e1e8f2; border-radius:22px; box-shadow:0 12px 30px rgba(7,29,73,.08); }
        .application-card { padding:clamp(22px,3vw,34px); }
        .card-heading { display:flex; justify-content:space-between; gap:16px; align-items:flex-start; margin-bottom:24px; }
        .card-heading h2 { margin:0; color:var(--deep-blue); font-size:1.35rem; }
        .card-heading p { margin:7px 0 0; color:var(--muted); line-height:1.55; }
        .badge { flex:0 0 auto; background:var(--gold-soft); color:#79580d; border:1px solid #f0d88c; border-radius:999px; padding:7px 11px; font-size:.74rem; font-weight:800; }
        .section { padding:22px 0 4px; border-top:1px solid var(--line); }
        .section:first-of-type { padding-top:0; border-top:0; }
        .section-title { display:flex; align-items:center; gap:10px; color:var(--deep-blue); margin:0 0 16px; font-size:1.02rem; }
        .section-title .num { width:28px; height:28px; display:grid; place-items:center; border-radius:50%; background:#e8f0fb; color:var(--blue); font-size:.8rem; font-weight:800; }
        .fields { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:16px; }
        .field.full { grid-column:1/-1; }
        .field label { display:block; color:var(--deep-blue); font-size:.88rem; font-weight:750; margin-bottom:7px; }
        input, select, textarea { width:100%; border:1px solid #cbd7e7; border-radius:12px; padding:12px 13px; font:inherit; color:var(--ink); background:#fbfdff; outline:none; transition:.18s ease; }
        input:focus, select:focus, textarea:focus { border-color:var(--blue); box-shadow:0 0 0 4px rgba(20,86,160,.10); background:#fff; }
        textarea { min-height:110px; resize:vertical; }
        input[type=file] { padding:10px; background:#fff; }
        .hint { display:block; color:var(--muted); font-size:.77rem; line-height:1.45; margin-top:6px; }
        .actions { border-top:1px solid var(--line); margin-top:24px; padding-top:20px; display:flex; justify-content:flex-end; gap:12px; align-items:center; }
        .submit-btn { border:0; border-radius:12px; background:linear-gradient(135deg,var(--blue),var(--blue-2)); color:#fff; padding:13px 20px; font:inherit; font-weight:800; cursor:pointer; box-shadow:0 10px 20px rgba(20,86,160,.20); }
        .submit-btn:hover { transform:translateY(-1px); }
        .guide { background:linear-gradient(180deg,var(--deep-blue),#0b2b67); color:#fff; padding:24px; border-radius:22px; box-shadow:0 12px 30px rgba(7,29,73,.14); position:sticky; top:18px; }
        .guide h2 { margin:0; color:#fff; font-size:1.2rem; }
        .guide p { color:#cfdbed; line-height:1.6; font-size:.9rem; }
        .steps { list-style:none; margin:20px 0 0; padding:0; }
        .steps li { display:flex; gap:11px; align-items:flex-start; padding:12px 0; border-top:1px solid rgba(255,255,255,.12); color:#e6eefb; line-height:1.5; font-size:.9rem; }
        .steps li:first-child { border-top:0; }
        .step-dot { flex:0 0 26px; height:26px; display:grid; place-items:center; border-radius:50%; background:rgba(231,184,75,.18); color:#ffe7a1; font-weight:800; font-size:.76rem; }
        .guide-link { display:inline-flex; align-items:center; margin-top:12px; padding:10px 13px; border:1px solid rgba(231,184,75,.65); border-radius:10px; color:#ffe7a1; text-decoration:none; font-weight:750; }
        .guide-note { margin-top:18px; padding:13px; border-radius:12px; background:rgba(255,255,255,.06); color:#dce7f6; font-size:.82rem; line-height:1.5; }
        .history { margin-top:22px; padding:clamp(20px,3vw,30px); }
        .history-head { display:flex; justify-content:space-between; align-items:end; gap:14px; margin-bottom:16px; }
        .history-head h2 { margin:0; color:var(--deep-blue); font-size:1.28rem; }
        .history-head p { margin:5px 0 0; color:var(--muted); font-size:.88rem; }
        .table-wrap { overflow:auto; border:1px solid var(--line); border-radius:14px; }
        table { width:100%; border-collapse:collapse; min-width:820px; }
        th, td { padding:13px 12px; text-align:left; border-bottom:1px solid var(--line); vertical-align:top; }
        th { background:#eef4fb; color:var(--deep-blue); font-size:.78rem; text-transform:uppercase; letter-spacing:.05em; }
        td { font-size:.87rem; }
        tr:last-child td { border-bottom:0; }
        .loan-no { font-weight:800; color:var(--deep-blue); }
        .sub { display:block; margin-top:4px; color:var(--muted); font-size:.76rem; }
        .status { display:inline-block; border-radius:999px; padding:5px 9px; background:#edf2f7; color:#415169; font-size:.72rem; font-weight:800; }
        .status.pending { background:#fff5d9; color:#79580d; }
        .status.approved { background:#e7f6ee; color:var(--success); }
        .status.rejected { background:#fdecec; color:var(--danger); }
        .print-link { display:inline-block; margin-top:7px; font-weight:700; text-decoration:none; }
        .empty { padding:30px; text-align:center; color:var(--muted); background:#f8fbff; border:1px dashed #cbd7e7; border-radius:14px; }
        @media (max-width:900px) { .layout{grid-template-columns:1fr;} .guide{position:static;} }
        @media (max-width:700px) { .loan-page{width:min(100% - 20px,1220px);padding-top:18px;} .fields{grid-template-columns:1fr;} .field.full{grid-column:auto;} .card-heading,.history-head{display:block;} .badge{display:inline-block;margin-top:12px;} .actions{display:block;} .submit-btn{width:100%;} }
    </style>
    <link rel="stylesheet" href="member-panels.css?v=2">
</head>
<body>
<?php pascco_member_header('Loan Application'); ?>
<main class="loan-page member-content">
    <section class="page-hero">
        <div class="eyebrow">Member lending service</div>
        <h1>Apply for a Loan</h1>
        <p>Complete your loan request, provide the required identity and income documents, and submit your application for cooperative review.</p>
    </section>

    <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>

    <div class="layout">
        <section class="card application-card">
            <div class="card-heading">
                <div>
                    <h2>Loan Application Form</h2>
                    <p>Fields marked by the form's required indicators must be completed before submission.</p>
                </div>
                <span class="badge">Secure application</span>
            </div>
            <form method="POST" action="apply_loan.php" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

                <div class="section">
                    <h3 class="section-title"><span class="num">1</span>Loan Request</h3>
                    <div class="fields">
                        <div class="field full">
                            <label for="loan-product">Loan Product</label>
                            <select id="loan-product" name="loan_product" required>
                                <option value="">Choose a loan product</option>
                                <?php foreach ($allowed_loan_products as $product): ?>
                                    <option value="<?php echo htmlspecialchars($product, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $loan_product === $product ? 'selected' : ''; ?>><?php echo htmlspecialchars($product, ENT_QUOTES, 'UTF-8'); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small class="hint">Select the product that best matches your financing need.</small>
                        </div>
                        <div class="field">
                            <label for="loan-amount">Desired Loan Amount (PHP)</label>
                            <input id="loan-amount" type="number" step="0.01" min="1" name="loan_amount" value="<?php echo isset($_POST['loan_amount']) ? htmlspecialchars($_POST['loan_amount'], ENT_QUOTES, 'UTF-8') : ''; ?>" placeholder="e.g. 10000" required>
                        </div>
                        <div class="field">
                            <label for="loan-term">Preferred Term</label>
                            <select id="loan-term" name="loan_term" required>
                                <?php foreach (['6 months','12 months','24 months','36 months'] as $term): ?>
                                    <option value="<?php echo $term; ?>" <?php echo $loan_term === $term ? 'selected' : ''; ?>><?php echo $term; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="field">
                            <label for="contact-number">Contact Number</label>
                            <input id="contact-number" type="tel" name="contact_number" value="<?php echo htmlspecialchars($contact_number, ENT_QUOTES, 'UTF-8'); ?>" placeholder="09XX XXX XXXX" required>
                        </div>
                        <div class="field full">
                            <label for="loan-purpose">Purpose of Loan</label>
                            <textarea id="loan-purpose" name="loan_purpose" placeholder="Briefly explain how the loan will be used" required><?php echo htmlspecialchars($loan_purpose, ENT_QUOTES, 'UTF-8'); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <h3 class="section-title"><span class="num">2</span>Personal &amp; Employment Details</h3>
                    <div class="fields">
                        <div class="field">
                            <label for="birth-date">Birth Date</label>
                            <input id="birth-date" type="date" name="birth_date" value="<?php echo htmlspecialchars($birth_date, ENT_QUOTES, 'UTF-8'); ?>" required>
                        </div>
                        <div class="field">
                            <label for="civil-status">Civil Status</label>
                            <select id="civil-status" name="civil_status" required>
                                <option value="">Select civil status</option>
                                <?php foreach (['Single','Married','Widowed','Separated'] as $status): ?>
                                    <option value="<?php echo $status; ?>" <?php echo $civil_status === $status ? 'selected' : ''; ?>><?php echo $status; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="field full">
                            <label for="address">Complete Home Address</label>
                            <input id="address" name="address" value="<?php echo htmlspecialchars($address, ENT_QUOTES, 'UTF-8'); ?>" placeholder="House/Unit, Street, Barangay, City/Municipality" required>
                        </div>
                        <div class="field">
                            <label for="occupation">Occupation</label>
                            <input id="occupation" name="occupation" value="<?php echo htmlspecialchars($occupation, ENT_QUOTES, 'UTF-8'); ?>" required>
                        </div>
                        <div class="field">
                            <label for="employer">Employer or Business Name</label>
                            <input id="employer" name="employer" value="<?php echo htmlspecialchars($employer, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Enter N/A when not applicable">
                        </div>
                        <div class="field">
                            <label for="monthly-income">Monthly Income (PHP)</label>
                            <input id="monthly-income" type="number" min="0" step="0.01" name="monthly_income" value="<?php echo htmlspecialchars($monthly_income, ENT_QUOTES, 'UTF-8'); ?>" placeholder="e.g. 25000" required>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <h3 class="section-title"><span class="num">3</span>Identity Verification</h3>
                    <div class="fields">
                        <div class="field">
                            <label for="id-type">Government ID Type</label>
                            <select id="id-type" name="id_type" required>
                                <option value="">Select ID type</option>
                                <?php foreach (['Philippine Passport','Driver License','UMID','National ID','PRC ID','Voter ID','Other Government ID'] as $option): ?>
                                    <option value="<?php echo htmlspecialchars($option, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $id_type === $option ? 'selected' : ''; ?>><?php echo htmlspecialchars($option, ENT_QUOTES, 'UTF-8'); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="field">
                            <label for="id-number">Government ID Number</label>
                            <input id="id-number" name="id_number" value="<?php echo htmlspecialchars($id_number, ENT_QUOTES, 'UTF-8'); ?>" required>
                        </div>
                        <div class="field">
                            <label for="id-document">Government ID</label>
                            <input id="id-document" type="file" name="id_document" accept="image/jpeg,image/png,application/pdf" required>
                            <small class="hint">JPG, PNG, or PDF · maximum 5 MB.</small>
                        </div>
                        <div class="field">
                            <label for="proof-income">Proof of Income</label>
                            <input id="proof-income" type="file" name="proof_income" accept="image/jpeg,image/png,application/pdf" required>
                            <small class="hint">Payslip, certificate, or business proof · maximum 5 MB.</small>
                        </div>
                    </div>
                </div>

                <div class="actions">
                    <span class="hint">Your application and uploaded documents are sent through the secured member workflow for verification.</span>
                    <button class="submit-btn" type="submit">Submit Loan Application</button>
                </div>
            </form>
        </section>

        <aside class="guide">
            <h2>How the application works</h2>
            <p>Your request moves through verification and cooperative review before any loan can become active.</p>
            <ol class="steps">
                <li><span class="step-dot">1</span><span>Choose the loan product, amount, term, and purpose.</span></li>
                <li><span class="step-dot">2</span><span>Complete your personal and employment information.</span></li>
                <li><span class="step-dot">3</span><span>Upload a valid government ID and proof of income.</span></li>
                <li><span class="step-dot">4</span><span>Submit and monitor the application status in your history.</span></li>
            </ol>
            <a class="guide-link" href="credit.php">Review loan products</a>
            <div class="guide-note"><strong>Reminder:</strong> Submission does not guarantee approval. Final decisions depend on document verification and cooperative review.</div>
        </aside>
    </div>

    <section class="card history">
        <div class="history-head">
            <div>
                <h2>My Loan Applications</h2>
                <p>Review your submitted requests, current status, and printable application copies.</p>
            </div>
        </div>
        <?php if ($loan_history): ?>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr><th>Loan</th><th>Product</th><th>Amount</th><th>Remaining</th><th>Status</th><th>Applied</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($loan_history as $loan): ?>
                        <?php $status_class = strtolower((string)$loan['status']); ?>
                        <tr>
                            <td><span class="loan-no"><?php echo htmlspecialchars($loan['loan_number'], ENT_QUOTES, 'UTF-8'); ?></span><span class="sub"><?php echo htmlspecialchars($loan['loan_term'], ENT_QUOTES, 'UTF-8'); ?></span></td>
                            <td><?php echo htmlspecialchars($loan['loan_product'] ?? 'Loan application', ENT_QUOTES, 'UTF-8'); ?></td>
                            <td>PHP <?php echo number_format((float)$loan['loan_amount'], 2); ?></td>
                            <td>PHP <?php echo number_format((float)$loan['remaining_balance'], 2); ?></td>
                            <td><span class="status <?php echo htmlspecialchars($status_class, ENT_QUOTES, 'UTF-8'); ?>"><?php echo strtoupper(htmlspecialchars($loan['status'], ENT_QUOTES, 'UTF-8')); ?></span><span class="sub">Identity: <?php echo htmlspecialchars($loan['identity_status'] ?? 'pending', ENT_QUOTES, 'UTF-8'); ?></span></td>
                            <td><?php echo htmlspecialchars($loan['application_date'], ENT_QUOTES, 'UTF-8'); ?><a class="print-link" href="loan_application_print.php?loan_id=<?php echo (int)$loan['id']; ?>" target="_blank" rel="noopener">Print / Save PDF</a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty">You have not submitted a loan application yet. Complete the form above to get started.</div>
        <?php endif; ?>
    </section>
</main>
<?php pascco_global_footer(); ?>
</body>
</html>
